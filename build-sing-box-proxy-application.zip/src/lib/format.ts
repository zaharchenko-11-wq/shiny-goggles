export function flagEmoji(code: string | null | undefined): string {
  const normalized = (code ?? "").toUpperCase();
  if (!/^[A-Z]{2}$/.test(normalized) || normalized === "XX") return "🌐";
  return String.fromCodePoint(
    ...normalized.split("").map((char) => 0x1f1e6 + char.charCodeAt(0) - 65),
  );
}

export function relativeTime(value: string | Date | null | undefined): string {
  if (!value) return "—";
  const date = typeof value === "string" ? new Date(value) : value;
  const diff = Date.now() - date.getTime();
  if (Number.isNaN(diff)) return "—";
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return "только что";
  if (minutes < 60) return `${minutes} мин назад`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} ч назад`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days} дн назад`;
  return date.toLocaleDateString("ru-RU", { day: "2-digit", month: "short" });
}

export function clockTime(value: string | Date | null | undefined): string {
  if (!value) return "—:—";
  const date = typeof value === "string" ? new Date(value) : value;
  if (Number.isNaN(date.getTime())) return "—:—";
  return date.toLocaleTimeString("ru-RU", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

export function latencyTone(ms: number | null | undefined): "good" | "warn" | "bad" {
  if (ms === null || ms === undefined) return "bad";
  if (ms < 90) return "good";
  if (ms < 170) return "warn";
  return "bad";
}

export function latencyPct(ms: number | null | undefined): number {
  if (!ms) return 4;
  return Math.max(6, Math.min(100, Math.round((ms / 260) * 100)));
}

export function protocolLabel(protocol: string): string {
  const map: Record<string, string> = {
    vless: "VLESS",
    vmess: "VMess",
    trojan: "Trojan",
    shadowsocks: "Shadowsocks",
    hysteria2: "Hysteria2",
  };
  return map[protocol] ?? protocol.toUpperCase();
}

export function shortHost(host: string, max = 28): string {
  if (host.length <= max) return host;
  return `${host.slice(0, max - 1)}…`;
}
