import { db } from "@/db";
import { egressChecks, events, nodes, settings } from "@/db/schema";
import type { EventRow, EgressRow, NodeRow, SettingsRow } from "@/db/schema";
import { ensureSeeded } from "@/lib/seed";
import { and, desc, eq, sql } from "drizzle-orm";
import { cache } from "react";

export type AppState = {
  settings: SettingsRow;
  nodes: NodeRow[];
  activeNode: NodeRow | null;
  events: EventRow[];
  latestEgress: EgressRow | null;
};

export const getState = cache(async (): Promise<AppState> => {
  await ensureSeeded();

  const [settingsRow] = await db.select().from(settings).where(eq(settings.id, 1)).limit(1);
  const nodeRows = await db.select().from(nodes).orderBy(nodes.id);
  const eventRows = await db
    .select()
    .from(events)
    .orderBy(desc(events.createdAt), desc(events.id))
    .limit(40);
  const [egressRow] = await db
    .select()
    .from(egressChecks)
    .orderBy(desc(egressChecks.createdAt), desc(egressChecks.id))
    .limit(1);

  const current: SettingsRow =
    settingsRow ??
    ({
      id: 1,
      activeNodeId: nodeRows[0]?.id ?? null,
      connected: nodeRows.length > 0,
      connectedAt: new Date(),
      mixedPort: 2080,
      clashPort: 9090,
      tunEnabled: false,
      autoSelect: true,
      killSwitch: true,
      dnsStrategy: "ipv4_only",
      remoteDns: "",
      directDns: "",
      routeChatGPT: true,
      routeCodex: true,
      routeAnthropic: false,
      routeGoogle: false,
      routeStreaming: false,
      ruleSetMode: true,
      telemetryMode: "simulated",
      agentToken: "exitnode-local-agent",
      updatedAt: new Date(),
    } satisfies SettingsRow);

  const activeNode =
    nodeRows.find((node) => node.id === current.activeNodeId) ?? nodeRows[0] ?? null;

  return {
    settings: current,
    nodes: nodeRows,
    activeNode: current.connected ? activeNode : null,
    events: eventRows,
    latestEgress: egressRow ?? null,
  };
});

export async function getSettingsRow(): Promise<SettingsRow> {
  const state = await getState();
  return state.settings;
}

export async function getNode(id: number): Promise<NodeRow | null> {
  const [row] = await db.select().from(nodes).where(eq(nodes.id, id)).limit(1);
  return row ?? null;
}

export async function logEvent(entry: {
  level?: "info" | "success" | "warn" | "error";
  scope?: string;
  message: string;
  nodeName?: string | null;
}): Promise<void> {
  await db.insert(events).values({
    level: entry.level ?? "info",
    scope: entry.scope ?? "system",
    message: entry.message,
    nodeName: entry.nodeName ?? null,
  });
}

export async function touchSettings(patch: Partial<SettingsRow>): Promise<SettingsRow> {
  await db
    .update(settings)
    .set({ ...patch, updatedAt: new Date() })
    .where(eq(settings.id, 1));
  const [row] = await db.select().from(settings).where(eq(settings.id, 1)).limit(1);
  return row;
}

export async function findNodeByName(name: string): Promise<NodeRow | null> {
  const [row] = await db.select().from(nodes).where(eq(nodes.name, name)).limit(1);
  return row ?? null;
}

export async function countNodes(): Promise<number> {
  const [row] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(nodes)
    .where(and(eq(nodes.enabled, true)));
  return row?.count ?? 0;
}
