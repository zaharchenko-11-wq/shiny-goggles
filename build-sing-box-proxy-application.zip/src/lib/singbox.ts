import type { NodeRow, SettingsRow } from "@/db/schema";
import {
  enabledRouteGroups,
  ROUTE_GROUPS,
  type RouteGroupKey,
} from "@/lib/ai-routes";

export type SingBoxConfig = Record<string, unknown>;

export const SELECTOR_TAG = "ai-exit";
export const AUTO_TAG = "ai-auto";

export function slugify(value: string): string {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
    .slice(0, 28);
}

export function nodeTag(node: Pick<NodeRow, "id" | "name">): string {
  return `node-${node.id}-${slugify(node.name) || "exit"}`;
}

type Transport = Record<string, unknown> | undefined;

function buildTransport(node: NodeRow): Transport {
  if (node.network === "ws") {
    const headers: Record<string, string> = {};
    if (node.wsHost) headers.Host = node.wsHost;
    return {
      type: "ws",
      path: node.path || "/",
      ...(Object.keys(headers).length ? { headers } : {}),
      max_early_data: 2048,
      early_data_header_name: "Sec-WebSocket-Protocol",
    };
  }
  if (node.network === "grpc") {
    return { type: "grpc", service_name: node.serviceName || "" };
  }
  if (node.network === "http") {
    return { type: "http", path: node.path || "/" };
  }
  return undefined;
}

function buildTls(node: NodeRow): Record<string, unknown> | undefined {
  if (node.security === "none") return undefined;
  const tls: Record<string, unknown> = {
    enabled: true,
    server_name: node.sni || node.wsHost || node.host,
    utls: { enabled: true, fingerprint: node.fingerprint || "chrome" },
  };
  if (node.alpn) {
    tls.alpn = node.alpn
      .split(",")
      .map((item) => item.trim())
      .filter(Boolean);
  }
  if (node.security === "reality") {
    tls.reality = {
      enabled: true,
      public_key: node.publicKey,
      short_id: node.shortId,
    };
  }
  return tls;
}

export function buildOutbound(node: NodeRow): Record<string, unknown> {
  const tag = nodeTag(node);
  const transport = buildTransport(node);
  const tls = buildTls(node);

  switch (node.protocol) {
    case "vless":
      return {
        type: "vless",
        tag,
        server: node.host,
        server_port: node.port,
        uuid: node.uuid,
        ...(node.flow ? { flow: node.flow } : {}),
        ...(tls ? { tls } : {}),
        ...(transport ? { transport } : {}),
        packet_encoding: "xudp",
      };
    case "vmess":
      return {
        type: "vmess",
        tag,
        server: node.host,
        server_port: node.port,
        uuid: node.uuid,
        security: "auto",
        alter_id: 0,
        ...(tls ? { tls } : {}),
        ...(transport ? { transport } : {}),
      };
    case "trojan":
      return {
        type: "trojan",
        tag,
        server: node.host,
        server_port: node.port,
        password: node.password,
        ...(tls ? { tls } : {}),
        ...(transport ? { transport } : {}),
      };
    case "shadowsocks":
      return {
        type: "shadowsocks",
        tag,
        server: node.host,
        server_port: node.port,
        method: node.method || "2022-blake3-aes-128-gcm",
        password: node.password,
      };
    case "hysteria2":
      return {
        type: "hysteria2",
        tag,
        server: node.host,
        server_port: node.port,
        password: node.password,
        ...(node.obfs
          ? { obfs: { type: node.obfs, password: node.obfsPassword } }
          : {}),
        tls: {
          enabled: true,
          server_name: node.sni || node.host,
          alpn: node.alpn ? node.alpn.split(",") : ["h3"],
          ...(node.fingerprint ? { utls: { enabled: true, fingerprint: node.fingerprint } } : {}),
        },
      };
    default:
      return {
        type: "vless",
        tag,
        server: node.host,
        server_port: node.port,
        uuid: node.uuid,
        ...(tls ? { tls } : {}),
      };
  }
}

/** Deep config that can be pasted straight into `sing-box run -c config.json`. */
export function buildSingBoxConfig(
  allNodes: NodeRow[],
  settings: SettingsRow,
  activeNodeId: number | null,
): { config: SingBoxConfig; activeTag: string; exitTags: string[] } {
  const nodes = allNodes.filter((node) => node.enabled);
  const tags = nodes.map(nodeTag);
  const activeNode = nodes.find((node) => node.id === activeNodeId) ?? nodes[0] ?? null;
  const activeTag = activeNode ? nodeTag(activeNode) : "direct";

  const outbounds: Record<string, unknown>[] = [];
  if (nodes.length > 0) {
    outbounds.push({
      type: "selector",
      tag: SELECTOR_TAG,
      outbounds: [AUTO_TAG, ...tags],
      default: activeTag,
      interrupt_exist_connections: false,
    });
    outbounds.push({
      type: "urltest",
      tag: AUTO_TAG,
      outbounds: tags,
      url: "https://chatgpt.com/favicon.ico",
      interval: "3m",
      tolerance: 80,
      idle_timeout: "30m",
    });
  }
  outbounds.push(...nodes.map(buildOutbound));
  outbounds.push({ type: "direct", tag: "direct" });
  outbounds.push({ type: "block", tag: "block" });

  const groups = enabledRouteGroups(settings);
  const ruleSetMode = settings.ruleSetMode !== false;
  const proxyTarget = nodes.length > 0 ? SELECTOR_TAG : "direct";

  const routeRules: Record<string, unknown>[] = [
    { protocol: "dns", action: "hijack-dns" },
    { ip_is_private: true, outbound: "direct" },
  ];
  if (ruleSetMode) {
    const ruleSet = buildRuleSet(groups.map((group) => group.key));
    if (ruleSet.length > 0) {
      routeRules.push({ rule_set: ruleSet.map((item) => item.tag), outbound: proxyTarget });
    }
  } else {
    const suffixes = Array.from(new Set(groups.flatMap((group) => group.domains)));
    if (suffixes.length > 0) {
      routeRules.push({ domain_suffix: suffixes, outbound: proxyTarget });
    }
  }

  const config: SingBoxConfig = {
    log: { level: "info", timestamp: true },
    dns: {
      servers: [
        {
          type: "https",
          tag: "dns-remote",
          server: "1.1.1.1",
          domain_resolver: "dns-bootstrap",
          detour: proxyTarget,
        },
        {
          type: "https",
          tag: "dns-direct",
          server: "8.8.8.8",
          domain_resolver: "dns-bootstrap",
          detour: "direct",
        },
        { type: "udp", tag: "dns-bootstrap", server: "1.1.1.1" },
      ],
      rules: [
        { clash_mode: "Direct", server: "dns-direct" },
        ...(groups.length > 0
          ? [
              {
                domain_suffix: Array.from(
                  new Set(groups.flatMap((group) => group.domains.filter((d) => !d.includes("*")))),
                ),
                server: "dns-remote",
              },
            ]
          : []),
      ],
      final: "dns-remote",
      strategy: settings.dnsStrategy || "ipv4_only",
      independent_cache: true,
    },
    inbounds: [
      {
        type: "mixed",
        tag: "mixed-in",
        listen: "127.0.0.1",
        listen_port: settings.mixedPort,
      },
      ...(settings.tunEnabled
        ? [
            {
              type: "tun",
              tag: "tun-in",
              address: ["172.19.0.1/30", "fdfe:dcba:9876::1/126"],
              auto_route: true,
              strict_route: settings.killSwitch,
              stack: "mixed",
            },
          ]
        : []),
    ],
    outbounds,
    route: {
      rules: routeRules,
      ...(ruleSetMode
        ? { rule_set: buildRuleSet(groups.map((group) => group.key)) }
        : {}),
      final: "direct",
      auto_detect_interface: true,
      default_domain_resolver: "dns-bootstrap",
    },
    experimental: {
      cache_file: { enabled: true, store_fakeip: false },
      clash_api: {
        external_controller: `127.0.0.1:${settings.clashPort}`,
        default_mode: "Rule",
      },
    },
  };

  return { config, activeTag, exitTags: tags };
}

function buildRuleSet(keys: RouteGroupKey[]) {
  const seen = new Set<string>();
  return ROUTE_GROUPS.filter((group) => keys.includes(group.key))
    .map((group) => ({
      type: "remote",
      tag: `ai-${group.key}`,
      format: "binary",
      url: group.ruleSet,
      download_detour: "direct",
      update_interval: "1d",
    }))
    .filter((item) => {
      if (seen.has(item.tag)) return false;
      seen.add(item.tag);
      return true;
    });
}

export function buildRunScript(): string {
  return [
    "# 1. Установка sing-box (Linux / macOS)",
    "curl -fsSL https://sing-box.app/install.sh | sh",
    "",
    "# 2. Сохранить конфиг, сгенерированный в панели",
    "mkdir -p ~/.config/exitnode",
    "curl -s http://localhost:3000/api/export -o ~/.config/exitnode/config.json",
    "",
    "# 3. Проверить и запустить",
    "sing-box check -c ~/.config/exitnode/config.json",
    "sudo sing-box run -c ~/.config/exitnode/config.json",
    "",
    "# 4. Проверить, что ChatGPT видит новый выход",
    "curl -s https://api.ipify.org; echo",
    "export HTTPS_PROXY=http://127.0.0.1:2080",
    "",
    "# 5. Codex CLI через тот же exit",
    "codex --config 'model_providers.openai.base_url=\"https://api.openai.com/v1\"'",
  ].join("\n");
}
