export type RouteGroupKey =
  | "chatgpt"
  | "codex"
  | "anthropic"
  | "google"
  | "streaming";

export type RouteGroup = {
  key: RouteGroupKey;
  label: string;
  hint: string;
  domains: string[];
  ruleSet: string;
};

/**
 * Domains that must leave through the residential/clean exit when talking to
 * ChatGPT and Codex. Keeping them in one place means the exported sing-box
 * config and the UI stay in sync.
 */
export const ROUTE_GROUPS: RouteGroup[] = [
  {
    key: "chatgpt",
    label: "ChatGPT",
    hint: "chatgpt.com, auth, CDN и файлы",
    domains: [
      "chatgpt.com",
      "chat.openai.com",
      "ab.chatgpt.com",
      "auth.openai.com",
      "auth0.openai.com",
      "cdn.oaistatic.com",
      "oaistatic.com",
      "oaiusercontent.com",
      "openaiapi-site.azureedge.net",
      "sora.com",
      "sora.chatgpt.com",
    ],
    ruleSet:
      "https://raw.githubusercontent.com/MetaCubeX/meta-rules-dat/sing/geo/geosite/openai.srs",
  },
  {
    key: "codex",
    label: "Codex / API",
    hint: "api.openai.com, platform, CLI-сессии",
    domains: [
      "api.openai.com",
      "platform.openai.com",
      "chatgpt.com",
      "auth.openai.com",
      "cdn.openai.com",
      "openaiapi-site.azureedge.net",
      "oaistatic.com",
      "oaiusercontent.com",
    ],
    ruleSet:
      "https://raw.githubusercontent.com/MetaCubeX/meta-rules-dat/sing/geo/geosite/openai.srs",
  },
  {
    key: "anthropic",
    label: "Claude",
    hint: "anthropic.com, claude.ai",
    domains: ["anthropic.com", "claude.ai", "claudeusercontent.com"],
    ruleSet:
      "https://raw.githubusercontent.com/MetaCubeX/meta-rules-dat/sing/geo/geosite/anthropic.srs",
  },
  {
    key: "google",
    label: "Gemini",
    hint: "Google AI Studio и Gemini API",
    domains: [
      "gemini.google.com",
      "generativelanguage.googleapis.com",
      "aistudio.google.com",
      "ai.google.dev",
    ],
    ruleSet:
      "https://raw.githubusercontent.com/MetaCubeX/meta-rules-dat/sing/geo/geosite/google-gemini.srs",
  },
  {
    key: "streaming",
    label: "Streaming + Voice",
    hint: "Realtime voice, websocket-сессии",
    domains: ["*.openai.com", "*.chatgpt.com", "*.oaistatic.com"],
    ruleSet:
      "https://raw.githubusercontent.com/MetaCubeX/meta-rules-dat/sing/geo/geosite/openai.srs",
  },
];

export const ROUTE_GROUP_MAP: Record<RouteGroupKey, RouteGroup> = ROUTE_GROUPS.reduce(
  (acc, group) => {
    acc[group.key] = group;
    return acc;
  },
  {} as Record<RouteGroupKey, RouteGroup>,
);

export function enabledRouteGroups(settings: {
  routeChatGPT: boolean;
  routeCodex: boolean;
  routeAnthropic: boolean;
  routeGoogle: boolean;
  routeStreaming: boolean;
}): RouteGroup[] {
  const flags: Record<RouteGroupKey, boolean> = {
    chatgpt: settings.routeChatGPT,
    codex: settings.routeCodex,
    anthropic: settings.routeAnthropic,
    google: settings.routeGoogle,
    streaming: settings.routeStreaming,
  };
  return ROUTE_GROUPS.filter((group) => flags[group.key]);
}

export function flagsFromBody(body: Record<string, unknown>) {
  return {
    routeChatGPT: Boolean(body.routeChatGPT),
    routeCodex: Boolean(body.routeCodex),
    routeAnthropic: Boolean(body.routeAnthropic),
    routeGoogle: Boolean(body.routeGoogle),
    routeStreaming: Boolean(body.routeStreaming),
  };
}
