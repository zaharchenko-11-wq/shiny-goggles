import { connect } from "node:net";
import type { NodeRow } from "@/db/schema";

const UA =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Safari/537.36";

export type EgressInfo = {
  ip: string;
  country: string;
  countryCode: string;
  city: string;
  org: string;
  asn: string;
  latencyMs: number | null;
  provider: string;
};

async function fetchJson(url: string, timeout = 3500): Promise<Record<string, unknown> | null> {
  try {
    const response = await fetch(url, {
      cache: "no-store",
      headers: { "user-agent": UA, accept: "application/json" },
      signal: AbortSignal.timeout(timeout),
    });
    if (!response.ok) return null;
    return (await response.json()) as Record<string, unknown>;
  } catch {
    return null;
  }
}

/** Resolves the IP the current host really presents to the internet. */
export async function detectEgress(): Promise<EgressInfo | null> {
  const started = Date.now();
  const ipapi = await fetchJson("https://ipapi.co/json/");
  if (ipapi?.ip) {
    return {
      ip: String(ipapi.ip),
      country: String(ipapi.country_name || ""),
      countryCode: String(ipapi.country_code || "XX"),
      city: String(ipapi.city || ""),
      org: String(ipapi.org || ""),
      asn: String(ipapi.asn || ""),
      latencyMs: Date.now() - started,
      provider: "ipapi.co",
    };
  }

  const ipwho = await fetchJson("https://ipwho.is/");
  if (ipwho?.ip && ipwho.success !== false) {
    return {
      ip: String(ipwho.ip),
      country: String(ipwho.country || ""),
      countryCode: String(ipwho.country_code || "XX"),
      city: String(ipwho.city || ""),
      org: String((ipwho.connection as Record<string, unknown> | undefined)?.org || ""),
      asn: String((ipwho.connection as Record<string, unknown> | undefined)?.asn || ""),
      latencyMs: Date.now() - started,
      provider: "ipwho.is",
    };
  }

  const ipify = await fetchJson("https://api.ipify.org?format=json");
  if (ipify?.ip) {
    return {
      ip: String(ipify.ip),
      country: "",
      countryCode: "XX",
      city: "",
      org: "",
      asn: "",
      latencyMs: Date.now() - started,
      provider: "ipify.org",
    };
  }

  return null;
}

export async function probeTcp(host: string, port: number, timeout = 2500): Promise<number | null> {
  return new Promise((resolve) => {
    const started = Date.now();
    let settled = false;
    const socket = connect({ host, port });
    const finish = (value: number | null) => {
      if (settled) return;
      settled = true;
      socket.destroy();
      resolve(value);
    };
    socket.setTimeout(timeout);
    socket.once("connect", () => finish(Date.now() - started));
    socket.once("timeout", () => finish(null));
    socket.once("error", () => finish(null));
  });
}

function hash(value: string): number {
  let h = 2166136261;
  for (let i = 0; i < value.length; i += 1) {
    h ^= value.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

const REGION_BASE: Record<string, number> = {
  DE: 34,
  NL: 41,
  FR: 46,
  GB: 52,
  CH: 44,
  SE: 58,
  FI: 61,
  PL: 49,
  US: 88,
  CA: 96,
  JP: 132,
  SG: 148,
  AE: 121,
  TR: 79,
  KZ: 112,
};

/**
 * Demo telemetry used when no sing-box agent is attached to the control plane.
 * Values are deterministic per node so the dashboard stays stable between
 * requests instead of jumping around with Math.random().
 */
export function simulateLatency(node: Pick<NodeRow, "host" | "countryCode" | "protocol">): {
  latencyMs: number;
  lossPct: number;
} {
  const seed = hash(`${node.host}:${node.protocol}`);
  const base = REGION_BASE[node.countryCode] ?? 96;
  const jitter = seed % 46;
  const penalty = node.protocol === "hysteria2" ? -8 : node.protocol === "shadowsocks" ? 6 : 0;
  return {
    latencyMs: Math.max(12, base + jitter + penalty),
    lossPct: seed % 11 === 0 ? 1 : 0,
  };
}

export async function probeNode(
  node: NodeRow,
  mode: "simulated" | "tcp",
): Promise<{ latencyMs: number | null; lossPct: number; source: "simulated" | "tcp" }> {
  if (mode === "tcp") {
    const latencyMs = await probeTcp(node.host, node.port);
    if (latencyMs !== null) return { latencyMs, lossPct: 0, source: "tcp" };
    return { latencyMs: null, lossPct: 100, source: "tcp" };
  }
  const simulated = simulateLatency(node);
  return { ...simulated, source: "simulated" };
}

export async function probeEndpoint(
  url: string,
  timeout = 6000,
): Promise<{ ok: boolean; status: number; ms: number }> {
  const started = Date.now();
  try {
    const response = await fetch(url, {
      cache: "no-store",
      redirect: "manual",
      headers: { "user-agent": UA },
      signal: AbortSignal.timeout(timeout),
    });
    return { ok: response.status < 500, status: response.status, ms: Date.now() - started };
  } catch {
    return { ok: false, status: 0, ms: Date.now() - started };
  }
}
