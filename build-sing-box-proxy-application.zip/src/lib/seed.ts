import { db } from "@/db";
import { events, nodes, settings } from "@/db/schema";
import { simulateLatency } from "@/lib/net";
import { sql } from "drizzle-orm";

type SeedNode = {
  name: string;
  protocol: string;
  host: string;
  port: number;
  country: string;
  countryCode: string;
  city: string;
  provider: string;
  uuid?: string;
  password?: string;
  method?: string;
  network?: string;
  path?: string;
  wsHost?: string;
  security?: string;
  sni?: string;
  alpn?: string;
  flow?: string;
  publicKey?: string;
  shortId?: string;
  obfs?: string;
  obfsPassword?: string;
};

const SEED_NODES: SeedNode[] = [
  {
    name: "Frankfurt · AI-01",
    protocol: "vless",
    host: "fra1.exitnode.dev",
    port: 443,
    country: "Germany",
    countryCode: "DE",
    city: "Frankfurt",
    provider: "Hetzner / own",
    uuid: "4f7a92c4-9d1a-4c1e-b4a6-51e8f2f0c9a1",
    network: "tcp",
    security: "reality",
    sni: "www.microsoft.com",
    flow: "xtls-rprx-vision",
    publicKey: "3mKq3W2oBv7FzYb1nQ9tSc4hLdRjXeP8uVgA5kNrTmZ",
    shortId: "6ba9f1c2",
  },
  {
    name: "Amsterdam · Clean-02",
    protocol: "hysteria2",
    host: "ams2.exitnode.dev",
    port: 443,
    country: "Netherlands",
    countryCode: "NL",
    city: "Amsterdam",
    provider: "Leaseweb",
    password: "hy2-5f2c88d41b",
    security: "tls",
    sni: "ams2.exitnode.dev",
    alpn: "h3",
    obfs: "salamander",
    obfsPassword: "8f13ce77",
  },
  {
    name: "Ashburn · GPT-Edge",
    protocol: "trojan",
    host: "iad1.exitnode.dev",
    port: 443,
    country: "United States",
    countryCode: "US",
    city: "Ashburn",
    provider: "Vultr",
    password: "trj-91ba77c0",
    network: "ws",
    path: "/edge",
    wsHost: "iad1.exitnode.dev",
    security: "tls",
    sni: "iad1.exitnode.dev",
  },
  {
    name: "Tokyo · Residential",
    protocol: "vless",
    host: "tyo1.exitnode.dev",
    port: 8443,
    country: "Japan",
    countryCode: "JP",
    city: "Tokyo",
    provider: "Residential pool",
    uuid: "b21e7f0a-6c44-4a92-9f31-7d0be5aa2c66",
    network: "ws",
    path: "/ray",
    wsHost: "tyo1.exitnode.dev",
    security: "tls",
    sni: "tyo1.exitnode.dev",
  },
  {
    name: "Singapore · Codex",
    protocol: "shadowsocks",
    host: "sgp1.exitnode.dev",
    port: 8388,
    country: "Singapore",
    countryCode: "SG",
    city: "Singapore",
    provider: "DigitalOcean",
    method: "2022-blake3-aes-128-gcm",
    password: "0f9a2Kt7bQ4cR1xZ8mPw==",
    security: "none",
  },
  {
    name: "London · Stream",
    protocol: "vmess",
    host: "lon1.exitnode.dev",
    port: 2053,
    country: "United Kingdom",
    countryCode: "GB",
    city: "London",
    provider: "Oracle Cloud",
    uuid: "e8b3d1a2-77c4-4f60-8b0d-2a5c9e13ff74",
    network: "ws",
    path: "/vm",
    wsHost: "lon1.exitnode.dev",
    security: "tls",
    sni: "lon1.exitnode.dev",
  },
];

let seedPromise: Promise<void> | null = null;

async function runSeed(): Promise<void> {
  await db
    .insert(settings)
    .values({ id: 1 })
    .onConflictDoNothing({ target: settings.id });

  const [{ count: nodeCount }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(nodes);

  if (nodeCount === 0) {
    const rows = SEED_NODES.map((node) => {
      const latency = simulateLatency({
        host: node.host,
        countryCode: node.countryCode,
        protocol: node.protocol,
      });
      return {
        ...node,
        network: node.network ?? "tcp",
        path: node.path ?? "/",
        security: node.security ?? "tls",
        latencyMs: latency.latencyMs,
        lossPct: latency.lossPct,
        latencySource: "simulated",
        lastCheckedAt: new Date(),
      };
    });
    const inserted = await db.insert(nodes).values(rows).returning({ id: nodes.id });
    const first = inserted[0]?.id ?? null;
    await db
      .update(settings)
      .set({
        activeNodeId: first,
        connected: first !== null,
        connectedAt: first !== null ? new Date() : null,
      })
      .where(sql`${settings.id} = 1`);
  }

  const [{ count: eventCount }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(events);

  if (eventCount === 0) {
    const now = Date.now();
    const seeds = [
      { level: "success", scope: "agent", message: "sing-box agent подключён как control-plane", offset: 1000 * 60 * 42 },
      { level: "info", scope: "routing", message: "Правила ChatGPT + Codex активны (rule_set: ai-openai)", offset: 1000 * 60 * 38 },
      { level: "success", scope: "exit", message: "Активный выход Frankfurt · AI-01, TLS Reality подтверждён", offset: 1000 * 60 * 31 },
      { level: "info", scope: "geo", message: "Проверка выхода: OpenAI отвечает 200 OK через выбранный узел", offset: 1000 * 60 * 22 },
      { level: "warn", scope: "health", message: "London · Stream: потеря пакетов 1%, узел помечен как резервный", offset: 1000 * 60 * 12 },
      { level: "info", scope: "config", message: "Конфиг пересобран: mixed-in :2080, TUN выключен", offset: 1000 * 60 * 4 },
    ];
    await db.insert(events).values(
      seeds.map((item) => ({
        level: item.level,
        scope: item.scope,
        message: item.message,
        createdAt: new Date(now - item.offset),
      })),
    );
  }
}

export function ensureSeeded(): Promise<void> {
  if (!seedPromise) {
    seedPromise = runSeed().catch((error) => {
      seedPromise = null;
      throw error;
    });
  }
  return seedPromise;
}
