import type { NewNodeRow } from "@/db/schema";

type ParsedNode = Omit<NewNodeRow, "id" | "createdAt">;

const COUNTRY_HINTS: { code: string; country: string; patterns: string[] }[] = [
  { code: "DE", country: "Germany", patterns: ["german", "frankfurt", "fra", "berlin", "герман"] },
  { code: "NL", country: "Netherlands", patterns: ["netherland", "amsterdam", "ams", "нидерланд"] },
  { code: "US", country: "United States", patterns: ["united states", "usa", "us-", "ashburn", "new york", "seattle", "dallas", "сша"] },
  { code: "GB", country: "United Kingdom", patterns: ["united kingdom", "london", "lon", "britain", "англи"] },
  { code: "JP", country: "Japan", patterns: ["japan", "tokyo", "tyo", "osaka", "япони"] },
  { code: "SG", country: "Singapore", patterns: ["singapore", "sgp", "сингапур"] },
  { code: "TR", country: "Türkiye", patterns: ["turkey", "türkiye", "istanbul", "турци"] },
  { code: "CH", country: "Switzerland", patterns: ["switzerland", "zurich", "цюрих"] },
  { code: "SE", country: "Sweden", patterns: ["sweden", "stockholm"] },
  { code: "FI", country: "Finland", patterns: ["finland", "helsinki"] },
  { code: "PL", country: "Poland", patterns: ["poland", "warsaw"] },
  { code: "CA", country: "Canada", patterns: ["canada", "toronto", "montreal"] },
  { code: "FR", country: "France", patterns: ["france", "paris"] },
  { code: "AE", country: "UAE", patterns: ["dubai", "uae", "emirates"] },
  { code: "KZ", country: "Kazakhstan", patterns: ["kazakh", "almaty"] },
];

export function inferRegion(name: string): { country: string; countryCode: string; city: string } {
  const haystack = name.toLowerCase();
  for (const hint of COUNTRY_HINTS) {
    if (hint.patterns.some((pattern) => haystack.includes(pattern))) {
      return { country: hint.country, countryCode: hint.code, city: "" };
    }
  }
  const codeMatch = name.match(/\b([A-Z]{2})\b/);
  if (codeMatch) {
    return { country: codeMatch[1], countryCode: codeMatch[1], city: "" };
  }
  return { country: "Unknown", countryCode: "XX", city: "" };
}

function defaultNode(name: string, protocol: string): ParsedNode {
  const region = inferRegion(name || protocol);
  return {
    name: name || `${protocol.toUpperCase()} exit`,
    protocol,
    host: "",
    port: 443,
    country: region.country,
    countryCode: region.countryCode,
    city: "",
    provider: "imported",
    uuid: "",
    password: "",
    method: "",
    network: "tcp",
    path: "/",
    wsHost: "",
    serviceName: "",
    security: "tls",
    sni: "",
    alpn: "",
    flow: "",
    publicKey: "",
    shortId: "",
    fingerprint: "chrome",
    obfs: "",
    obfsPassword: "",
    enabled: true,
    latencyMs: null,
    lossPct: 0,
    latencySource: "simulated",
  };
}

function safeDecode(value: string): string {
  try {
    return Buffer.from(value, "base64").toString("utf8");
  } catch {
    return "";
  }
}

function applyTransport(target: ParsedNode, params: URLSearchParams) {
  const type = (params.get("type") || params.get("network") || "tcp").toLowerCase();
  target.network = ["ws", "grpc", "http", "h2"].includes(type)
    ? type === "h2"
      ? "http"
      : type
    : "tcp";
  target.path = params.get("path") || "/";
  target.wsHost = params.get("host") || "";
  target.serviceName = params.get("serviceName") || params.get("service_name") || "";
  const security = (params.get("security") || "tls").toLowerCase();
  target.security = ["reality", "tls", "none"].includes(security) ? security : "tls";
  target.sni = params.get("sni") || params.get("peer") || "";
  target.alpn = params.get("alpn") || "";
  target.flow = params.get("flow") || "";
  target.fingerprint = params.get("fp") || "chrome";
  target.publicKey = params.get("pbk") || "";
  target.shortId = params.get("sid") || "";
  target.obfs = params.get("obfs") || "";
  target.obfsPassword = params.get("obfs-password") || params.get("obfs_password") || "";
}

function decodeName(raw: string, fallback: string): string {
  if (!raw) return fallback;
  try {
    return decodeURIComponent(raw.replace(/\+/g, " "));
  } catch {
    return raw;
  }
}

export type ParseResult = {
  nodes: ParsedNode[];
  errors: string[];
  skipped: number;
};

/** Parses sing-box / v2ray / clash style share links and base64 subscriptions. */
export function parseShareLinks(input: string): ParseResult {
  const errors: string[] = [];
  const nodes: ParsedNode[] = [];
  let skipped = 0;

  let text = input.trim();
  if (!text) return { nodes, errors: ["Пустой ввод"], skipped };

  if (!text.includes("://") && text.length > 24) {
    const decoded = safeDecode(text.replace(/\s+/g, ""));
    if (decoded.includes("://")) text = decoded;
  }

  const lines = text
    .split(/\r?\n|,(?=\w+:\/\/)/)
    .map((line) => line.trim())
    .filter(Boolean);

  for (const line of lines) {
    try {
      if (line.startsWith("vless://") || line.startsWith("trojan://")) {
        const url = new URL(line);
        const isVless = line.startsWith("vless://");
        const parsed = defaultNode(decodeName(url.hash.slice(1), isVless ? "VLESS" : "Trojan"), url.protocol.replace(":", ""));
        parsed.host = url.hostname;
        parsed.port = Number(url.port || 443);
        if (isVless) parsed.uuid = url.username;
        else parsed.password = decodeURIComponent(url.username);
        applyTransport(parsed, url.searchParams);
        nodes.push(parsed);
      } else if (line.startsWith("vmess://")) {
        const payload = line.slice("vmess://".length);
        const decoded = safeDecode(payload.split("#")[0]);
        if (!decoded.trim().startsWith("{")) throw new Error("vmess payload is not JSON");
        const json = JSON.parse(decoded) as Record<string, string | number>;
        const name = String(json.ps || "VMess exit");
        const parsed = defaultNode(name, "vmess");
        parsed.host = String(json.add || "");
        parsed.port = Number(json.port || 443);
        parsed.uuid = String(json.id || "");
        parsed.sni = String(json.sni || json.host || "");
        parsed.wsHost = String(json.host || "");
        parsed.path = String(json.path || "/");
        parsed.alpn = String(json.alpn || "");
        parsed.network = String(json.net || "tcp") === "ws" ? "ws" : String(json.net || "tcp") === "grpc" ? "grpc" : "tcp";
        parsed.security = String(json.tls || "") === "tls" ? "tls" : "none";
        if (!parsed.host || !parsed.uuid) throw new Error("vmess link without add/id");
        nodes.push(parsed);
      } else if (line.startsWith("ss://")) {
        const withoutScheme = line.slice(5);
        const name = decodeName(withoutScheme.split("#")[1] || "", "Shadowsocks exit");
        const body = withoutScheme.split("#")[0];
        let method = "";
        let password = "";
        let host = "";
        let port = 443;
        if (body.includes("@")) {
          const [credentials, endpoint] = body.split("@");
          const decoded = credentials.includes(":") ? credentials : safeDecode(credentials);
          const idx = decoded.indexOf(":");
          method = decoded.slice(0, idx);
          password = decoded.slice(idx + 1);
          const cleaned = endpoint.split("/")[0].split("?")[0];
          const lastColon = cleaned.lastIndexOf(":");
          host = cleaned.slice(0, lastColon);
          port = Number(cleaned.slice(lastColon + 1) || 8388);
          method = method.replace(/^.*:/, "");
        } else {
          const decoded = safeDecode(body.split("?")[0]);
          const at = decoded.lastIndexOf("@");
          const credentials = decoded.slice(0, at);
          const endpoint = decoded.slice(at + 1);
          const idx = credentials.indexOf(":");
          method = credentials.slice(0, idx);
          password = credentials.slice(idx + 1);
          const lastColon = endpoint.lastIndexOf(":");
          host = endpoint.slice(0, lastColon);
          port = Number(endpoint.slice(lastColon + 1) || 8388);
        }
        const parsed = defaultNode(name, "shadowsocks");
        parsed.host = host;
        parsed.port = port;
        parsed.method = method;
        parsed.password = password;
        parsed.security = "none";
        nodes.push(parsed);
      } else if (line.startsWith("hysteria2://") || line.startsWith("hy2://")) {
        const url = new URL(line.replace("hy2://", "hysteria2://"));
        const parsed = defaultNode(
          decodeName(url.hash.slice(1), "Hysteria2 exit"),
          "hysteria2",
        );
        parsed.host = url.hostname;
        parsed.port = Number(url.port || 443);
        parsed.password = decodeURIComponent(url.username || url.searchParams.get("auth") || "");
        parsed.sni = url.searchParams.get("sni") || "";
        parsed.obfs = url.searchParams.get("obfs") || "";
        parsed.obfsPassword = url.searchParams.get("obfs-password") || "";
        parsed.alpn = url.searchParams.get("alpn") || "h3";
        parsed.security = "tls";
        nodes.push(parsed);
      } else {
        skipped += 1;
      }
    } catch (error) {
      errors.push(
        `${line.slice(0, 32)}… → ${error instanceof Error ? error.message : "parse error"}`,
      );
    }
  }

  if (nodes.length === 0 && errors.length === 0) {
    errors.push("Не найдено поддерживаемых ссылок (vless, vmess, trojan, ss, hysteria2)");
  }

  return { nodes, errors, skipped };
}

/** Builds a portable share link for the selected node. */
export function buildShareLink(node: {
  name: string;
  protocol: string;
  host: string;
  port: number;
  uuid?: string;
  password?: string;
  method?: string;
  network?: string;
  path?: string;
  wsHost?: string;
  serviceName?: string;
  security?: string;
  sni?: string;
  alpn?: string;
  flow?: string;
  publicKey?: string;
  shortId?: string;
  fingerprint?: string;
  obfs?: string;
  obfsPassword?: string;
}): string {
  const namePart = encodeURIComponent(node.name);
  const network = node.network || "tcp";

  if (node.protocol === "vmess") {
    const payload = {
      v: "2",
      ps: node.name,
      add: node.host,
      port: String(node.port),
      id: node.uuid ?? "",
      aid: "0",
      scy: "auto",
      net: network,
      type: "none",
      host: node.wsHost ?? "",
      path: node.path ?? "/",
      tls: node.security === "tls" ? "tls" : "",
      sni: node.sni ?? "",
      alpn: node.alpn ?? "",
    };
    return `vmess://${Buffer.from(JSON.stringify(payload), "utf8").toString("base64")}`;
  }

  if (node.protocol === "shadowsocks") {
    const credentials = Buffer.from(`${node.method}:${node.password}`, "utf8").toString("base64url");
    return `ss://${credentials}@${node.host}:${node.port}#${namePart}`;
  }

  if (node.protocol === "hysteria2") {
    const params = new URLSearchParams({ sni: node.sni || node.host });
    if (node.obfs) {
      params.set("obfs", node.obfs);
      params.set("obfs-password", node.obfsPassword ?? "");
    }
    if (node.alpn) params.set("alpn", node.alpn);
    return `hysteria2://${encodeURIComponent(node.password ?? "")}@${node.host}:${node.port}?${params.toString()}#${namePart}`;
  }

  const params = new URLSearchParams({
    security: node.security || "tls",
    type: network,
    sni: node.sni || node.host,
  });
  if (node.security === "reality") {
    params.set("pbk", node.publicKey ?? "");
    params.set("sid", node.shortId ?? "");
    params.set("fp", node.fingerprint || "chrome");
    if (node.flow) params.set("flow", node.flow);
  }
  if (network === "ws") {
    params.set("path", node.path || "/");
    if (node.wsHost) params.set("host", node.wsHost);
  }
  if (network === "grpc" && node.serviceName) params.set("serviceName", node.serviceName);
  if (node.alpn) params.set("alpn", node.alpn);

  const userInfo =
    node.protocol === "trojan" ? encodeURIComponent(node.password ?? "") : node.uuid ?? "";
  return `${node.protocol}://${userInfo}@${node.host}:${node.port}?${params.toString()}#${namePart}`;
}
