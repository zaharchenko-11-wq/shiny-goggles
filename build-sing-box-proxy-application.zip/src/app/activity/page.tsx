import type { Metadata } from "next";
import { getState } from "@/lib/data";
import { clockTime, relativeTime } from "@/lib/format";
import { OpenAiCheck, ProbeButton, RefreshButton } from "@/components/dashboard-widgets";
import { EmptyState, Label, LevelBadge, Metric, Panel } from "@/components/ui";

export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Журнал — exitnode" };

export default async function ActivityPage() {
  const { events, latestEgress, activeNode, settings } = await getState();
  const counts = {
    success: events.filter((event) => event.level === "success").length,
    warn: events.filter((event) => event.level === "warn").length,
    error: events.filter((event) => event.level === "error").length,
  };
  const scopes = Array.from(new Set(events.map((event) => event.scope)));

  return (
    <div className="animate-fade-up space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="label">audit · telemetry</p>
          <h1 className="mt-2 text-[26px] font-medium leading-[1.1] tracking-[-0.035em] sm:text-[30px]">
            Журнал
          </h1>
          <p className="mt-1.5 max-w-2xl text-[12.5px] leading-relaxed text-muted">
            Все переключения, изменения правил и проверки выхода. Журнал хранится в PostgreSQL и
            обновляется после каждого действия в панели.
          </p>
        </div>
        <RefreshButton label="Обновить" />
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Metric label="событий" value={events.length} hint="последние 40 записей" />
        <Metric label="успешно" value={counts.success} hint="exit и правила применены" accent />
        <Metric label="предупреждения" value={counts.warn} hint="потери, недоступные узлы" />
        <Metric label="ошибки" value={counts.error} hint="неудачные проверки" />
      </div>

      <div className="grid gap-4 lg:grid-cols-[1.6fr_1fr]">
        <Panel className="overflow-hidden">
          <div className="flex items-center justify-between border-b border-line px-4 py-2.5">
            <Label>timeline</Label>
            <div className="flex items-center gap-1.5">
              {scopes.slice(0, 5).map((scope) => (
                <span key={scope} className="chip !h-[18px] !text-[9px]">
                  {scope}
                </span>
              ))}
            </div>
          </div>
          {events.length === 0 ? (
            <div className="p-4">
              <EmptyState
                title="Событий пока нет"
                hint="Переключите узел или измените правила — записи появятся здесь."
              />
            </div>
          ) : (
            <div className="divide-y divide-linesoft">
              {events.map((event) => (
                <div key={event.id} className="flex items-start gap-3 px-4 py-3">
                  <div className="mono w-[54px] shrink-0 pt-0.5 text-[10px] text-dim">
                    <div suppressHydrationWarning>{clockTime(event.createdAt)}</div>
                    <div className="mt-0.5 text-[9px] text-[#3f5049]" suppressHydrationWarning>
                      {relativeTime(event.createdAt)}
                    </div>
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <LevelBadge level={event.level} />
                      <span className="chip !h-[17px] !text-[9px]">{event.scope}</span>
                      {event.nodeName ? (
                        <span className="mono truncate text-[9.5px] text-dim">{event.nodeName}</span>
                      ) : null}
                    </div>
                    <p className="mt-1.5 text-[12.5px] leading-snug text-muted">{event.message}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Panel>

        <div className="flex flex-col gap-3">
          <Panel className="p-5">
            <p className="text-[14px] font-medium">Диагностика</p>
            <p className="mt-0.5 text-[11.5px] text-dim">
              Проверки выполняются с хоста панели. Exit:{" "}
              <span className="mono text-muted">
                {settings.connected ? activeNode?.name ?? "—" : "direct"}
              </span>
            </p>
            <div className="mt-3 flex flex-col gap-2">
              <OpenAiCheck />
              <ProbeButton label="Проверить задержки пула" />
            </div>
          </Panel>

          <Panel className="p-5">
            <p className="text-[14px] font-medium">Последний geo-замер</p>
            {latestEgress ? (
              <div className="mt-3 space-y-2">
                <p className="mono text-[20px] leading-none text-ink">{latestEgress.ip}</p>
                <div className="flex flex-wrap gap-1.5">
                  {latestEgress.country ? (
                    <span className="chip chip-lime">{latestEgress.country}</span>
                  ) : null}
                  {latestEgress.city ? <span className="chip">{latestEgress.city}</span> : null}
                  {latestEgress.asn ? <span className="chip">{latestEgress.asn}</span> : null}
                  <span className="chip">{latestEgress.source}</span>
                </div>
                <p className="text-[11px] leading-relaxed text-dim">{latestEgress.org || "—"}</p>
                <p className="text-[10.5px] text-dim" suppressHydrationWarning>
                  {relativeTime(latestEgress.createdAt)}
                </p>
              </div>
            ) : (
              <p className="mt-3 text-[11.5px] leading-relaxed text-dim">
                Гео-проверок ещё не было. Откройте обзор и нажмите «Проверить» в карточке внешнего IP.
              </p>
            )}
          </Panel>

          <Panel className="p-5">
            <p className="text-[14px] font-medium">Хранение</p>
            <p className="mt-1.5 text-[11.5px] leading-relaxed text-dim">
              Панель — control plane: узлы, правила и журнал в PostgreSQL. Туннель поднимает
              sing-box CLI на устройстве. Журнал ограничен 40 последними записями на экране.
            </p>
            <div className="mono mt-3 flex items-center justify-between text-[10px] text-dim">
              <span>table: events</span>
              <span>{events.length} rows</span>
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}
