import type { Metadata } from "next";
import Link from "next/link";
import { getState } from "@/lib/data";
import { enabledRouteGroups } from "@/lib/ai-routes";
import { buildRunScript, buildSingBoxConfig } from "@/lib/singbox";
import { ConfigView } from "@/components/config-view";
import { Flag } from "@/components/ui";
import { RefreshButton } from "@/components/dashboard-widgets";

export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Конфиг sing-box — exitnode" };

export default async function ConfigPage() {
  const state = await getState();
  const { config, activeTag, exitTags } = buildSingBoxConfig(
    state.nodes,
    state.settings,
    state.activeNode?.id ?? null,
  );
  const groups = enabledRouteGroups(state.settings);
  const json = JSON.stringify(config, null, 2);
  const script = buildRunScript();

  return (
    <div className="animate-fade-up space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="label">export · sing-box</p>
          <h1 className="mt-2 text-[26px] font-medium leading-[1.1] tracking-[-0.035em] sm:text-[30px]">
            Конфиг sing-box
          </h1>
          <p className="mt-1.5 max-w-2xl text-[12.5px] leading-relaxed text-muted">
            Готовый конфиг с selector, urltest и AI-правилами. Скопируйте или скачайте файл и запустите
            агентом на своём устройстве.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="hidden items-center gap-2 rounded-lg border border-line bg-white/[0.02] px-2.5 py-1.5 sm:flex">
            <Flag code={state.activeNode?.countryCode ?? "XX"} size="sm" />
            <span className="mono text-[11px] text-muted">
              {state.settings.connected ? state.activeNode?.name ?? "—" : "direct"}
            </span>
          </div>
          <RefreshButton label="Пересобрать" />
          <Link href="/routing" className="btn btn-lime">
            Правила
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { label: "exit outbounds", value: String(exitTags.length) },
          { label: "route groups", value: `${groups.length}/5` },
          { label: "active tag", value: activeTag },
          { label: "inbound", value: state.settings.tunEnabled ? "mixed + tun" : "mixed only" },
        ].map((item) => (
          <div key={item.label} className="panel px-4 py-3">
            <p className="label">{item.label}</p>
            <p className="mono mt-1.5 truncate text-[12.5px] text-ink">{item.value}</p>
          </div>
        ))}
      </div>

      <ConfigView
        json={json}
        script={script}
        activeTag={activeTag}
        nodeCount={exitTags.length}
        groups={groups.length}
        mixedPort={state.settings.mixedPort}
        tunEnabled={state.settings.tunEnabled}
      />
    </div>
  );
}
