import type { Metadata } from "next";
import { getState } from "@/lib/data";
import { NodesManager } from "@/components/nodes-manager";
import { Label } from "@/components/ui";
import { RefreshButton } from "@/components/dashboard-widgets";

export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Выходные узлы — exitnode" };

export default async function NodesPage() {
  const { nodes, settings, activeNode } = await getState();

  return (
    <div className="animate-fade-up space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="label">пул выходных ip</p>
          <h1 className="mt-2 text-[26px] font-medium leading-[1.1] tracking-[-0.035em] sm:text-[30px]">
            Выходные узлы
          </h1>
          <p className="mt-1.5 max-w-2xl text-[12.5px] leading-relaxed text-muted">
            Каждый узел превращается в outbound sing-box. Переключатель меняет default у selector
            <span className="mono text-ink/80"> ai-exit</span>, а конфиг пересобирается автоматически.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="hidden flex-col items-end sm:flex">
            <Label>активный тег</Label>
            <span className="mono mt-1 text-[11px] text-muted">
              {activeNode && settings.connected ? nodeTagLabel(activeNode.id, activeNode.name) : "direct"}
            </span>
          </div>
          <RefreshButton label="Обновить" />
        </div>
      </div>

      <NodesManager
        nodes={nodes}
        activeId={settings.activeNodeId}
        connected={settings.connected}
      />
    </div>
  );
}

function nodeTagLabel(id: number, name: string): string {
  const slug = name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "")
    .slice(0, 28);
  return `node-${id}-${slug || "exit"}`;
}
