import { getState, logEvent } from "@/lib/data";
import { probeEndpoint } from "@/lib/net";

export const dynamic = "force-dynamic";

const TARGETS = [
  { label: "ChatGPT", url: "https://chatgpt.com/favicon.ico" },
  { label: "OpenAI API", url: "https://api.openai.com/v1/models" },
  { label: "Codex backend", url: "https://chatgpt.com/backend-api/codex" },
];

export async function POST() {
  const state = await getState();
  const results = await Promise.all(
    TARGETS.map(async (target) => {
      const probe = await probeEndpoint(target.url);
      return {
        label: target.label,
        url: target.url,
        reachable: probe.status > 0 && probe.status < 500,
        status: probe.status,
        ms: probe.ms,
      };
    }),
  );

  const reachable = results.filter((item) => item.reachable).length;
  const exitLabel = state.activeNode ? state.activeNode.name : "direct";
  await logEvent({
    level: reachable === results.length ? "success" : reachable > 0 ? "warn" : "error",
    scope: "geo",
    message: `Проверка OpenAI через ${exitLabel}: ${reachable}/${results.length} эндпоинтов отвечают`,
    nodeName: state.activeNode?.name ?? null,
  });

  return Response.json({
    exit: state.activeNode?.name ?? "direct",
    results,
    checkedAt: new Date().toISOString(),
  });
}
