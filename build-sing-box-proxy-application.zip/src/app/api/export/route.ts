import { getState } from "@/lib/data";
import { buildRunScript, buildSingBoxConfig } from "@/lib/singbox";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const format = searchParams.get("format") ?? "json";
  const download = searchParams.get("download") === "1";
  const state = await getState();
  const { config } = buildSingBoxConfig(state.nodes, state.settings, state.activeNode?.id ?? null);

  if (format === "sh") {
    const script = buildRunScript();
    return new Response(script, {
      headers: {
        "content-type": "text/x-shellscript; charset=utf-8",
        ...(download
          ? { "content-disposition": 'attachment; filename="exitnode-start.sh"' }
          : {}),
      },
    });
  }

  const body = JSON.stringify(config, null, 2);
  return new Response(body, {
    headers: {
      "content-type": "application/json; charset=utf-8",
      ...(download
        ? { "content-disposition": 'attachment; filename="sing-box-config.json"' }
        : {}),
    },
  });
}
