import { getNode, logEvent, touchSettings } from "@/lib/data";
import { nodeTag } from "@/lib/singbox";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  let body: Record<string, unknown> = {};
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    body = {};
  }

  const action = typeof body.action === "string" ? body.action : "connect";

  if (action === "disconnect") {
    await touchSettings({ connected: false, connectedAt: null });
    await logEvent({
      level: "warn",
      scope: "exit",
      message: "Выход отключён, трафик переведён напрямую (direct)",
    });
    return Response.json({ ok: true, connected: false });
  }

  const nodeId = Number(body.nodeId);
  if (!Number.isFinite(nodeId)) {
    return Response.json({ error: "Выберите узел для переключения" }, { status: 400 });
  }

  const node = await getNode(nodeId);
  if (!node) return Response.json({ error: "Узел не найден" }, { status: 404 });
  if (!node.enabled) {
    return Response.json({ error: "Узел отключён — сначала включите его" }, { status: 409 });
  }

  await touchSettings({
    activeNodeId: node.id,
    connected: true,
    connectedAt: new Date(),
  });

  await logEvent({
    level: "success",
    scope: "exit",
    message: `Выход переключён на ${node.name} · ${node.country} · ${node.host}:${node.port}`,
    nodeName: node.name,
  });

  return Response.json({
    ok: true,
    connected: true,
    node,
    tag: nodeTag(node),
  });
}
