import { db } from "@/db";
import { nodes, settings } from "@/db/schema";
import { getNode, logEvent } from "@/lib/data";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export async function PATCH(request: Request, { params }: Params) {
  const { id } = await params;
  const nodeId = Number(id);
  if (!Number.isFinite(nodeId)) {
    return Response.json({ error: "Неверный id" }, { status: 400 });
  }

  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ error: "Некорректный JSON" }, { status: 400 });
  }

  const node = await getNode(nodeId);
  if (!node) return Response.json({ error: "Узел не найден" }, { status: 404 });

  const patch: Record<string, unknown> = {};
  if (typeof body.enabled === "boolean") patch.enabled = body.enabled;
  if (typeof body.name === "string" && body.name.trim()) patch.name = body.name.trim();
  if (typeof body.latencyMs === "number") patch.latencyMs = body.latencyMs;

  if (Object.keys(patch).length === 0) {
    return Response.json({ error: "Нет полей для обновления" }, { status: 400 });
  }

  const [updated] = await db
    .update(nodes)
    .set(patch)
    .where(eq(nodes.id, nodeId))
    .returning();

  if (typeof body.enabled === "boolean") {
    await logEvent({
      level: body.enabled ? "success" : "warn",
      scope: "nodes",
      message: `Узел ${updated.name} ${body.enabled ? "включён" : "отключён"}`,
      nodeName: updated.name,
    });
  }

  return Response.json({ node: updated });
}

export async function DELETE(_request: Request, { params }: Params) {
  const { id } = await params;
  const nodeId = Number(id);
  if (!Number.isFinite(nodeId)) {
    return Response.json({ error: "Неверный id" }, { status: 400 });
  }

  const node = await getNode(nodeId);
  if (!node) return Response.json({ error: "Узел не найден" }, { status: 404 });

  await db.delete(nodes).where(eq(nodes.id, nodeId));

  const [current] = await db.select().from(settings).where(eq(settings.id, 1)).limit(1);
  if (current?.activeNodeId === nodeId) {
    const remaining = await db.select({ id: nodes.id }).from(nodes).limit(1);
    await db
      .update(settings)
      .set({
        activeNodeId: remaining[0]?.id ?? null,
        connected: Boolean(remaining[0]),
        connectedAt: remaining[0] ? new Date() : null,
      })
      .where(eq(settings.id, 1));
  }

  await logEvent({
    level: "warn",
    scope: "nodes",
    message: `Узел ${node.name} удалён из пула`,
    nodeName: node.name,
  });

  return Response.json({ ok: true });
}
