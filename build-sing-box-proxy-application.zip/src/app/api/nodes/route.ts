import { db } from "@/db";
import { nodes } from "@/db/schema";
import { getState, logEvent } from "@/lib/data";
import { simulateLatency } from "@/lib/net";
import { inferRegion } from "@/lib/links";

export const dynamic = "force-dynamic";

const PROTOCOLS = ["vless", "vmess", "trojan", "shadowsocks", "hysteria2"];

function str(value: unknown, fallback = ""): string {
  return typeof value === "string" ? value.trim() : fallback;
}

export async function GET() {
  const state = await getState();
  return Response.json({ nodes: state.nodes });
}

export async function POST(request: Request) {
  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ error: "Некорректный JSON" }, { status: 400 });
  }

  const host = str(body.host);
  const name = str(body.name);
  const protocol = str(body.protocol, "vless");

  if (!host) return Response.json({ error: "Укажите адрес сервера (host)" }, { status: 400 });
  if (!PROTOCOLS.includes(protocol)) {
    return Response.json({ error: "Неподдерживаемый протокол" }, { status: 400 });
  }

  const port = Number(body.port) || 443;
  if (port < 1 || port > 65535) {
    return Response.json({ error: "Порт вне диапазона 1–65535" }, { status: 400 });
  }

  const region = inferRegion(name || host);
  const country = str(body.country, region.country);
  const countryCode = str(body.countryCode, region.countryCode).toUpperCase().slice(0, 2);
  const latency = simulateLatency({ host, countryCode, protocol });

  try {
    const [created] = await db
      .insert(nodes)
      .values({
        name: name || `${host}:${port}`,
        protocol,
        host,
        port,
        country,
        countryCode: countryCode || "XX",
        city: str(body.city),
        provider: str(body.provider, "self-hosted"),
        uuid: str(body.uuid),
        password: str(body.password),
        method: str(body.method),
        network: ["tcp", "ws", "grpc", "http"].includes(str(body.network))
          ? str(body.network)
          : "tcp",
        path: str(body.path, "/") || "/",
        wsHost: str(body.wsHost),
        sni: str(body.sni),
        security: ["tls", "reality", "none"].includes(str(body.security))
          ? str(body.security)
          : "tls",
        alpn: str(body.alpn),
        flow: str(body.flow),
        publicKey: str(body.publicKey),
        shortId: str(body.shortId),
        fingerprint: str(body.fingerprint, "chrome") || "chrome",
        obfs: str(body.obfs),
        obfsPassword: str(body.obfsPassword),
        latencyMs: latency.latencyMs,
        lossPct: latency.lossPct,
        latencySource: "simulated",
        lastCheckedAt: new Date(),
      })
      .returning();

    await logEvent({
      level: "success",
      scope: "nodes",
      message: `Добавлен узел ${created.name} (${created.protocol.toUpperCase()} · ${created.country})`,
      nodeName: created.name,
    });

    return Response.json({ node: created }, { status: 201 });
  } catch {
    return Response.json({ error: "Не удалось сохранить узел" }, { status: 500 });
  }
}
