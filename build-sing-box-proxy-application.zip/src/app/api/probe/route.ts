import { db } from "@/db";
import { nodes } from "@/db/schema";
import { getSettingsRow, getState, logEvent } from "@/lib/data";
import { probeNode } from "@/lib/net";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  let body: Record<string, unknown> = {};
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    body = {};
  }

  const settings = await getSettingsRow();
  const mode = settings.telemetryMode === "tcp" ? "tcp" : "simulated";
  const state = await getState();
  const singleId = Number(body.id);

  const targets = Number.isFinite(singleId)
    ? state.nodes.filter((node) => node.id === singleId)
    : state.nodes;

  if (targets.length === 0) {
    return Response.json({ error: "Нет узлов для проверки" }, { status: 404 });
  }

  const results = await Promise.all(
    targets.map(async (node) => {
      const result = await probeNode(node, mode);
      await db
        .update(nodes)
        .set({
          latencyMs: result.latencyMs,
          lossPct: result.lossPct,
          latencySource: result.source,
          lastCheckedAt: new Date(),
        })
        .where(eq(nodes.id, node.id));
      return { id: node.id, ...result };
    }),
  );

  const reachable = results.filter((item) => item.latencyMs !== null).length;
  await logEvent({
    level: reachable === results.length ? "success" : "warn",
    scope: "health",
    message: `Проверка задержек: ${reachable}/${results.length} узлов доступны (${mode === "tcp" ? "TCP handshake" : "demo telemetry"})`,
  });

  return Response.json({ mode, results });
}
