import { db } from "@/db";
import { egressChecks } from "@/db/schema";
import { getState, logEvent } from "@/lib/data";
import { detectEgress } from "@/lib/net";

export const dynamic = "force-dynamic";

export async function GET() {
  const state = await getState();
  return Response.json({ egress: state.latestEgress });
}

export async function POST() {
  const state = await getState();
  const egress = await detectEgress();

  if (!egress) {
    await logEvent({
      level: "warn",
      scope: "geo",
      message: "Не удалось определить внешний IP: гео-сервисы недоступны",
    });
    return Response.json(
      { error: "Гео-сервис недоступен. Проверьте сеть хоста и повторите." },
      { status: 503 },
    );
  }

  const [saved] = await db
    .insert(egressChecks)
    .values({
      ip: egress.ip,
      country: egress.country,
      city: egress.city,
      org: egress.org,
      asn: egress.asn,
      source: egress.provider,
      latencyMs: egress.latencyMs,
    })
    .returning();

  const exitLabel = state.activeNode
    ? `активный выход ${state.activeNode.name}`
    : "прямое подключение";
  await logEvent({
    level: "success",
    scope: "geo",
    message: `Внешний IP ${egress.ip}${egress.country ? ` · ${egress.country}` : ""} (${exitLabel})`,
  });

  return Response.json({ egress: saved });
}
