import { db } from "@/db";
import { nodes } from "@/db/schema";
import { logEvent } from "@/lib/data";
import { parseShareLinks } from "@/lib/links";
import { simulateLatency } from "@/lib/net";

export const dynamic = "force-dynamic";

const UA = "sing-box/1.11 exitnode-control-plane";

export async function POST(request: Request) {
  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ error: "Некорректный JSON" }, { status: 400 });
  }

  let payload = typeof body.text === "string" ? body.text : "";
  const url = typeof body.url === "string" ? body.url.trim() : "";

  if (url) {
    if (!/^https?:\/\//i.test(url)) {
      return Response.json({ error: "Ссылка подписки должна начинаться с http(s)://" }, { status: 400 });
    }
    try {
      const response = await fetch(url, {
        cache: "no-store",
        headers: { "user-agent": UA },
        signal: AbortSignal.timeout(9000),
      });
      if (!response.ok) {
        return Response.json(
          { error: `Подписка ответила ${response.status}` },
          { status: 400 },
        );
      }
      payload = await response.text();
    } catch {
      return Response.json(
        { error: "Не удалось скачать подписку (таймаут или сеть недоступна)" },
        { status: 400 },
      );
    }
  }

  if (!payload.trim()) {
    return Response.json({ error: "Вставьте ссылки или URL подписки" }, { status: 400 });
  }

  const parsed = parseShareLinks(payload);
  if (parsed.nodes.length === 0) {
    return Response.json({ error: parsed.errors[0] ?? "Ссылки не распознаны", errors: parsed.errors }, { status: 400 });
  }

  const existing = await db.select({ host: nodes.host, port: nodes.port }).from(nodes);
  const known = new Set(existing.map((item) => `${item.host}:${item.port}`));

  const inserted: string[] = [];
  let duplicates = 0;

  for (const parsedNode of parsed.nodes.slice(0, 50)) {
    if (!parsedNode.host) continue;
    const key = `${parsedNode.host}:${parsedNode.port}`;
    if (known.has(key)) {
      duplicates += 1;
      continue;
    }
    known.add(key);
    const latency = simulateLatency({
      host: parsedNode.host,
      countryCode: parsedNode.countryCode ?? "XX",
      protocol: parsedNode.protocol,
    });
    const [row] = await db
      .insert(nodes)
      .values({
        ...parsedNode,
        latencyMs: latency.latencyMs,
        lossPct: latency.lossPct,
        latencySource: "simulated",
        lastCheckedAt: new Date(),
      })
      .returning({ id: nodes.id, name: nodes.name });
    inserted.push(row.name);
  }

  if (inserted.length > 0) {
    await logEvent({
      level: "success",
      scope: "import",
      message: `Импортировано ${inserted.length} узлов${duplicates ? `, пропущено дублей: ${duplicates}` : ""}`,
    });
  } else {
    await logEvent({
      level: "warn",
      scope: "import",
      message: `Все ${duplicates} узлов уже есть в пуле`,
    });
  }

  return Response.json({ ok: true, inserted, duplicates, errors: parsed.errors });
}
