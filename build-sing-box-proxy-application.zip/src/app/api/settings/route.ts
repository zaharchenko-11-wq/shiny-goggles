import { getSettingsRow, logEvent, touchSettings } from "@/lib/data";
import type { SettingsRow } from "@/db/schema";
import { enabledRouteGroups } from "@/lib/ai-routes";

export const dynamic = "force-dynamic";

const BOOLEAN_KEYS: (keyof SettingsRow)[] = [
  "tunEnabled",
  "autoSelect",
  "killSwitch",
  "routeChatGPT",
  "routeCodex",
  "routeAnthropic",
  "routeGoogle",
  "routeStreaming",
  "ruleSetMode",
];

export async function GET() {
  return Response.json({ settings: await getSettingsRow() });
}

export async function PATCH(request: Request) {
  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return Response.json({ error: "Некорректный JSON" }, { status: 400 });
  }

  const patch: Partial<SettingsRow> = {};
  for (const key of BOOLEAN_KEYS) {
    if (typeof body[key] === "boolean") {
      (patch as Record<string, unknown>)[key] = body[key];
    }
  }

  if (body.mixedPort !== undefined) {
    const port = Number(body.mixedPort);
    if (!Number.isInteger(port) || port < 1024 || port > 65535) {
      return Response.json({ error: "Порт должен быть 1024–65535" }, { status: 400 });
    }
    patch.mixedPort = port;
  }

  if (body.clashPort !== undefined) {
    const port = Number(body.clashPort);
    if (!Number.isInteger(port) || port < 1024 || port > 65535) {
      return Response.json({ error: "Порт Clash API должен быть 1024–65535" }, { status: 400 });
    }
    patch.clashPort = port;
  }

  if (typeof body.dnsStrategy === "string") {
    if (!["ipv4_only", "prefer_ipv4", "prefer_ipv6", "ipv6_only"].includes(body.dnsStrategy)) {
      return Response.json({ error: "Неизвестная DNS-стратегия" }, { status: 400 });
    }
    patch.dnsStrategy = body.dnsStrategy;
  }

  if (typeof body.telemetryMode === "string") {
    if (!["simulated", "tcp"].includes(body.telemetryMode)) {
      return Response.json({ error: "Неизвестный режим телеметрии" }, { status: 400 });
    }
    patch.telemetryMode = body.telemetryMode;
  }

  if (typeof body.remoteDns === "string" && body.remoteDns.trim()) {
    patch.remoteDns = body.remoteDns.trim();
  }
  if (typeof body.directDns === "string" && body.directDns.trim()) {
    patch.directDns = body.directDns.trim();
  }

  if (Object.keys(patch).length === 0) {
    return Response.json({ error: "Нет изменений" }, { status: 400 });
  }

  const updated = await touchSettings(patch);
  const groups = enabledRouteGroups(updated).map((group) => group.label);
  await logEvent({
    level: "info",
    scope: "config",
    message: `Настройки обновлены · mixed :${updated.mixedPort} · TUN ${updated.tunEnabled ? "on" : "off"} · правила: ${groups.join(", ") || "нет"}`,
  });

  return Response.json({ settings: updated });
}
