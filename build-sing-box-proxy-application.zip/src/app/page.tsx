import Link from "next/link";
import type { Metadata } from "next";
import { getState } from "@/lib/data";
import { enabledRouteGroups } from "@/lib/ai-routes";
import { protocolLabel, relativeTime } from "@/lib/format";
import { nodeTag } from "@/lib/singbox";
import { CopyButton, ConnectSwitch, EgressCard, OpenAiCheck, ProbeButton, QuickSwitch, RouteQuickToggles } from "@/components/dashboard-widgets";
import { EmptyState, Flag, Label, LatencyMeter, LevelBadge, Metric, Panel, StatusDot } from "@/components/ui";

export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Обзор — exitnode" };

export default async function OverviewPage() {
  const { settings, nodes, activeNode, events, latestEgress } = await getState();
  const groups = enabledRouteGroups(settings);
  const enabledNodes = nodes.filter((node) => node.enabled);
  const avgLatency =
    enabledNodes.length > 0
      ? Math.round(
          enabledNodes.reduce((sum, node) => sum + (node.latencyMs ?? 260), 0) / enabledNodes.length,
        )
      : null;
  const connected = settings.connected && activeNode !== null;

  const ready = [
    { label: "Выходной узел выбран", ok: activeNode !== null, hint: activeNode ? activeNode.name : "пул пуст" },
    { label: "Split-правила ChatGPT/Codex", ok: groups.length > 0, hint: `${groups.length} групп доменов` },
    { label: "Локальный mixed-прокси", ok: connected, hint: `127.0.0.1:${settings.mixedPort}` },
    { label: "TUN / системный трафик", ok: settings.tunEnabled, hint: settings.tunEnabled ? "auto_route включён" : "только приложения через прокси" },
  ];

  return (
    <div className="animate-fade-up space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <span className="live-dot" />
            <p className="label">control plane · live</p>
          </div>
          <h1 className="mt-2 text-[26px] font-medium leading-[1.1] tracking-[-0.035em] sm:text-[31px]">
            Смена выходного IP для ChatGPT и Codex
          </h1>
          <p className="mt-1.5 max-w-xl text-[12.5px] leading-relaxed text-muted">
            sing-box маршрутизирует домены OpenAI через выбранный узел, остальной трафик идёт
            напрямую. Панель хранит пул, проверяет задержки и собирает готовый конфиг.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <ProbeButton />
          <Link href="/nodes" className="btn btn-lime">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-3.5 w-3.5">
              <path d="M12 5v14M5 12h14" />
            </svg>
            Новый узел
          </Link>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1.55fr_1fr]">
        <Panel className="overflow-hidden p-5 sm:p-6">
          <div className="pointer-events-none absolute -right-16 -top-20 h-56 w-56 rounded-full bg-lime/[0.07] blur-3xl" />
          <div className="relative flex items-start justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <StatusDot live={connected} />
                <p className="label">активный выход</p>
              </div>
              <div className="mt-3 flex items-center gap-3">
                <span className="grid h-11 w-11 place-items-center rounded-xl border border-line bg-white/[0.03]">
                  <Flag code={activeNode?.countryCode ?? "XX"} size="lg" />
                </span>
                <div className="min-w-0">
                  <p className="truncate text-[22px] font-medium leading-tight tracking-[-0.03em] sm:text-[25px]">
                    {activeNode?.name ?? "Нет узла"}
                  </p>
                  <p className="mono mt-1 text-[11px] text-muted">
                    {activeNode
                      ? `${activeNode.country}${activeNode.city ? ` · ${activeNode.city}` : ""} · ${activeNode.provider}`
                      : "добавьте первый exit в пул"}
                  </p>
                </div>
              </div>
            </div>
            <div className="hidden flex-col items-end gap-1.5 sm:flex">
              <span className={`chip ${connected ? "chip-lime" : ""}`}>
                {connected ? "outbound live" : "bypass"}
              </span>
              <span className="chip">mixed :{settings.mixedPort}</span>
              {settings.tunEnabled ? <span className="chip chip-warn">tun on</span> : null}
            </div>
          </div>

          {activeNode ? (
            <>
              <div className="relative mt-5 flex flex-wrap items-center gap-2">
                <span className="chip chip-lime">{protocolLabel(activeNode.protocol)}</span>
                <span className="chip">{activeNode.security}</span>
                <span className="chip">{activeNode.network}</span>
                <span className="chip">loss {activeNode.lossPct}%</span>
                <div className="ml-auto flex items-center gap-3">
                  <LatencyMeter ms={activeNode.latencyMs} />
                </div>
              </div>

              <div className="panel-quiet relative mt-3 flex items-center gap-2 px-3 py-2">
                <span className="label shrink-0">endpoint</span>
                <span className="mono truncate text-[12px] text-ink/90">
                  {activeNode.host}:{activeNode.port}
                </span>
                <span className="ml-auto shrink-0">
                  <CopyButton
                    text={`${activeNode.host}:${activeNode.port}`}
                    label="copy"
                    className="btn btn-ghost btn-sm !h-7 !px-2 !text-[10px]"
                  />
                </span>
              </div>

              <div className="relative mt-3 flex flex-wrap gap-2">
                <span className="chip">tag {nodeTag(activeNode)}</span>
                <span className="chip">selector ai-exit</span>
                <span className="chip">dns {settings.dnsStrategy}</span>
              </div>
            </>
          ) : (
            <div className="relative mt-5 rounded-xl border border-dashed border-line px-4 py-6 text-center text-[12.5px] text-dim">
              Пул пуст — добавьте VLESS / Hysteria2 / Trojan узел или импортируйте подписку.
            </div>
          )}

          <div className="relative mt-5 flex flex-col gap-3 border-t border-linesoft pt-4 sm:flex-row sm:items-center sm:justify-between">
            <ConnectSwitch nodeId={activeNode?.id ?? null} connected={connected} />
            <div className="flex flex-wrap items-center gap-2">
              <OpenAiCheck />
              <Link href="/config" className="btn">
                Конфиг
              </Link>
            </div>
          </div>
        </Panel>

        <div className="flex flex-col gap-4">
          <EgressCard
            initial={latestEgress}
            nodeName={activeNode?.name ?? "direct"}
            connected={connected}
          />
          <Panel className="p-4">
            <div className="flex items-center justify-between">
              <Label>быстрый старт</Label>
              <span className="chip">3 шага</span>
            </div>
            <ol className="mt-3 space-y-2.5">
              {[
                "Выберите exit в пуле и включите тумблер",
                "Экспортируйте конфиг в sing-box CLI",
                "Проверьте IP и доступ к chatgpt.com",
              ].map((step, index) => (
                <li key={step} className="flex items-start gap-2.5 text-[12px] leading-snug text-muted">
                  <span className="mono mt-px grid h-[18px] w-[18px] shrink-0 place-items-center rounded-full border border-line bg-white/[0.03] text-[9.5px] text-lime">
                    {index + 1}
                  </span>
                  {step}
                </li>
              ))}
            </ol>
            <Link href="/config" className="mono mt-3 inline-flex text-[10.5px] uppercase tracking-[0.12em] text-lime hover:underline">
              открыть конфиг и команды →
            </Link>
          </Panel>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Metric
          label="узлов в пуле"
          value={nodes.length}
          hint={`${enabledNodes.length} активных · ${nodes.length - enabledNodes.length} выключено`}
        />
        <Metric
          label="средняя задержка"
          value={avgLatency ?? "—"}
          hint={avgLatency ? "мс до выхода · demo telemetry" : "нет данных"}
          accent
        />
        <Metric
          label="правил маршрутизации"
          value={groups.length}
          hint={groups.length > 0 ? groups.map((group) => group.label).join(" · ") : "правила выключены"}
        />
        <Metric
          label="прокси / dns"
          value={`:${settings.mixedPort}`}
          hint={`${settings.tunEnabled ? "TUN auto_route" : "mixed inbound"} · ${settings.dnsStrategy}`}
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-[1.3fr_1fr]">
        <Panel className="p-5">
          <div className="flex items-center justify-between gap-2">
            <div>
              <p className="text-[14px] font-medium">Быстрое переключение</p>
              <p className="mt-0.5 text-[11.5px] text-dim">
                Клик переключает selector <span className="mono text-muted">ai-exit</span> на выбранный узел
              </p>
            </div>
            <Link href="/nodes" className="btn btn-sm">
              Все узлы
            </Link>
          </div>
          <div className="mt-2">
            {nodes.length > 0 ? (
              <QuickSwitch nodes={nodes.slice(0, 5)} activeId={activeNode?.id ?? null} connected={connected} />
            ) : (
              <p className="py-6 text-center text-[12px] text-dim">Узлов пока нет</p>
            )}
          </div>
        </Panel>

        <Panel className="p-5">
          <div className="flex items-start justify-between gap-2">
            <div>
              <p className="text-[14px] font-medium">AI-трафик через exit</p>
              <p className="mt-0.5 text-[11.5px] text-dim">Домены, которые меняют IP первыми</p>
            </div>
            <span className="chip chip-lime">{groups.length} on</span>
          </div>
          <div className="mt-4">
            <RouteQuickToggles settings={settings} />
          </div>
        </Panel>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_1.3fr]">
        <Panel className="p-5">
          <div className="flex items-center justify-between">
            <p className="text-[14px] font-medium">Готовность</p>
            <span className="chip">{ready.filter((item) => item.ok).length}/4</span>
          </div>
          <div className="mt-3 flex flex-col">
            {ready.map((item) => (
              <div key={item.label} className="flex items-center gap-2.5 border-b border-linesoft py-2.5 last:border-0">
                <span className={item.ok ? "live-dot" : "idle-dot"} />
                <span className="text-[12.5px] text-ink/90">{item.label}</span>
                <span className="mono ml-auto truncate text-[10.5px] text-dim">{item.hint}</span>
              </div>
            ))}
          </div>
        </Panel>

        <Panel className="p-5">
          <div className="flex items-center justify-between">
            <p className="text-[14px] font-medium">Последние события</p>
            <Link href="/activity" className="mono text-[10.5px] uppercase tracking-[0.12em] text-muted hover:text-lime">
              весь журнал →
            </Link>
          </div>
          <div className="mt-2 flex flex-col">
            {events.length === 0 ? (
              <EmptyState title="Журнал пуст" hint="Действия с узлами и конфигом появятся здесь." />
            ) : (
              events.slice(0, 5).map((event) => (
                <div key={event.id} className="flex items-start gap-2.5 border-b border-linesoft py-2.5 last:border-0">
                  <LevelBadge level={event.level} />
                  <p className="min-w-0 flex-1 text-[12px] leading-snug text-muted">{event.message}</p>
                  <span className="mono shrink-0 text-[10px] text-dim" suppressHydrationWarning>
                    {relativeTime(event.createdAt)}
                  </span>
                </div>
              ))
            )}
          </div>
        </Panel>
      </div>
    </div>
  );
}
