import type { Metadata } from "next";
import { getState } from "@/lib/data";
import { enabledRouteGroups, ROUTE_GROUPS } from "@/lib/ai-routes";
import { buildSingBoxConfig } from "@/lib/singbox";
import { RoutingForm } from "@/components/routing-form";
import { Panel } from "@/components/ui";

export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "Маршрутизация — exitnode" };

export default async function RoutingPage() {
  const state = await getState();
  const groups = enabledRouteGroups(state.settings);
  const { config } = buildSingBoxConfig(state.nodes, state.settings, state.activeNode?.id ?? null);
  const route = config.route as Record<string, unknown>;
  const preview = JSON.stringify(
    {
      route: {
        rules: route.rules,
        rule_set: route.rule_set,
        final: route.final,
      },
    },
    null,
    2,
  );

  return (
    <div className="animate-fade-up space-y-4">
      <div>
        <p className="label">split tunnel · rule engine</p>
        <h1 className="mt-2 text-[26px] font-medium leading-[1.1] tracking-[-0.035em] sm:text-[30px]">
          Маршрутизация
        </h1>
        <p className="mt-1.5 max-w-2xl text-[12.5px] leading-relaxed text-muted">
          Управляйте тем, какие домены меняют IP. ChatGPT и Codex идут через выбранный exit, всё
          остальное — напрямую, чтобы локальные сервисы и банки не ломались.
        </p>
      </div>

      <div className="grid gap-4 xl:grid-cols-[1.45fr_1fr]">
        <RoutingForm settings={state.settings} />

        <div className="flex flex-col gap-3">
          <Panel className="p-5">
            <p className="text-[14px] font-medium">Путь пакета</p>
            <div className="mt-3 flex flex-col gap-1.5">
              {[
                { label: "ChatGPT / Codex", sub: "chatgpt.com · api.openai.com", tone: "muted" },
                { label: `inbound mixed :${state.settings.mixedPort}`, sub: state.settings.tunEnabled ? "+ tun-in auto_route" : "HTTP/SOCKS на localhost", tone: "muted" },
                { label: "route: rule_set", sub: `${groups.length} групп · ${state.settings.ruleSetMode ? "remote srs" : "domain_suffix"}`, tone: "accent" },
                { label: "selector ai-exit", sub: state.activeNode ? `default → ${state.activeNode.name}` : "нет узлов", tone: "accent" },
                { label: "exit node", sub: state.activeNode ? `${state.activeNode.countryCode} · ${state.activeNode.host}:${state.activeNode.port}` : "direct", tone: "lime" },
              ].map((step, index) => (
                <div key={step.label} className="flex items-center gap-2.5">
                  <span
                    className={`mono grid h-5 w-5 shrink-0 place-items-center rounded-md border text-[9.5px] ${
                      step.tone === "lime"
                        ? "border-lime/40 bg-lime/10 text-lime"
                        : step.tone === "accent"
                          ? "border-line bg-white/[0.04] text-mint"
                          : "border-line bg-white/[0.02] text-dim"
                    }`}
                  >
                    {index + 1}
                  </span>
                  <div className="min-w-0 flex-1 rounded-lg border border-linesoft px-2.5 py-2">
                    <p className="truncate text-[12px] text-ink">{step.label}</p>
                    <p className="mono mt-0.5 truncate text-[9.5px] text-dim">{step.sub}</p>
                  </div>
                </div>
              ))}
              <div className="mt-1 flex items-center gap-2 rounded-lg border border-line bg-white/[0.015] px-3 py-2">
                <span className="mono text-[10px] text-dim">fallback</span>
                <span className="mono ml-auto text-[10px] text-muted">final → direct</span>
              </div>
            </div>
          </Panel>

          <Panel className="overflow-hidden">
            <div className="flex items-center justify-between border-b border-line px-4 py-2.5">
              <p className="label">route.rules · preview</p>
              <span className="chip">json</span>
            </div>
            <pre className="code-block max-h-[320px] overflow-auto p-4">{preview}</pre>
          </Panel>

          <Panel className="p-5">
            <p className="text-[14px] font-medium">Покрытие доменов</p>
            <div className="mt-3 space-y-3">
              {ROUTE_GROUPS.map((group) => {
                const on = groups.some((item) => item.key === group.key);
                return (
                  <div key={group.key}>
                    <div className="flex items-center gap-2">
                      <span className={on ? "live-dot" : "idle-dot"} />
                      <p className="text-[12px] text-ink">{group.label}</p>
                      {!on ? <span className="chip !h-[17px] !text-[9px]">выкл</span> : null}
                    </div>
                    <p className="mono mt-1 pl-[15px] text-[10px] leading-relaxed text-dim">
                      {group.domains.join(" · ")}
                    </p>
                  </div>
                );
              })}
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
}
