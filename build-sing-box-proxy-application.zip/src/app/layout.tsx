import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Shell } from "@/components/shell";
import { getState } from "@/lib/data";
import "./globals.css";

export const metadata: Metadata = {
  title: "exitnode — sing-box control plane для ChatGPT и Codex",
  description:
    "Панель управления выходными IP на sing-box: переключение узлов, split-маршрутизация ChatGPT/Codex, проверка внешнего IP и экспорт готового конфига.",
};

export const dynamic = "force-dynamic";

export default async function RootLayout({ children }: { children: ReactNode }) {
  const state = await getState();

  return (
    <html lang="ru">
      <body className="antialiased">
        <Shell
          activeName={state.activeNode?.name ?? "direct"}
          activeCountry={state.activeNode?.countryCode ?? "XX"}
          activeLatency={state.activeNode?.latencyMs ?? null}
          connected={state.settings.connected}
          telemetryMode={state.settings.telemetryMode}
        >
          {children}
        </Shell>
      </body>
    </html>
  );
}
