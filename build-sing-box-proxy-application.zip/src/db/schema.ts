import {
  boolean,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

/**
 * Exit nodes — sing-box outbound definitions that the control plane can switch
 * between. Credentials are stored as-is in the local control-plane database.
 */
export const nodes = pgTable("nodes", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  protocol: text("protocol").notNull(), // vless | vmess | trojan | shadowsocks | hysteria2
  host: text("host").notNull(),
  port: integer("port").notNull().default(443),
  country: text("country").notNull().default("Unknown"),
  countryCode: text("country_code").notNull().default("XX"),
  city: text("city").notNull().default(""),
  provider: text("provider").notNull().default("self-hosted"),
  uuid: text("uuid").notNull().default(""),
  password: text("password").notNull().default(""),
  method: text("method").notNull().default(""),
  network: text("network").notNull().default("tcp"), // tcp | ws | grpc | h2
  path: text("path").notNull().default("/"),
  wsHost: text("ws_host").notNull().default(""),
  serviceName: text("service_name").notNull().default(""),
  security: text("security").notNull().default("tls"), // tls | reality | none
  sni: text("sni").notNull().default(""),
  alpn: text("alpn").notNull().default(""),
  flow: text("flow").notNull().default(""),
  publicKey: text("public_key").notNull().default(""),
  shortId: text("short_id").notNull().default(""),
  fingerprint: text("fingerprint").notNull().default("chrome"),
  obfs: text("obfs").notNull().default(""),
  obfsPassword: text("obfs_password").notNull().default(""),
  extra: jsonb("extra").$type<Record<string, unknown>>(),
  enabled: boolean("enabled").notNull().default(true),
  latencyMs: integer("latency_ms"),
  lossPct: integer("loss_pct").notNull().default(0),
  latencySource: text("latency_source").notNull().default("simulated"),
  lastCheckedAt: timestamp("last_checked_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Singleton control-plane settings (id = 1). */
export const settings = pgTable("settings", {
  id: integer("id").primaryKey().default(1),
  activeNodeId: integer("active_node_id"),
  connected: boolean("connected").notNull().default(false),
  connectedAt: timestamp("connected_at", { withTimezone: true }),
  mixedPort: integer("mixed_port").notNull().default(2080),
  clashPort: integer("clash_port").notNull().default(9090),
  tunEnabled: boolean("tun_enabled").notNull().default(false),
  autoSelect: boolean("auto_select").notNull().default(true),
  killSwitch: boolean("kill_switch").notNull().default(true),
  dnsStrategy: text("dns_strategy").notNull().default("ipv4_only"),
  remoteDns: text("remote_dns").notNull().default("https://1.1.1.1/dns-query"),
  directDns: text("direct_dns").notNull().default("https://dns.google/dns-query"),
  routeChatGPT: boolean("route_chatgpt").notNull().default(true),
  routeCodex: boolean("route_codex").notNull().default(true),
  routeAnthropic: boolean("route_anthropic").notNull().default(false),
  routeGoogle: boolean("route_google").notNull().default(false),
  routeStreaming: boolean("route_streaming").notNull().default(false),
  ruleSetMode: boolean("rule_set_mode").notNull().default(true),
  telemetryMode: text("telemetry_mode").notNull().default("simulated"), // simulated | tcp
  agentToken: text("agent_token").notNull().default("exitnode-local-agent"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Rolling activity log for the console. */
export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  level: text("level").notNull().default("info"), // info | success | warn | error
  scope: text("scope").notNull().default("system"),
  message: text("message").notNull(),
  nodeName: text("node_name"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Detected egress identity snapshots. */
export const egressChecks = pgTable("egress_checks", {
  id: serial("id").primaryKey(),
  ip: text("ip").notNull(),
  country: text("country").notNull().default(""),
  city: text("city").notNull().default(""),
  org: text("org").notNull().default(""),
  asn: text("asn").notNull().default(""),
  source: text("source").notNull().default("host"),
  latencyMs: integer("latency_ms"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type NodeRow = typeof nodes.$inferSelect;
export type NewNodeRow = typeof nodes.$inferInsert;
export type SettingsRow = typeof settings.$inferSelect;
export type EventRow = typeof events.$inferSelect;
export type EgressRow = typeof egressChecks.$inferSelect;
