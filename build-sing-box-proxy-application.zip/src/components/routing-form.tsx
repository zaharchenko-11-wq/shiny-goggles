"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import type { SettingsRow } from "@/db/schema";
import { api } from "@/lib/client";
import { ROUTE_GROUPS, type RouteGroupKey } from "@/lib/ai-routes";

type Draft = {
  routeChatGPT: boolean;
  routeCodex: boolean;
  routeAnthropic: boolean;
  routeGoogle: boolean;
  routeStreaming: boolean;
  ruleSetMode: boolean;
  tunEnabled: boolean;
  killSwitch: boolean;
  autoSelect: boolean;
  mixedPort: string;
  clashPort: string;
  dnsStrategy: string;
  telemetryMode: string;
  remoteDns: string;
  directDns: string;
};

const FLAG_MAP: Record<RouteGroupKey, keyof Draft> = {
  chatgpt: "routeChatGPT",
  codex: "routeCodex",
  anthropic: "routeAnthropic",
  google: "routeGoogle",
  streaming: "routeStreaming",
};

function toDraft(settings: SettingsRow): Draft {
  return {
    routeChatGPT: settings.routeChatGPT,
    routeCodex: settings.routeCodex,
    routeAnthropic: settings.routeAnthropic,
    routeGoogle: settings.routeGoogle,
    routeStreaming: settings.routeStreaming,
    ruleSetMode: settings.ruleSetMode,
    tunEnabled: settings.tunEnabled,
    killSwitch: settings.killSwitch,
    autoSelect: settings.autoSelect,
    mixedPort: String(settings.mixedPort),
    clashPort: String(settings.clashPort),
    dnsStrategy: settings.dnsStrategy,
    telemetryMode: settings.telemetryMode,
    remoteDns: settings.remoteDns,
    directDns: settings.directDns,
  };
}

export function RoutingForm({ settings }: { settings: SettingsRow }) {
  const router = useRouter();
  const [draft, setDraft] = useState<Draft>(toDraft(settings));
  const [saved, setSaved] = useState<Draft>(toDraft(settings));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const dirty = JSON.stringify(draft) !== JSON.stringify(saved);

  const set = <K extends keyof Draft>(key: K, value: Draft[K]) =>
    setDraft((prev) => ({ ...prev, [key]: value }));

  const save = async () => {
    setBusy(true);
    setError(null);
    setNotice(null);
    try {
      await api("/api/settings", {
        method: "PATCH",
        body: JSON.stringify({
          ...draft,
          mixedPort: Number(draft.mixedPort),
          clashPort: Number(draft.clashPort),
        }),
      });
      setSaved(draft);
      setNotice("Правила применены, конфиг sing-box пересобран");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Не удалось сохранить");
    } finally {
      setBusy(false);
    }
  };

  const reset = () => {
    setDraft(saved);
    setError(null);
    setNotice(null);
  };

  return (
    <div className="flex flex-col gap-3">
      <div className="panel p-5">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div>
            <p className="text-[14px] font-medium">Split-маршрутизация AI</p>
            <p className="mt-0.5 text-[11.5px] text-dim">
              Выбранные домены уходят в <span className="mono text-muted">outbound: ai-exit</span>, остальное — direct
            </p>
          </div>
          <span className={`chip ${dirty ? "chip-warn" : "chip-lime"}`}>{dirty ? "есть изменения" : "синхронизировано"}</span>
        </div>

        <div className="mt-4 flex flex-col divide-y divide-linesoft">
          {ROUTE_GROUPS.map((group) => {
            const key = FLAG_MAP[group.key];
            const on = draft[key] as boolean;
            return (
              <div key={group.key} className="flex items-start gap-3 py-3 first:pt-0 last:pb-0">
                <button
                  role="switch"
                  aria-checked={on}
                  aria-label={group.label}
                  onClick={() => set(key, !on as never)}
                  className={`mt-0.5 flex h-[20px] w-[34px] shrink-0 items-center rounded-full border px-[2.5px] transition-colors ${
                    on ? "border-lime/50 bg-lime/25" : "border-line bg-white/[0.04]"
                  }`}
                >
                  <span
                    className={`h-[13px] w-[13px] rounded-full transition-transform ${
                      on ? "translate-x-[13px] bg-lime" : "bg-[#4a5a51]"
                    }`}
                  />
                </button>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="text-[13px] text-ink">{group.label}</p>
                    <span className="mono text-[10px] text-dim">{group.domains.length} доменов</span>
                    {on ? <span className="chip chip-lime !h-[17px] !text-[9px]">→ exit</span> : null}
                  </div>
                  <p className="mono mt-1 truncate text-[10px] text-dim">
                    {group.domains.slice(0, 4).join(", ")}
                    {group.domains.length > 4 ? ` +${group.domains.length - 4}` : ""}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-4 rounded-xl border border-line bg-white/[0.02] p-3">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-[12.5px] text-ink">Использовать remote rule_set</p>
              <p className="mt-0.5 text-[11px] text-dim">
                Бинарные geo-правила MetaCubeX вместо inline-списка доменов
              </p>
            </div>
            <button
              role="switch"
              aria-checked={draft.ruleSetMode}
              onClick={() => set("ruleSetMode", !draft.ruleSetMode)}
              className={`flex h-[20px] w-[34px] shrink-0 items-center rounded-full border px-[2.5px] transition-colors ${
                draft.ruleSetMode ? "border-lime/50 bg-lime/25" : "border-line bg-white/[0.04]"
              }`}
            >
              <span
                className={`h-[13px] w-[13px] rounded-full transition-transform ${
                  draft.ruleSetMode ? "translate-x-[13px] bg-lime" : "bg-[#4a5a51]"
                }`}
              />
            </button>
          </div>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <div className="panel p-5">
          <p className="text-[14px] font-medium">Инбаунды</p>
          <div className="mt-3 grid grid-cols-2 gap-2.5">
            <div>
              <p className="label mb-1.5">mixed port</p>
              <input
                className="field mono !text-[12px]"
                value={draft.mixedPort}
                onChange={(event) => set("mixedPort", event.target.value)}
                inputMode="numeric"
              />
            </div>
            <div>
              <p className="label mb-1.5">clash api</p>
              <input
                className="field mono !text-[12px]"
                value={draft.clashPort}
                onChange={(event) => set("clashPort", event.target.value)}
                inputMode="numeric"
              />
            </div>
          </div>
          <div className="mt-3 flex flex-col divide-y divide-linesoft">
            {(
              [
                { key: "tunEnabled", label: "TUN auto_route", hint: "Перехват всего системного трафика" },
                { key: "killSwitch", label: "Kill switch", hint: "strict_route в TUN, блок при обрыве" },
                { key: "autoSelect", label: "Auto-select по latency", hint: "urltest выбирает быстрый узел" },
              ] as const
            ).map((item) => (
              <div key={item.key} className="flex items-center justify-between gap-3 py-2.5">
                <div>
                  <p className="text-[12.5px] text-ink">{item.label}</p>
                  <p className="mt-0.5 text-[10.5px] text-dim">{item.hint}</p>
                </div>
                <button
                  role="switch"
                  aria-checked={draft[item.key] as boolean}
                  onClick={() => set(item.key, !draft[item.key] as never)}
                  className={`flex h-[20px] w-[34px] shrink-0 items-center rounded-full border px-[2.5px] transition-colors ${
                    draft[item.key] ? "border-lime/50 bg-lime/25" : "border-line bg-white/[0.04]"
                  }`}
                >
                  <span
                    className={`h-[13px] w-[13px] rounded-full transition-transform ${
                      draft[item.key] ? "translate-x-[13px] bg-lime" : "bg-[#4a5a51]"
                    }`}
                  />
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="panel p-5">
          <p className="text-[14px] font-medium">DNS и телеметрия</p>
          <div className="mt-3">
            <p className="label mb-1.5">стратегия</p>
            <select
              className="field !h-9 !text-[12px]"
              value={draft.dnsStrategy}
              onChange={(event) => set("dnsStrategy", event.target.value)}
            >
              <option value="ipv4_only">ipv4_only — стабильнее для OpenAI</option>
              <option value="prefer_ipv4">prefer_ipv4</option>
              <option value="prefer_ipv6">prefer_ipv6</option>
              <option value="ipv6_only">ipv6_only</option>
            </select>
          </div>
          <div className="mt-2.5">
            <p className="label mb-1.5">remote dns (через exit)</p>
            <input
              className="field mono !h-9 !text-[11px]"
              value={draft.remoteDns}
              onChange={(event) => set("remoteDns", event.target.value)}
            />
          </div>
          <div className="mt-2.5">
            <p className="label mb-1.5">direct dns</p>
            <input
              className="field mono !h-9 !text-[11px]"
              value={draft.directDns}
              onChange={(event) => set("directDns", event.target.value)}
            />
          </div>
          <div className="mt-3">
            <p className="label mb-1.5">проверка задержек</p>
            <div className="flex rounded-lg border border-line bg-white/[0.02] p-1">
              {[
                { key: "simulated", label: "demo" },
                { key: "tcp", label: "TCP handshake" },
              ].map((item) => (
                <button
                  key={item.key}
                  onClick={() => set("telemetryMode", item.key)}
                  className={`flex-1 rounded-md px-2 py-1.5 text-[11.5px] transition-colors ${
                    draft.telemetryMode === item.key
                      ? "bg-lime font-medium text-[#0b1207]"
                      : "text-muted hover:text-ink"
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
            <p className="mt-1.5 text-[10.5px] leading-relaxed text-dim">
              demo — детерминированные значения без агента. TCP — реальный handshake до host:port
              (нужен доступ из сети хоста).
            </p>
          </div>
        </div>
      </div>

      <div className="panel sticky bottom-3 flex flex-wrap items-center gap-3 p-3">
        <div className="min-w-0">
          <p className="text-[12px] text-ink">
            {dirty ? "Есть неприменённые изменения" : "Все изменения сохранены"}
          </p>
          <p className="mono mt-0.5 truncate text-[10px] text-dim">
            route.final=direct · selector ai-exit · dns {draft.dnsStrategy}
          </p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          {error ? <p className="max-w-[260px] text-[11px] text-danger">{error}</p> : null}
          {notice ? <p className="max-w-[260px] text-[11px] text-lime">{notice}</p> : null}
          <button className="btn btn-sm" onClick={reset} disabled={busy || !dirty}>
            Сброс
          </button>
          <button className="btn btn-lime btn-sm" onClick={() => void save()} disabled={busy}>
            {busy ? "Применяем…" : "Применить и пересобрать"}
          </button>
        </div>
      </div>
    </div>
  );
}
