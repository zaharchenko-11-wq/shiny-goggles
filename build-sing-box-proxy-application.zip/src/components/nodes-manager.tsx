"use client";

import { useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import type { NodeRow } from "@/db/schema";
import { api } from "@/lib/client";
import { protocolLabel, relativeTime } from "@/lib/format";
import { Flag, LatencyMeter, StatusDot } from "@/components/ui";
import { CopyButton } from "@/components/dashboard-widgets";
import { buildOutbound } from "@/lib/singbox";
import { buildShareLink } from "@/lib/links";

const PROTOCOLS = ["vless", "vmess", "trojan", "shadowsocks", "hysteria2"] as const;

type FormState = {
  name: string;
  protocol: string;
  host: string;
  port: string;
  country: string;
  city: string;
  provider: string;
  uuid: string;
  password: string;
  method: string;
  security: string;
  network: string;
  path: string;
  wsHost: string;
  sni: string;
  alpn: string;
  flow: string;
  publicKey: string;
  shortId: string;
  obfs: string;
  obfsPassword: string;
};

const EMPTY_FORM: FormState = {
  name: "",
  protocol: "vless",
  host: "",
  port: "443",
  country: "",
  city: "",
  provider: "",
  uuid: "",
  password: "",
  method: "2022-blake3-aes-128-gcm",
  security: "reality",
  network: "tcp",
  path: "/",
  wsHost: "",
  sni: "",
  alpn: "",
  flow: "xtls-rprx-vision",
  publicKey: "",
  shortId: "",
  obfs: "",
  obfsPassword: "",
};

export function NodesManager({
  nodes,
  activeId,
  connected,
}: {
  nodes: NodeRow[];
  activeId: number | null;
  connected: boolean;
}) {
  const router = useRouter();
  const [, startTransition] = useTransition();
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [protocolFilter, setProtocolFilter] = useState("all");
  const [tab, setTab] = useState<"manual" | "import">("import");
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [importText, setImportText] = useState("");
  const [importUrl, setImportUrl] = useState("");

  const activeNode = nodes.find((node) => node.id === activeId) ?? null;
  const outboundJson = activeNode ? JSON.stringify(buildOutbound(activeNode), null, 2) : "";
  const shareLink = activeNode ? buildShareLink(activeNode) : "";

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return nodes.filter((node) => {
      const matchesQuery =
        !q ||
        node.name.toLowerCase().includes(q) ||
        node.host.toLowerCase().includes(q) ||
        node.country.toLowerCase().includes(q) ||
        node.protocol.includes(q);
      const matchesProtocol = protocolFilter === "all" || node.protocol === protocolFilter;
      return matchesQuery && matchesProtocol;
    });
  }, [nodes, query, protocolFilter]);

  const refresh = () => startTransition(() => router.refresh());

  const run = async (key: string, task: () => Promise<unknown>, success?: string) => {
    setBusy(key);
    setError(null);
    setNotice(null);
    try {
      await task();
      if (success) setNotice(success);
      refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Неизвестная ошибка");
    } finally {
      setBusy(null);
    }
  };

  const field = (key: keyof FormState) => ({
    value: form[key],
    onChange: (event: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
      setForm((prev) => ({ ...prev, [key]: event.target.value })),
  });

  const needsTls = form.security !== "none" && form.protocol !== "shadowsocks";
  const needsTransport = ["ws", "grpc"].includes(form.network) && form.protocol !== "hysteria2";

  return (
    <div className="grid gap-4 xl:grid-cols-[1.65fr_1fr]">
      <div className="flex min-w-0 flex-col gap-3">
        <div className="panel flex flex-col gap-2 p-3 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-dim">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="h-3.5 w-3.5">
                <circle cx="11" cy="11" r="7" />
                <path d="m20 20-3.5-3.5" />
              </svg>
            </span>
            <input
              className="field !h-9 !pl-8 !text-[12.5px]"
              placeholder="Поиск: имя, хост, страна, протокол"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
            />
          </div>
          <select
            className="field !h-9 !w-auto !text-[12px]"
            value={protocolFilter}
            onChange={(event) => setProtocolFilter(event.target.value)}
          >
            <option value="all">все протоколы</option>
            {PROTOCOLS.map((protocol) => (
              <option key={protocol} value={protocol}>
                {protocolLabel(protocol)}
              </option>
            ))}
          </select>
          <button
            className="btn btn-sm"
            disabled={busy !== null || nodes.length === 0}
            onClick={() => void run("probe", () => api("/api/probe", { method: "POST", body: "{}" }), "Задержки обновлены")}
          >
            {busy === "probe" ? "Проверяем…" : "Проверить все"}
          </button>
        </div>

        {error ? (
          <div className="rounded-xl border border-danger/30 bg-danger/[0.07] px-3 py-2 text-[12px] text-danger">
            {error}
          </div>
        ) : null}
        {notice ? (
          <div className="rounded-xl border border-lime/25 bg-lime/[0.06] px-3 py-2 text-[12px] text-lime">
            {notice}
          </div>
        ) : null}

        <div className="panel overflow-hidden">
          <div className="hidden grid-cols-[minmax(0,1.6fr)_minmax(0,1.1fr)_110px_150px] items-center gap-3 border-b border-line px-4 py-2.5 md:grid">
            <span className="label">узел</span>
            <span className="label">endpoint</span>
            <span className="label">задержка</span>
            <span className="label text-right">действия</span>
          </div>

          {filtered.length === 0 ? (
            <div className="px-5 py-12 text-center">
              <p className="text-[14px] text-ink">Ничего не найдено</p>
              <p className="mt-1 text-[12px] text-dim">
                {nodes.length === 0
                  ? "Добавьте узел справа или импортируйте подписку."
                  : "Измените запрос или сбросьте фильтр протокола."}
              </p>
            </div>
          ) : (
            filtered.map((node) => {
              const active = connected && node.id === activeId;
              const rowBusy = busy?.endsWith(String(node.id)) ?? false;
              return (
                <div
                  key={node.id}
                  className={`grid grid-cols-1 gap-3 border-b border-linesoft px-4 py-3 last:border-0 md:grid-cols-[minmax(0,1.6fr)_minmax(0,1.1fr)_110px_150px] md:items-center ${
                    active ? "bg-lime/[0.035]" : ""
                  } ${node.enabled ? "" : "opacity-55"}`}
                >
                  <div className="flex min-w-0 items-start gap-2.5">
                    <div className="mt-0.5 shrink-0">
                      <Flag code={node.countryCode} />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <StatusDot live={active} />
                        <p className="truncate text-[13px] text-ink">{node.name}</p>
                        {active ? <span className="chip chip-lime">active</span> : null}
                      </div>
                      <p className="mono mt-1 truncate text-[10px] text-dim">
                        {node.countryCode} · {node.provider} · {protocolLabel(node.protocol)}
                      </p>
                    </div>
                  </div>

                  <div className="min-w-0">
                    <p className="mono truncate text-[11.5px] text-muted">
                      {node.host}:{node.port}
                    </p>
                    <div className="mt-1 flex items-center gap-1.5">
                      <span className="chip !h-[18px] !text-[9px]">{node.security}</span>
                      <span className="chip !h-[18px] !text-[9px]">{node.network}</span>
                      <span className="mono text-[9.5px] text-dim">
                        {node.lossPct > 0 ? `loss ${node.lossPct}%` : "loss 0%"}
                      </span>
                    </div>
                  </div>

                  <div>
                    <LatencyMeter ms={node.latencyMs} compact />
                    <p className="mono mt-1 text-[9.5px] text-dim" suppressHydrationWarning>
                      {node.lastCheckedAt ? relativeTime(node.lastCheckedAt) : "не проверялся"}
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center justify-end gap-1.5">
                    <button
                      className={`btn btn-sm ${active ? "" : "!border-lime/30 !text-lime"}`}
                      disabled={rowBusy || !node.enabled || active}
                      onClick={() =>
                        void run(
                          `activate-${node.id}`,
                          () =>
                            api("/api/connect", {
                              method: "POST",
                              body: JSON.stringify({ nodeId: node.id, action: "connect" }),
                            }),
                          `Выход переключён на ${node.name}`,
                        )
                      }
                    >
                      {active ? "активен" : "включить"}
                    </button>
                    <button
                      className="btn btn-sm btn-ghost"
                      title="Проверить задержку"
                      disabled={rowBusy}
                      onClick={() =>
                        void run(`probe-${node.id}`, () =>
                          api("/api/probe", { method: "POST", body: JSON.stringify({ id: node.id }) }),
                        )
                      }
                    >
                      ↻
                    </button>
                    <button
                      className="btn btn-sm btn-ghost"
                      title={node.enabled ? "Отключить узел" : "Включить узел"}
                      disabled={rowBusy}
                      onClick={() =>
                        void run(`toggle-${node.id}`, () =>
                          api(`/api/nodes/${node.id}`, {
                            method: "PATCH",
                            body: JSON.stringify({ enabled: !node.enabled }),
                          }),
                        )
                      }
                    >
                      {node.enabled ? "off" : "on"}
                    </button>
                    <button
                      className="btn btn-sm btn-danger"
                      title="Удалить узел"
                      disabled={rowBusy}
                      onClick={() => {
                        if (!window.confirm(`Удалить узел «${node.name}»?`)) return;
                        void run(`delete-${node.id}`, () => api(`/api/nodes/${node.id}`, { method: "DELETE" }));
                      }}
                    >
                      ✕
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        <div className="panel flex flex-wrap items-center gap-x-5 gap-y-2 px-4 py-3">
          <p className="label">пул</p>
          <span className="mono text-[11px] text-muted">{nodes.length} всего</span>
          <span className="mono text-[11px] text-muted">{nodes.filter((n) => n.enabled).length} активных</span>
          <span className="mono text-[11px] text-muted">
            {new Set(nodes.map((n) => n.countryCode)).size} локаций
          </span>
          <span className="mono ml-auto text-[10px] text-dim">
            конфиг пересобирается автоматически при каждом изменении
          </span>
        </div>
      </div>

      <aside className="flex min-w-0 flex-col gap-3">
        <div className="panel p-4">
          <div className="flex rounded-lg border border-line bg-white/[0.02] p-1">
            {(
              [
                { key: "import", label: "Импорт" },
                { key: "manual", label: "Вручную" },
              ] as const
            ).map((item) => (
              <button
                key={item.key}
                onClick={() => setTab(item.key)}
                className={`flex-1 rounded-md px-3 py-1.5 text-[12px] transition-colors ${
                  tab === item.key ? "bg-lime text-[#0b1207] font-medium" : "text-muted hover:text-ink"
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          {tab === "import" ? (
            <div className="mt-4 flex flex-col gap-3">
              <div>
                <p className="label mb-1.5">url подписки</p>
                <div className="flex gap-2">
                  <input
                    className="field !h-9 !text-[12px]"
                    placeholder="https://panel.example/sub/…"
                    value={importUrl}
                    onChange={(event) => setImportUrl(event.target.value)}
                  />
                  <button
                    className="btn btn-sm btn-lime shrink-0"
                    disabled={busy !== null || !importUrl.trim()}
                    onClick={() =>
                      void run(
                        "import-url",
                        async () => {
                          const data = await api<{ inserted: string[]; duplicates: number }>("/api/import", {
                            method: "POST",
                            body: JSON.stringify({ url: importUrl }),
                          });
                          setNotice(
                            data.inserted.length > 0
                              ? `Загружено узлов: ${data.inserted.length}`
                              : "Новых узлов нет — все уже в пуле",
                          );
                        },
                      )
                    }
                  >
                    {busy === "import-url" ? "…" : "fetch"}
                  </button>
                </div>
              </div>

              <div>
                <p className="label mb-1.5">или ссылки узлов</p>
                <textarea
                  className="field !text-[11px] mono"
                  rows={5}
                  placeholder={"vless://uuid@host:443?security=reality&pbk=…&sni=…\nhysteria2://pass@host:443?sni=…\nss://…"}
                  value={importText}
                  onChange={(event) => setImportText(event.target.value)}
                />
                <button
                  className="btn btn-lime mt-2 w-full"
                  disabled={busy !== null || !importText.trim()}
                  onClick={() =>
                    void run(
                      "import-text",
                      async () => {
                        const data = await api<{ inserted: string[]; duplicates: number }>("/api/import", {
                          method: "POST",
                          body: JSON.stringify({ text: importText }),
                        });
                        setNotice(
                          data.inserted.length > 0
                            ? `Импортировано: ${data.inserted.join(", ")}`
                            : "Дубликаты не добавлялись",
                        );
                        if (data.inserted.length > 0) setImportText("");
                      },
                    )
                  }
                >
                  {busy === "import-text" ? "Разбираем…" : "Импортировать ссылки"}
                </button>
              </div>
              <p className="text-[10.5px] leading-relaxed text-dim">
                Поддерживаются vless, vmess, trojan, shadowsocks (SIP002), hysteria2 и base64-подписки.
                Дубликаты по <span className="mono">host:port</span> пропускаются.
              </p>
            </div>
          ) : (
            <form
              className="mt-4 flex flex-col gap-2.5"
              onSubmit={(event) => {
                event.preventDefault();
                void run(
                  "create",
                  async () => {
                    await api("/api/nodes", { method: "POST", body: JSON.stringify(form) });
                    setForm(EMPTY_FORM);
                    setNotice("Узел добавлен в пул");
                  },
                );
              }}
            >
              <div>
                <p className="label mb-1.5">имя / локация</p>
                <input className="field !h-9" placeholder="Frankfurt · AI-02" required {...field("name")} />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <p className="label mb-1.5">протокол</p>
                  <select className="field !h-9" {...field("protocol")}>
                    {PROTOCOLS.map((protocol) => (
                      <option key={protocol} value={protocol}>
                        {protocolLabel(protocol)}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <p className="label mb-1.5">порт</p>
                  <input className="field !h-9" type="number" min={1} max={65535} required {...field("port")} />
                </div>
              </div>
              <div>
                <p className="label mb-1.5">host / ip</p>
                <input className="field !h-9 mono !text-[12px]" placeholder="fra2.exitnode.dev" required {...field("host")} />
              </div>

              {form.protocol === "vless" || form.protocol === "vmess" ? (
                <div>
                  <p className="label mb-1.5">uuid</p>
                  <input className="field !h-9 mono !text-[11px]" placeholder="xxxxxxxx-xxxx-…" {...field("uuid")} />
                </div>
              ) : null}

              {form.protocol === "shadowsocks" ? (
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <p className="label mb-1.5">method</p>
                    <input className="field !h-9 mono !text-[11px]" {...field("method")} />
                  </div>
                  <div>
                    <p className="label mb-1.5">password</p>
                    <input className="field !h-9 mono !text-[11px]" {...field("password")} />
                  </div>
                </div>
              ) : null}

              {["vless", "vmess", "trojan", "hysteria2"].includes(form.protocol) ? (
                <div>
                  <p className="label mb-1.5">password {form.protocol === "vless" || form.protocol === "vmess" ? "(опц.)" : ""}</p>
                  <input className="field !h-9 mono !text-[11px]" {...field("password")} />
                </div>
              ) : null}

              {form.protocol !== "shadowsocks" && form.protocol !== "hysteria2" ? (
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <p className="label mb-1.5">security</p>
                    <select className="field !h-9" {...field("security")}>
                      <option value="reality">reality</option>
                      <option value="tls">tls</option>
                      <option value="none">none</option>
                    </select>
                  </div>
                  <div>
                    <p className="label mb-1.5">network</p>
                    <select className="field !h-9" {...field("network")}>
                      <option value="tcp">tcp</option>
                      <option value="ws">ws</option>
                      <option value="grpc">grpc</option>
                    </select>
                  </div>
                </div>
              ) : null}

              {needsTls ? (
                <div>
                  <p className="label mb-1.5">sni</p>
                  <input className="field !h-9 mono !text-[11px]" placeholder="www.microsoft.com" {...field("sni")} />
                </div>
              ) : null}

              {form.security === "reality" && form.protocol !== "shadowsocks" ? (
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <p className="label mb-1.5">public key</p>
                    <input className="field !h-9 mono !text-[10.5px]" {...field("publicKey")} />
                  </div>
                  <div>
                    <p className="label mb-1.5">short id</p>
                    <input className="field !h-9 mono !text-[10.5px]" {...field("shortId")} />
                  </div>
                </div>
              ) : null}

              {form.protocol === "vless" && form.security === "reality" ? (
                <div>
                  <p className="label mb-1.5">flow</p>
                  <input className="field !h-9 mono !text-[11px]" {...field("flow")} />
                </div>
              ) : null}

              {needsTransport ? (
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <p className="label mb-1.5">path</p>
                    <input className="field !h-9 mono !text-[11px]" {...field("path")} />
                  </div>
                  <div>
                    <p className="label mb-1.5">ws host</p>
                    <input className="field !h-9 mono !text-[11px]" {...field("wsHost")} />
                  </div>
                </div>
              ) : null}

              {form.protocol === "hysteria2" ? (
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <p className="label mb-1.5">obfs</p>
                    <select className="field !h-9" {...field("obfs")}>
                      <option value="">none</option>
                      <option value="salamander">salamander</option>
                    </select>
                  </div>
                  <div>
                    <p className="label mb-1.5">obfs password</p>
                    <input className="field !h-9 mono !text-[11px]" {...field("obfsPassword")} />
                  </div>
                </div>
              ) : null}

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <p className="label mb-1.5">city</p>
                  <input className="field !h-9 !text-[12px]" {...field("city")} />
                </div>
                <div>
                  <p className="label mb-1.5">provider</p>
                  <input className="field !h-9 !text-[12px]" placeholder="Hetzner" {...field("provider")} />
                </div>
              </div>

              <button className="btn btn-lime mt-1 w-full" disabled={busy === "create"}>
                {busy === "create" ? "Сохраняем…" : "Добавить узел"}
              </button>
              <p className="text-[10.5px] leading-relaxed text-dim">
                Страна определится по имени автоматически. Секреты хранятся в локальной PostgreSQL и
                попадают только в экспортируемый конфиг.
              </p>
            </form>
          )}
        </div>

        <div className="panel p-4">
          <div className="flex items-center justify-between">
            <p className="label">экспорт узла</p>
            {activeNode ? <span className="chip chip-lime">{protocolLabel(activeNode.protocol)}</span> : null}
          </div>
          {activeNode ? (
            <>
              <p className="mt-2 truncate text-[12px] text-ink">{activeNode.name}</p>
              <p className="mono mt-0.5 truncate text-[10px] text-dim">
                {activeNode.host}:{activeNode.port}
              </p>
              <div className="panel-quiet mt-2 max-h-[150px] overflow-hidden">
                <pre className="code-block whitespace-pre-wrap break-all p-2.5 !text-[10px]">{outboundJson}</pre>
              </div>
              <div className="mt-2 flex flex-col gap-1.5">
                <CopyButton text={outboundJson} label="Копировать outbound JSON" className="btn btn-sm w-full" />
                <CopyButton text={shareLink} label="Копировать share-link" className="btn btn-sm w-full" />
              </div>
              <p className="mt-2 text-[10.5px] leading-relaxed text-dim">
                Outbound можно вставить в существующий конфиг sing-box, share-link подходит для
                мобильных клиентов (sing-box, v2rayNG, Shadowrocket).
              </p>
            </>
          ) : (
            <p className="mt-2 text-[11.5px] leading-relaxed text-dim">
              Включите узел, чтобы увидеть его outbound JSON и share-link.
            </p>
          )}
        </div>
      </aside>
    </div>
  );
}
