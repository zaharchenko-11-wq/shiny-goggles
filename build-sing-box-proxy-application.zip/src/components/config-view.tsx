"use client";

import { useMemo, useState } from "react";
import { CopyButton } from "@/components/dashboard-widgets";

type Tab = "json" | "script" | "env";

export function ConfigView({
  json,
  script,
  activeTag,
  nodeCount,
  groups,
  mixedPort,
  tunEnabled,
}: {
  json: string;
  script: string;
  activeTag: string;
  nodeCount: number;
  groups: number;
  mixedPort: number;
  tunEnabled: boolean;
}) {
  const [tab, setTab] = useState<Tab>("json");

  const envText = useMemo(
    () =>
      [
        "# Локальный прокси sing-box (mixed inbound)",
        `export HTTPS_PROXY=http://127.0.0.1:${mixedPort}`,
        `export HTTP_PROXY=http://127.0.0.1:${mixedPort}`,
        `export ALL_PROXY=socks5://127.0.0.1:${mixedPort}`,
        "",
        "# Проверить, какой IP видит ChatGPT",
        "curl -s https://api.ipify.org; echo",
        "",
        "# Codex CLI в этом же shell",
        "codex",
        "",
        "# Или разово, без системного прокси:",
        `HTTPS_PROXY=http://127.0.0.1:${mixedPort} codex exec "напиши тест для функции parse()"`,
      ].join("\n"),
    [mixedPort],
  );

  const content = tab === "json" ? json : tab === "script" ? script : envText;
  const lines = content.split("\n");

  const downloadHref =
    tab === "json"
      ? "/api/export?download=1"
      : tab === "script"
        ? "/api/export?format=sh&download=1"
        : null;

  return (
    <div className="grid gap-4 xl:grid-cols-[1.7fr_1fr]">
      <div className="panel overflow-hidden">
        <div className="flex flex-wrap items-center gap-2 border-b border-line px-3 py-2.5">
          <div className="flex rounded-lg border border-line bg-white/[0.02] p-1">
            {(
              [
                { key: "json", label: "config.json" },
                { key: "script", label: "start.sh" },
                { key: "env", label: "env" },
              ] as const
            ).map((item) => (
              <button
                key={item.key}
                onClick={() => setTab(item.key)}
                className={`rounded-md px-2.5 py-1 text-[11.5px] transition-colors ${
                  tab === item.key ? "bg-white/[0.07] text-ink" : "text-dim hover:text-muted"
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
          <span className="mono ml-auto text-[10px] text-dim">
            {lines.length} строк · {(new TextEncoder().encode(content).length / 1024).toFixed(1)} KB
          </span>
          <CopyButton text={content} label="Копировать" />
          {downloadHref ? (
            <a href={downloadHref} className="btn btn-sm btn-lime">
              ↓ Скачать
            </a>
          ) : null}
        </div>

        <div className="relative max-h-[620px] overflow-auto">
          <div className="flex min-w-full">
            <div className="code-block select-none border-r border-linesoft bg-black/20 px-3 py-3 text-right text-[10px] text-[#3b4a43]">
              {lines.map((_, index) => (
                <div key={index}>{index + 1}</div>
              ))}
            </div>
            <pre className="code-block flex-1 px-4 py-3">
              {lines.map((line, index) => {
                const highlight = /openai|chatgpt|codex|ai-exit/i.test(line);
                return (
                  <div
                    key={index}
                    className={highlight ? "bg-lime/[0.06] -mx-4 px-4 text-[#dcf7a8]" : undefined}
                  >
                    {line || " "}
                  </div>
                );
              })}
            </pre>
          </div>
        </div>
      </div>

      <div className="flex flex-col gap-3">
        <div className="panel p-5">
          <div className="flex items-center justify-between">
            <p className="text-[14px] font-medium">Что внутри</p>
            <span className="chip chip-lime">sing-box 1.11+</span>
          </div>
          <div className="mt-3 flex flex-col divide-y divide-linesoft">
            {[
              { label: "Активный outbound", value: activeTag },
              { label: "Узлов в selector", value: `${nodeCount}` },
              { label: "AI-групп в route", value: `${groups}` },
              { label: "Mixed inbound", value: `127.0.0.1:${mixedPort}` },
              { label: "TUN", value: tunEnabled ? "auto_route" : "off" },
              { label: "Selector tag", value: "ai-exit / ai-auto" },
            ].map((row) => (
              <div key={row.label} className="flex items-center justify-between gap-3 py-2">
                <span className="text-[11.5px] text-muted">{row.label}</span>
                <span className="mono truncate text-[10.5px] text-ink/80">{row.value}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="panel p-5">
          <p className="text-[14px] font-medium">Запуск агента</p>
          <ol className="mt-3 space-y-2.5">
            {[
              "Установите sing-box: curl -fsSL https://sing-box.app/install.sh | sh",
              "Скачайте config.json кнопкой слева",
              "sing-box check -c ./sing-box-config.json",
              "sudo sing-box run -c ./sing-box-config.json",
              "Проверьте IP: curl -s https://api.ipify.org",
            ].map((step, index) => (
              <li key={step} className="flex items-start gap-2.5 text-[11.5px] leading-relaxed text-muted">
                <span className="mono mt-px grid h-[17px] w-[17px] shrink-0 place-items-center rounded-full border border-line bg-white/[0.03] text-[9px] text-lime">
                  {index + 1}
                </span>
                <span className="min-w-0 break-words">{step}</span>
              </li>
            ))}
          </ol>
          <a
            href="https://sing-box.sagernet.org/configuration/"
            target="_blank"
            rel="noreferrer"
            className="mono mt-3 inline-flex text-[10.5px] uppercase tracking-[0.12em] text-lime hover:underline"
          >
            sing-box docs ↗
          </a>
        </div>

        <div className="rounded-xl border border-warn/25 bg-warn/[0.05] p-4">
          <p className="text-[12px] font-medium text-warn">Секреты в конфиге</p>
          <p className="mt-1.5 text-[11px] leading-relaxed text-warn/80">
            Файл содержит UUID, пароли и Reality public key. Не публикуйте его и не коммитьте в git.
            Для передачи используйте защищённый канал.
          </p>
        </div>
      </div>
    </div>
  );
}
