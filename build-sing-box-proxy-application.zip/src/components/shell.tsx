"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, type ReactNode } from "react";
import { Flag, StatusDot } from "@/components/ui";

type NavItem = { href: string; label: string; icon: ReactNode; hint?: string };

const icon = {
  overview: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className="h-[17px] w-[17px]">
      <rect x="3" y="3" width="7.5" height="7.5" rx="2" />
      <rect x="13.5" y="3" width="7.5" height="7.5" rx="2" />
      <rect x="3" y="13.5" width="7.5" height="7.5" rx="2" />
      <rect x="13.5" y="13.5" width="7.5" height="7.5" rx="2" />
    </svg>
  ),
  nodes: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className="h-[17px] w-[17px]">
      <circle cx="12" cy="12" r="9" />
      <path d="M3 12h18M12 3c2.5 2.6 3.8 5.7 3.8 9s-1.3 6.4-3.8 9c-2.5-2.6-3.8-5.7-3.8-9S9.5 5.6 12 3Z" />
    </svg>
  ),
  routing: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className="h-[17px] w-[17px]">
      <circle cx="6" cy="5" r="2.4" />
      <circle cx="18" cy="19" r="2.4" />
      <circle cx="18" cy="7" r="2.4" />
      <path d="M6 7.4v3.2c0 2.4 2 4.4 4.4 4.4H15a3 3 0 0 1 3 3v-1.6M15.6 7h-1.2" />
    </svg>
  ),
  config: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className="h-[17px] w-[17px]">
      <path d="M9 7 4 12l5 5M15 7l5 5-5 5" />
    </svg>
  ),
  activity: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className="h-[17px] w-[17px]">
      <path d="M3 12h3.5L9 5l4 14 2.5-7H21" />
    </svg>
  ),
};

const NAV: { section: string; items: NavItem[] }[] = [
  {
    section: "панель",
    items: [
      { href: "/", label: "Обзор", icon: icon.overview },
      { href: "/nodes", label: "Выходные узлы", icon: icon.nodes },
    ],
  },
  {
    section: "трафик",
    items: [
      { href: "/routing", label: "Маршрутизация", icon: icon.routing },
      { href: "/config", label: "Конфиг sing-box", icon: icon.config },
    ],
  },
  {
    section: "система",
    items: [{ href: "/activity", label: "Журнал", icon: icon.activity }],
  },
];

const TITLES: Record<string, string> = {
  "/": "Обзор",
  "/nodes": "Выходные узлы",
  "/routing": "Маршрутизация",
  "/config": "Конфиг sing-box",
  "/activity": "Журнал",
};

export function Shell({
  children,
  activeName,
  activeCountry,
  activeLatency,
  connected,
  telemetryMode,
}: {
  children: ReactNode;
  activeName: string;
  activeCountry: string;
  activeLatency: number | null;
  connected: boolean;
  telemetryMode: string;
}) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const currentTitle = TITLES[pathname] ?? "ExitNode";

  const sidebar = (
    <div className="flex h-full flex-col gap-6">
      <Link href="/" className="flex items-center gap-2.5 px-1" onClick={() => setOpen(false)}>
        <span className="grid h-8 w-8 place-items-center rounded-[9px] bg-lime text-[15px] font-bold text-[#0b1207]">
          ↗
        </span>
        <span className="leading-tight">
          <span className="block text-[15px] font-semibold tracking-[-0.02em] text-ink">exitnode</span>
          <span className="mono block text-[9.5px] uppercase tracking-[0.16em] text-dim">
            sing-box control
          </span>
        </span>
      </Link>

      <nav className="flex flex-col gap-5">
        {NAV.map((group) => (
          <div key={group.section}>
            <p className="label mb-2 px-2">{group.section}</p>
            <div className="flex flex-col gap-0.5">
              {group.items.map((item) => {
                const active = pathname === item.href;
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={() => setOpen(false)}
                    className={`nav-item ${active ? "nav-item-active" : ""}`}
                  >
                    <span className={active ? "text-lime" : "text-dim"}>{item.icon}</span>
                    {item.label}
                    {active ? (
                      <span className="ml-auto h-1 w-1 rounded-full bg-lime shadow-[0_0_8px_#c9f96a]" />
                    ) : null}
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      <div className="mt-auto flex flex-col gap-3">
        <div className="panel-quiet p-3">
          <div className="flex items-center justify-between">
            <span className="label">agent</span>
            <div className="flex items-center gap-1.5">
              <StatusDot live={connected} />
              <span className="mono text-[10px] uppercase tracking-[0.1em] text-muted">
                {connected ? "online" : "idle"}
              </span>
            </div>
          </div>
          <p className="mono mt-2 truncate text-[11px] text-muted">
            {connected ? activeName : "нет активного выхода"}
          </p>
          <p className="mono mt-0.5 text-[10px] text-dim">
            {connected ? `${activeCountry} · ${activeLatency ?? "—"} ms` : "direct"}
          </p>
        </div>
        <div className="flex items-center justify-between px-1">
          <span className="mono text-[10px] text-dim">v1.11 · local</span>
          <a
            href="https://github.com/SagerNet/sing-box"
            target="_blank"
            rel="noreferrer"
            className="mono text-[10px] text-muted underline decoration-line underline-offset-2 hover:text-lime"
          >
            SagerNet/sing-box ↗
          </a>
        </div>
      </div>
    </div>
  );

  return (
    <div className="relative z-10 min-h-screen lg:grid lg:grid-cols-[252px_minmax(0,1fr)]">
      <aside className="sticky top-0 hidden h-screen border-r border-line bg-[#070b09]/80 px-4 py-5 backdrop-blur-xl lg:block">
        {sidebar}
      </aside>

      {open ? (
        <div className="fixed inset-0 z-50 lg:hidden">
          <button
            aria-label="Закрыть меню"
            className="absolute inset-0 bg-black/70 backdrop-blur-sm"
            onClick={() => setOpen(false)}
          />
          <div className="relative h-full w-[268px] border-r border-line bg-[#070b09] px-4 py-5">
            {sidebar}
          </div>
        </div>
      ) : null}

      <div className="flex min-h-screen min-w-0 flex-col">
        <header className="sticky top-0 z-30 border-b border-line bg-canvas/80 backdrop-blur-xl">
          <div className="flex h-[58px] items-center gap-3 px-4 sm:px-6 lg:px-8">
            <button
              className="btn btn-ghost btn-sm lg:hidden"
              onClick={() => setOpen(true)}
              aria-label="Открыть меню"
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" className="h-4 w-4">
                <path d="M4 7h16M4 12h16M4 17h16" />
              </svg>
            </button>
            <div className="flex min-w-0 items-center gap-2">
              <span className="mono hidden text-[11px] text-dim sm:inline">exitnode</span>
              <span className="mono hidden text-[11px] text-[#33443c] sm:inline">/</span>
              <span className="truncate text-[13px] font-medium text-ink">{currentTitle}</span>
            </div>
            <div className="ml-auto flex items-center gap-2">
              <span className="chip hidden md:inline-flex">
                {telemetryMode === "tcp" ? "tcp telemetry" : "demo telemetry"}
              </span>
              <Link href="/nodes" className="hidden items-center gap-2 rounded-lg border border-line bg-white/[0.02] px-2.5 py-1.5 sm:flex">
                <StatusDot live={connected} />
                <Flag code={connected ? activeCountry : "XX"} size="sm" />
                <span className="mono max-w-[150px] truncate text-[11px] text-muted">
                  {connected ? activeName : "direct"}
                </span>
              </Link>
              <Link href="/config" className="btn btn-lime btn-sm">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-3.5 w-3.5">
                  <path d="M12 3v12m0 0 4-4m-4 4-4-4M4 19h16" />
                </svg>
                Экспорт
              </Link>
            </div>
          </div>
        </header>

        <main className="mx-auto w-full max-w-[1240px] flex-1 px-4 pb-16 pt-6 sm:px-6 lg:px-8">
          {children}
          <footer className="mt-14 flex flex-col gap-2 border-t border-line pt-5 text-[11px] text-dim sm:flex-row sm:items-center sm:justify-between">
            <p>
              exitnode · control plane для sing-box. Туннель поднимает локальный агент, панель
              управляет маршрутами и конфигом.
            </p>
            <p className="mono text-[10px] uppercase tracking-[0.14em]">
              built for chatgpt · codex
            </p>
          </footer>
        </main>
      </div>
    </div>
  );
}
