import type { ReactNode } from "react";
import { flagEmoji, latencyPct, latencyTone } from "@/lib/format";

export function Flag({ code, size = "base" }: { code: string; size?: "sm" | "base" | "lg" }) {
  const cls = size === "lg" ? "text-[26px]" : size === "sm" ? "text-[13px]" : "text-[17px]";
  return (
    <span className={`${cls} leading-none`} aria-hidden>
      {flagEmoji(code)}
    </span>
  );
}

export function StatusDot({ live }: { live: boolean }) {
  return <span className={live ? "live-dot" : "idle-dot"} aria-hidden />;
}

export function LatencyMeter({ ms, compact = false }: { ms: number | null; compact?: boolean }) {
  const tone = latencyTone(ms);
  const width = latencyPct(ms);
  const color = tone === "good" ? "#c9f96a" : tone === "warn" ? "#f5c451" : "#ff7a6b";
  return (
    <div className="flex items-center gap-2">
      <div className="latency-bar w-full min-w-[42px]" style={compact ? undefined : { width: 58 }}>
        <div
          className="h-full rounded-full transition-all"
          style={{ width: `${width}%`, background: color, opacity: ms === null ? 0.25 : 1 }}
        />
      </div>
      <span
        className="mono shrink-0 text-[11.5px] tabular-nums"
        style={{ color: ms === null ? "#ff7a6b" : "#b9cbc1" }}
      >
        {ms === null ? "timeout" : `${ms} ms`}
      </span>
    </div>
  );
}

export function Label({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <p className={`label ${className}`}>{children}</p>;
}

export function Panel({
  children,
  className = "",
  as: Tag = "section",
}: {
  children: ReactNode;
  className?: string;
  as?: "section" | "div" | "article" | "aside";
}) {
  return <Tag className={`panel ${className}`}>{children}</Tag>;
}

export function Metric({
  label,
  value,
  hint,
  accent = false,
}: {
  label: string;
  value: ReactNode;
  hint?: ReactNode;
  accent?: boolean;
}) {
  return (
    <div className="panel px-4 py-4 sm:px-5">
      <Label>{label}</Label>
      <p
        className={`mt-2.5 text-[26px] font-medium leading-none tracking-[-0.03em] ${accent ? "text-lime" : "text-ink"}`}
      >
        {value}
      </p>
      {hint ? <p className="mt-2 text-[11.5px] leading-snug text-dim">{hint}</p> : null}
    </div>
  );
}

export function EmptyState({ title, hint, action }: { title: string; hint: string; action?: ReactNode }) {
  return (
    <div className="panel flex flex-col items-center justify-center gap-2 px-6 py-14 text-center">
      <div className="mb-1 grid h-10 w-10 place-items-center rounded-full border border-line bg-white/[0.03] text-muted">
        ✳
      </div>
      <p className="text-[15px] text-ink">{title}</p>
      <p className="max-w-sm text-[12.5px] leading-relaxed text-dim">{hint}</p>
      {action ? <div className="mt-3">{action}</div> : null}
    </div>
  );
}

export function LevelBadge({ level }: { level: string }) {
  const map: Record<string, string> = {
    success: "chip-lime",
    warn: "chip-warn",
    error: "chip-danger",
    info: "",
  };
  const labels: Record<string, string> = {
    success: "ok",
    warn: "warn",
    error: "error",
    info: "info",
  };
  return <span className={`chip ${map[level] ?? ""}`}>{labels[level] ?? level}</span>;
}
