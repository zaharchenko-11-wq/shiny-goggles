"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState, useTransition } from "react";
import type { EgressRow, NodeRow, SettingsRow } from "@/db/schema";
import { api } from "@/lib/client";
import { ROUTE_GROUPS } from "@/lib/ai-routes";
import { clockTime, flagEmoji, latencyTone, protocolLabel, relativeTime } from "@/lib/format";
import { Flag, LatencyMeter, StatusDot } from "@/components/ui";

type NodeLite = Pick<
  NodeRow,
  | "id"
  | "name"
  | "protocol"
  | "country"
  | "countryCode"
  | "city"
  | "host"
  | "port"
  | "latencyMs"
  | "lossPct"
  | "enabled"
  | "security"
  | "network"
>;

function useAction() {
  const router = useRouter();
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [, startTransition] = useTransition();

  const run = async (key: string, task: () => Promise<unknown>, done?: () => void) => {
    setBusy(key);
    setError(null);
    try {
      await task();
      done?.();
      startTransition(() => router.refresh());
    } catch (err) {
      setError(err instanceof Error ? err.message : "Неизвестная ошибка");
    } finally {
      setBusy(null);
    }
  };

  return { busy, error, setError, run, router };
}

export function ConnectSwitch({
  nodeId,
  connected,
  disabled,
}: {
  nodeId: number | null;
  connected: boolean;
  disabled?: boolean;
}) {
  const { busy, error, run } = useAction();

  const toggle = () => {
    if (!nodeId) return;
    void run("connect", () =>
      api("/api/connect", {
        method: "POST",
        body: JSON.stringify({ nodeId, action: connected ? "disconnect" : "connect" }),
      }),
    );
  };

  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center gap-3">
        <button
          onClick={toggle}
          disabled={busy !== null || !nodeId || disabled}
          className={`relative flex h-10 items-center gap-3 rounded-full border px-1.5 pr-4 transition-colors ${
            connected
              ? "border-lime/40 bg-lime/[0.12]"
              : "border-line bg-white/[0.03] hover:bg-white/[0.06]"
          }`}
          title={connected ? "Отключить exit" : "Подключить exit"}
        >
          <span
            className={`grid h-7 w-7 place-items-center rounded-full transition-all ${
              connected ? "translate-x-0 bg-lime text-[#0b1207]" : "bg-[#243029] text-dim"
            }`}
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-4 w-4">
              <path d="M12 3v9" />
              <path d="M6.5 7a8 8 0 1 0 11 0" />
            </svg>
          </span>
          <span className="mono text-[11px] font-medium uppercase tracking-[0.14em]">
            {busy === "connect" ? "…" : connected ? "exit active" : "direct"}
          </span>
        </button>
        <span className="text-[11.5px] leading-tight text-dim">
          {connected ? "Трафик AI идёт через выбранный узел" : "Включите, чтобы сменить IP"}
        </span>
      </div>
      {error ? <p className="text-[11.5px] text-danger">{error}</p> : null}
    </div>
  );
}

export function QuickSwitch({
  nodes,
  activeId,
  connected = true,
}: {
  nodes: NodeLite[];
  activeId: number | null;
  connected?: boolean;
}) {
  const { busy, error, run } = useAction();

  if (nodes.length === 0) {
    return (
      <p className="px-1 py-4 text-[12.5px] text-dim">
        Пул пуст.{" "}
        <Link href="/nodes" className="text-lime underline decoration-lime/30 underline-offset-2">
          Добавьте узел
        </Link>
        , чтобы переключать IP.
      </p>
    );
  }

  return (
    <div className="flex flex-col">
      {nodes.map((node) => {
        const active = connected && node.id === activeId;
        const tone = latencyTone(node.latencyMs);
        return (
          <button
            key={node.id}
            onClick={() =>
              void run(`node-${node.id}`, () =>
                api("/api/connect", {
                  method: "POST",
                  body: JSON.stringify({ nodeId: node.id, action: "connect" }),
                }),
              )
            }
            disabled={busy !== null || !node.enabled}
            className={`group flex items-center gap-3 border-b border-linesoft px-1 py-2.5 text-left transition-colors last:border-0 ${
              active ? "bg-lime/[0.04]" : "hover:bg-white/[0.025]"
            } ${node.enabled ? "" : "opacity-45"}`}
          >
            <StatusDot live={active} />
            <Flag code={node.countryCode} />
            <span className="min-w-0 flex-1">
              <span className="flex items-center gap-2">
                <span className="truncate text-[13px] text-ink">{node.name}</span>
                {active ? <span className="chip chip-lime">active</span> : null}
                {!node.enabled ? <span className="chip">off</span> : null}
              </span>
              <span className="mono mt-0.5 block truncate text-[10.5px] text-dim">
                {protocolLabel(node.protocol)} · {node.host}:{node.port}
              </span>
            </span>
            <span className="hidden w-[104px] shrink-0 sm:block">
              <LatencyMeter ms={node.latencyMs} compact />
            </span>
            <span
              className="mono hidden w-[46px] shrink-0 text-right text-[11px] sm:block"
              style={{
                color: tone === "good" ? "#c9f96a" : tone === "warn" ? "#f5c451" : "#ff7a6b",
              }}
            >
              {busy === `node-${node.id}` ? "…" : active ? "→" : "switch"}
            </span>
          </button>
        );
      })}
      {error ? <p className="pt-2 text-[11.5px] text-danger">{error}</p> : null}
    </div>
  );
}

export function EgressCard({
  initial,
  nodeName,
  connected,
}: {
  initial: EgressRow | null;
  nodeName: string;
  connected: boolean;
}) {
  const [egress, setEgress] = useState<EgressRow | null>(initial);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const autoRun = useRef(false);

  const check = async () => {
    setBusy(true);
    setError(null);
    try {
      const data = await api<{ egress: EgressRow }>("/api/egress", { method: "POST" });
      setEgress(data.egress);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Ошибка проверки");
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    if (!initial && !autoRun.current) {
      autoRun.current = true;
      void check();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initial]);

  return (
    <div className="panel relative overflow-hidden p-5">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="label">Внешний IP · geo</p>
          <p className="mt-1 text-[11.5px] text-dim">
            {connected ? `через ${nodeName}` : "прямое подключение хоста"}
          </p>
        </div>
        <button onClick={() => void check()} disabled={busy} className="btn btn-sm">
          {busy ? "проверка…" : "Проверить"}
        </button>
      </div>

      <div className="mt-4 flex items-end gap-2">
        <span className="mono text-[26px] leading-none tracking-[-0.02em] text-ink sm:text-[30px]">
          {egress?.ip ?? (busy ? "···" : "0.0.0.0")}
        </span>
        {egress?.country ? <Flag code={egress.country} size="base" /> : null}
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-1.5">
        {egress?.country ? (
          <span className="chip chip-lime">
            {egress.country}
            {egress.city ? ` · ${egress.city}` : ""}
          </span>
        ) : (
          <span className="chip">{busy ? "запрашиваем geo" : "не проверено"}</span>
        )}
        {egress?.asn ? <span className="chip">{egress.asn}</span> : null}
        {egress?.latencyMs ? <span className="chip">{egress.latencyMs} ms</span> : null}
      </div>

      <p className="mono mt-3 truncate text-[10.5px] text-dim">
        {egress?.org ? egress.org : "ISP / ASN появится после проверки"}
      </p>
      <p className="mt-2 flex items-center gap-1.5 text-[10.5px] text-dim" suppressHydrationWarning>
        <span className={egress ? "live-dot" : "idle-dot"} />
        {egress ? `обновлено ${relativeTime(egress.createdAt)} · ${egress.source}` : "ожидание проверки"}
      </p>

      {error ? <p className="mt-2 text-[11px] leading-snug text-danger">{error}</p> : null}
      <p className="mt-3 border-t border-linesoft pt-2.5 text-[10.5px] leading-relaxed text-dim">
        IP определяется с этого хоста. Чтобы ChatGPT видел адрес узла, запустите экспортированный
        конфиг sing-box и включите системный прокси/TUN.
      </p>
    </div>
  );
}

export function ProbeButton({ label = "Проверить задержки" }: { label?: string }) {
  const { busy, error, run } = useAction();
  return (
    <div className="flex flex-col gap-1.5">
      <button
        className="btn"
        onClick={() => void run("probe", () => api("/api/probe", { method: "POST", body: "{}" }))}
        disabled={busy !== null}
      >
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" className="h-3.5 w-3.5">
          <path d="M3 12h4l2.5-7 4 14 2.5-7h5" />
        </svg>
        {busy === "probe" ? "Проверяем…" : label}
      </button>
      {error ? <p className="text-[11px] text-danger">{error}</p> : null}
    </div>
  );
}

type CheckResult = { label: string; reachable: boolean; status: number; ms: number };

export function OpenAiCheck() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [results, setResults] = useState<CheckResult[] | null>(null);

  const run = async () => {
    setBusy(true);
    setError(null);
    try {
      const data = await api<{ results: CheckResult[] }>("/api/ai-check", {
        method: "POST",
      });
      setResults(data.results);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Ошибка проверки");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex flex-col gap-2.5">
      <button className="btn" onClick={() => void run()} disabled={busy}>
        <span className={busy ? "spinner" : ""}>◎</span>
        {busy ? "Проверяем OpenAI…" : "Проверить ChatGPT / Codex"}
      </button>
      {error ? <p className="text-[11px] text-danger">{error}</p> : null}
      {results ? (
        <div className="flex flex-col gap-1">
          {results.map((item) => (
            <div key={item.label} className="flex items-center gap-2 text-[11.5px]">
              <span
                className="h-1.5 w-1.5 rounded-full"
                style={{ background: item.reachable ? "#c9f96a" : "#ff7a6b" }}
              />
              <span className="text-muted">{item.label}</span>
              <span className="mono ml-auto text-dim">
                {item.status || "ERR"} · {item.ms} ms
              </span>
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );
}

export function RouteQuickToggles({ settings }: { settings: SettingsRow }) {
  const { busy, error, run } = useAction();
  const [flags, setFlags] = useState({
    routeChatGPT: settings.routeChatGPT,
    routeCodex: settings.routeCodex,
    routeAnthropic: settings.routeAnthropic,
    routeGoogle: settings.routeGoogle,
  });

  const keys: Record<string, keyof typeof flags> = {
    chatgpt: "routeChatGPT",
    codex: "routeCodex",
    anthropic: "routeAnthropic",
    google: "routeGoogle",
  };

  return (
    <div className="flex flex-col gap-3">
      {ROUTE_GROUPS.filter((group) => keys[group.key]).map((group) => {
        const key = keys[group.key];
        const on = flags[key];
        const pending = busy === key;
        return (
          <div key={group.key} className="flex items-start gap-3">
            <button
              role="switch"
              aria-checked={on}
              aria-label={group.label}
              disabled={pending}
              onClick={() => {
                const next = !on;
                setFlags((prev) => ({ ...prev, [key]: next }));
                void run(key, () =>
                  api("/api/settings", {
                    method: "PATCH",
                    body: JSON.stringify({ [key]: next }),
                  }),
                );
              }}
              className={`mt-0.5 flex h-[19px] w-[32px] shrink-0 items-center rounded-full border px-[2px] transition-colors ${
                on ? "border-lime/50 bg-lime/25" : "border-line bg-white/[0.04]"
              }`}
            >
              <span
                className={`h-[13px] w-[13px] rounded-full transition-transform ${
                  on ? "translate-x-[12px] bg-lime" : "translate-x-0 bg-[#4a5a51]"
                }`}
              />
            </button>
            <div className="min-w-0">
              <p className="text-[13px] leading-tight text-ink">
                {group.label}
                {on ? <span className="ml-2 text-[10px] text-lime">→ exit</span> : null}
              </p>
              <p className="mono mt-1 truncate text-[10px] text-dim">{group.hint}</p>
            </div>
          </div>
        );
      })}
      {error ? <p className="text-[11px] text-danger">{error}</p> : null}
      <Link
        href="/routing"
        className="mono mt-1 inline-flex items-center gap-1 text-[10.5px] uppercase tracking-[0.12em] text-muted hover:text-lime"
      >
        все правила и DNS →
      </Link>
    </div>
  );
}

export function CopyButton({
  text,
  label = "Копировать",
  className = "btn btn-sm",
}: {
  text: string;
  label?: string;
  className?: string;
}) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      className={className}
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(text);
          setCopied(true);
          setTimeout(() => setCopied(false), 1800);
        } catch {
          setCopied(false);
        }
      }}
    >
      {copied ? "✓ Скопировано" : label}
    </button>
  );
}

export function RefreshButton({ label = "Обновить" }: { label?: string }) {
  const router = useRouter();
  return (
    <button className="btn btn-sm" onClick={() => router.refresh()}>
      {label}
    </button>
  );
}

export function NodeLatencyBadge({ ms }: { ms: number | null }) {
  const tone = latencyTone(ms);
  return (
    <span
      className="mono text-[11px]"
      style={{
        color: tone === "good" ? "#c9f96a" : tone === "warn" ? "#f5c451" : "#ff7a6b",
      }}
    >
      {ms === null ? "timeout" : `${ms} ms`}
    </span>
  );
}

export function TimeAgo({ value }: { value: string | Date | null }) {
  return <span suppressHydrationWarning>{relativeTime(value)}</span>;
}

export function Stamp({ value }: { value: string | Date | null }) {
  return <span suppressHydrationWarning>{clockTime(value)}</span>;
}

export function CountryFlagText({ code, country }: { code: string; country: string }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span aria-hidden>{flagEmoji(code)}</span>
      {country}
    </span>
  );
}
