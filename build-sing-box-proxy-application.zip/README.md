# exitnode — sing-box control plane для ChatGPT и Codex

Панель управления выходными IP на базе [sing-box](https://github.com/SagerNet/sing-box).
Приложение хранит пул узлов (VLESS / VMess / Trojan / Shadowsocks / Hysteria2), собирает из них
готовый `config.json` для sing-box и позволяет в один клик переключить, через какой exit пойдёт
трафик ChatGPT, Codex и OpenAI API.

> Важно: веб-приложение — это **control plane**. Сам туннель поднимает sing-box CLI (агент) на
> вашем устройстве с экспортированным конфигом. Панель не может и не должна проксировать трафик
> из браузера: IP меняется на уровне устройства, а не вкладки.

## Что умеет

- **Пул выходных узлов** — 6 демо-узлов в БД, добавление вручную, импорт share-link и
  base64-подписок, включение/отключение, удаление, проверка задержек.
- **Переключение IP** — selector `ai-exit` меняет default на выбранный узел; состояние
  (`active_node_id`, `connected`) хранится в PostgreSQL.
- **Split-маршрутизация** — домены ChatGPT/Codex/Claude/Gemini уходят через exit, остальное
  напрямую (`final: direct`). Переключатель remote `rule_set` (MetaCubeX `.srs`) ↔ inline
  `domain_suffix`.
- **Реальная проверка внешнего IP** — серверный запрос к ipapi.co / ipwho.is / ipify с записью
  истории в `egress_checks` (IP, город, ASN, организация, задержка).
- **Проверка доступности OpenAI** — chatgpt.com, api.openai.com, backend-api/codex.
- **Экспорт** — `config.json` (полный sing-box конфиг), `start.sh` с командами установки и запуска,
  `env` для `HTTPS_PROXY`, outbound JSON и share-link активного узла.
- **Журнал** — все действия и проверки пишутся в таблицу `events`.

## Стек

- Next.js 16 (App Router, React 19, server components + route handlers)
- PostgreSQL + Drizzle ORM (`src/db/schema.ts`)
- Tailwind CSS 4
- sing-box конфиг генерируется в `src/lib/singbox.ts`

## Запуск

```bash
npm install
npx drizzle-kit push      # создать таблицы
npm run dev               # http://localhost:3000
```

`DATABASE_URL` берётся из `.env`. Демо-данные (узлы, настройки, журнал) создаются автоматически
при первом запросе, если таблицы пусты.

## Подключение настоящего sing-box

```bash
# 1. Установить
curl -fsSL https://sing-box.app/install.sh | sh   # macOS / Linux

# 2. Скачать конфиг из панели (страница «Конфиг sing-box» → Скачать)
mv ~/Downloads/sing-box-config.json ~/exitnode.json

# 3. Проверить и запустить
sing-box check -c ~/exitnode.json
sudo sing-box run -c ~/exitnode.json

# 4. Направить в прокси нужные приложения
export HTTPS_PROXY=http://127.0.0.1:2080
codex
```

Проверка IP и ChatGPT:

```bash
curl -s https://api.ipify.org; echo
curl -s -o /dev/null -w "%{http_code}\n" https://chatgpt.com
```

### Сборка sing-box из исходников

```bash
git clone https://github.com/SagerNet/sing-box.git
cd sing-box
go install -tags "with_quic,with_utls,with_reality_server,with_clash_api,with_gvisor" ./cmd/sing-box
```

## Структура

```
src/
  app/
    page.tsx                 # обзор + смена выхода
    nodes/page.tsx           # пул узлов, импорт, экспорт узла
    routing/page.tsx         # правила, DNS, инбаунды
    config/page.tsx          # config.json / start.sh / env
    activity/page.tsx        # журнал и диагностика
    api/
      state, nodes, nodes/[id], connect, probe, settings,
      import, egress, ai-check, export, health
  components/                # shell, виджеты, менеджер узлов, формы
  db/                        # drizzle schema + pool
  lib/
    singbox.ts               # генерация sing-box конфига
    links.ts                 # парсинг и сборка share-link
    ai-routes.ts             # домены ChatGPT / Codex / Claude / Gemini
    net.ts                   # гео-IP, TCP-пробы
    data.ts / seed.ts        # доступ к данным и демо-данные
```

## API

| Метод | Роут | Назначение |
| --- | --- | --- |
| GET | `/api/state` | узлы, настройки, журнал, последний geo-замер |
| GET/POST | `/api/nodes` | список / создание узла |
| PATCH/DELETE | `/api/nodes/:id` | включить/отключить, переименовать, удалить |
| POST | `/api/connect` | `{nodeId, action: connect \| disconnect}` |
| POST | `/api/probe` | проверка задержек (`simulated` или реальный TCP handshake) |
| GET/PATCH | `/api/settings` | порты, TUN, DNS, AI-правила, телеметрия |
| POST | `/api/import` | `{text}` или `{url}` подписки |
| GET/POST | `/api/egress` | история / обновление внешнего IP |
| POST | `/api/ai-check` | доступность ChatGPT и Codex |
| GET | `/api/export` | `?format=json\|sh`, `?download=1` |
| GET | `/api/health` | проверка БД |

## Безопасность

- В `config.json` попадают UUID, пароли и Reality public key — не публикуйте файл.
- Секреты узлов хранятся в локальной PostgreSQL в открытом виде: это self-hosted control plane,
  не выкладывайте базу и не открывайте панель в интернет без reverse-proxy + авторизации.
- Телеметрия задержек по умолчанию `simulated` (демо). Переключите на `TCP handshake` в
  «Маршрутизация → DNS и телеметрия», чтобы измерять реальные host:port.

## Возможные улучшения

- Агент синхронизации (`POST /api/agent/report`) с токеном для реальных задержек и статуса
  sing-box из `clash_api`.
- Генерация Clash/mihomo YAML из того же пула.
- Мультипрофильность (разные пулы под ChatGPT и Codex) и авторизация панели.
