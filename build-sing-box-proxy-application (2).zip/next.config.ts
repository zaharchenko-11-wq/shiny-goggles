import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  serverExternalPackages: ["undici", "pg"],
};

export default nextConfig;
