"use client";

import clsx from "clsx";
import { useCallback, useEffect, useState } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  Eraser,
  Info,
  Pause,
  Play,
  RefreshCw,
  Terminal,
} from "lucide-react";
import { Btn, Card, CardHeader, Spinner } from "@/components/ui";
import { fmtTime, jfetch, toast } from "@/lib/client";

interface EventRow {
  id: number;
  kind: string;
  message: string;
  createdAt: string;
}

const KIND_META: Record<string, { icon: typeof Info; color: string }> = {
  info: { icon: Info, color: "#5fd2e4" },
  success: { icon: CheckCircle2, color: "#c9f24b" },
  warn: { icon: AlertTriangle, color: "#f5c04e" },
  error: { icon: AlertTriangle, color: "#ff6a5c" },
};

export default function LogsPage() {
  const [events, setEvents] = useState<EventRow[]>([]);
  const [engineLog, setEngineLog] = useState("");
  const [live, setLive] = useState(true);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      const d = await jfetch<{ events: EventRow[]; engineLog: string }>("/api/logs");
      setEvents(d.events);
      setEngineLog(d.engineLog);
    } catch {
      /* ignore */
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    if (!live) return;
    const t = setInterval(load, 4000);
    return () => clearInterval(t);
  }, [load, live]);

  async function clearEvents() {
    try {
      await jfetch("/api/logs", { method: "DELETE" });
      setEvents([]);
      toast("Журнал событий очищен", "info");
    } catch (e) {
      toast(e instanceof Error ? e.message : "Ошибка", "error");
    }
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="font-mono text-[10px] tracking-[0.3em] text-muted uppercase">
            панель / журнал
          </div>
          <h1 className="mt-2 text-3xl font-extrabold tracking-tight md:text-4xl">Журнал</h1>
        </div>
        <div className="flex items-center gap-2">
          <Btn
            variant={live ? "primary" : "ghost"}
            size="md"
            onClick={() => setLive((v) => !v)}
          >
            {live ? <Pause size={14} /> : <Play size={14} />}
            {live ? "Live · 4с" : "Возобновить"}
          </Btn>
          <Btn variant="ghost" onClick={load}>
            <RefreshCw size={14} />
            Обновить
          </Btn>
          <Btn variant="danger" onClick={clearEvents}>
            <Eraser size={14} />
            Очистить
          </Btn>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-5 xl:grid-cols-2">
        <Card>
          <CardHeader title="События" hint="действия панели и движка" />
          <div className="max-h-[520px] overflow-y-auto px-3 py-3">
            {loading ? (
              <div className="flex items-center gap-2 px-3 py-8 text-muted">
                <Spinner /> загрузка…
              </div>
            ) : events.length === 0 ? (
              <div className="px-3 py-8 text-center font-mono text-xs text-muted">
                событий пока нет
              </div>
            ) : (
              events.map((e) => {
                const meta = KIND_META[e.kind] || KIND_META.info;
                return (
                  <div
                    key={e.id}
                    className="flex items-start gap-3 rounded-lg px-3 py-2 transition-colors hover:bg-panel2"
                  >
                    <meta.icon size={14} style={{ color: meta.color }} className="mt-0.5 shrink-0" />
                    <div className="min-w-0">
                      <div className="text-[13px] leading-snug text-ink">{e.message}</div>
                      <div className="mt-0.5 font-mono text-[10px] text-muted">
                        {fmtTime(e.createdAt)}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </Card>

        <Card>
          <CardHeader
            title="Вывод sing-box"
            hint="stderr/stdout запущенного процесса"
            right={<Terminal size={14} className="text-muted" />}
          />
          <div className="px-4 py-4">
            <pre
              className={clsx(
                "h-[460px] overflow-auto rounded-xl border border-line bg-bg p-4 font-mono text-[11px] leading-relaxed",
                engineLog.trim() ? "text-sub" : "text-muted",
              )}
            >
              {engineLog.trim() || "// пусто — движок не запускался в этой сессии"}
            </pre>
          </div>
        </Card>
      </div>
    </div>
  );
}
