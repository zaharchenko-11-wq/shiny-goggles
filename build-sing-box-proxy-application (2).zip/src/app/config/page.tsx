"use client";

import clsx from "clsx";
import { Fragment, useCallback, useEffect, useState, type ReactNode } from "react";
import { AlertTriangle, CheckCircle2, Download, FileCheck2 } from "lucide-react";
import { Btn, Card, CardHeader, CopyBtn, Spinner } from "@/components/ui";
import { jfetch, toast } from "@/lib/client";

interface ConfigResponse {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  config: any;
  degraded: boolean;
  engine: { available: boolean; version: string | null };
  activeServer: { id: number; name: string; protocol: string } | null;
}

/* naive JSON syntax highlighting */
function highlightLine(line: string, lineIdx: number): ReactNode {
  const re = /("(?:[^"\\]|\\.)*")(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?/g;
  const parts: ReactNode[] = [];
  let last = 0;
  let m: RegExpExecArray | null;
  let k = 0;
  while ((m = re.exec(line))) {
    if (m.index > last) parts.push(line.slice(last, m.index));
    if (m[1] !== undefined) {
      if (m[2]) {
        parts.push(
          <span key={`${lineIdx}-${k++}`} className="text-acid/90">
            {m[1]}
          </span>,
          m[2],
        );
      } else {
        parts.push(
          <span key={`${lineIdx}-${k++}`} className="text-ink">
            {m[1]}
          </span>,
        );
      }
    } else if (m[3] !== undefined) {
      parts.push(
        <span key={`${lineIdx}-${k++}`} className="text-warn">
          {m[3]}
        </span>,
      );
    } else {
      parts.push(
        <span key={`${lineIdx}-${k++}`} className="text-info">
          {m[0]}
        </span>,
      );
    }
    last = re.lastIndex;
  }
  if (last < line.length) parts.push(line.slice(last));
  return <Fragment>{parts}</Fragment>;
}

export default function ConfigPage() {
  const [data, setData] = useState<ConfigResponse | null>(null);
  const [validating, setValidating] = useState(false);
  const [validation, setValidation] = useState<{ ok: boolean; message: string; detail?: string } | null>(null);

  const load = useCallback(async () => {
    try {
      setData(await jfetch<ConfigResponse>("/api/config"));
    } catch (e) {
      toast(e instanceof Error ? e.message : "Ошибка загрузки", "error");
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function validate() {
    setValidating(true);
    setValidation(null);
    try {
      const r = await jfetch<{ ok: boolean; message: string }>("/api/control", {
        method: "POST",
        body: JSON.stringify({ action: "validate" }),
      });
      setValidation({ ok: true, message: r.message });
    } catch (e) {
      const err = e as Error & { detail?: string };
      setValidation({ ok: false, message: err.message, detail: err.detail });
    } finally {
      setValidating(false);
    }
  }

  const pretty = data ? JSON.stringify(data.config, null, 2) : "";
  const lines = pretty.split("\n");

  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="font-mono text-[10px] tracking-[0.3em] text-muted uppercase">
            панель / конфиг
          </div>
          <h1 className="mt-2 text-3xl font-extrabold tracking-tight md:text-4xl">
            Конфигурация sing-box
          </h1>
          <p className="mt-2 max-w-xl text-[13px] leading-relaxed text-sub">
            Генерируется автоматически из активного сервера и настроек маршрутизации.
            Формат — sing-box 1.12+ (rule actions, default_domain_resolver).
          </p>
        </div>
        <div className="flex items-center gap-2">
          <CopyBtn text={pretty} label="Копировать JSON" />
          <a href="/api/config?download=1">
            <Btn variant="outline">
              <Download size={14} />
              Скачать
            </Btn>
          </a>
          <Btn variant="primary" onClick={validate} disabled={validating || data?.engine.available === false}>
            {validating ? <Spinner /> : <FileCheck2 size={14} />}
            sing-box check
          </Btn>
        </div>
      </div>

      {data?.degraded && (
        <div className="flex items-start gap-3 rounded-2xl border border-warn/30 bg-warn/5 px-5 py-4">
          <AlertTriangle size={16} className="mt-0.5 shrink-0 text-warn" />
          <div className="text-[13px] leading-relaxed text-sub">
            <span className="font-semibold text-warn">Сервер не выбран.</span> Конфиг собран с
            заглушкой direct вместо outbound «proxy» — выберите активный сервер на обзорной
            странице или в разделе «Серверы».
          </div>
        </div>
      )}

      {validation && (
        <div
          className={clsx(
            "flex items-start gap-3 rounded-2xl border px-5 py-4",
            validation.ok ? "border-good/30 bg-good/5" : "border-danger/30 bg-danger/5",
          )}
        >
          {validation.ok ? (
            <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-good" />
          ) : (
            <AlertTriangle size={16} className="mt-0.5 shrink-0 text-danger" />
          )}
          <div className="text-[13px]">
            <span className={validation.ok ? "text-good" : "text-danger"}>{validation.message}</span>
            {validation.detail && (
              <pre className="mt-2 max-h-40 overflow-auto rounded-lg bg-bg p-3 font-mono text-[10px] leading-relaxed text-sub">
                {validation.detail}
              </pre>
            )}
          </div>
        </div>
      )}

      <Card>
        <CardHeader
          title="config.json"
          hint={
            data?.activeServer
              ? `proxy → ${data.activeServer.name} (${data.activeServer.protocol.toUpperCase()})`
              : "proxy → direct (заглушка)"
          }
          right={
            <span className="font-mono text-[10px] text-muted">
              {lines.length} строк{data?.engine.version ? ` · sing-box v${data.engine.version}` : ""}
            </span>
          }
        />
        <div className="overflow-x-auto px-2 py-4">
          {!data ? (
            <div className="flex items-center gap-2 px-4 py-10 text-muted">
              <Spinner /> загрузка…
            </div>
          ) : (
            <pre className="font-mono text-[12px] leading-[1.7] text-sub">
              {lines.map((l, i) => (
                <div key={i} className="flex">
                  <span className="w-11 shrink-0 pr-4 text-right text-muted/50 select-none">
                    {i + 1}
                  </span>
                  <span className="whitespace-pre">{highlightLine(l, i)}</span>
                </div>
              ))}
            </pre>
          )}
        </div>
      </Card>

      <div className="rounded-2xl border border-line bg-panel px-6 py-4 text-[12px] leading-relaxed text-sub">
        <span className="font-semibold text-ink">Как использовать вручную:</span> скачайте файл и
        выполните{" "}
        <span className="font-mono text-acid">sing-box run -c sing-box-config.json</span>, затем
        настройте систему или браузер на SOCKS5/HTTP-прокси{" "}
        <span className="font-mono text-acid">127.0.0.1:2080</span>. Для ChatGPT/Codex в режиме
        «по правилам» через прокси идут только домены OpenAI.
      </div>
    </div>
  );
}
