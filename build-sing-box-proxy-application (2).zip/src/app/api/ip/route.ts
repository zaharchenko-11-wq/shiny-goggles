import { getSettings } from "@/lib/settings";
import { engineStatus } from "@/lib/singbox";
import { fetchIpInfo } from "@/lib/ip";
import { unstable_noStore as noStore } from "next/cache";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  noStore();
  const { searchParams } = new URL(req.url);
  const via = searchParams.get("via");
  const settings = await getSettings();

  if (via === "proxy") {
    const engine = engineStatus(settings);
    if (!engine.running) {
      return Response.json({ error: "Прокси не запущен" }, { status: 409 });
    }
    const info = await fetchIpInfo({ viaProxyPort: settings.listenPort, timeoutMs: 8000 });
    if (!info) {
      return Response.json(
        { error: "Не удалось получить IP через прокси (нода недоступна?)" },
        { status: 502 },
      );
    }
    return Response.json({ info, via: "proxy" });
  }

  const info = await fetchIpInfo({ timeoutMs: 6000 });
  if (!info) {
    return Response.json({ error: "Нет соединения с внешним сервисом" }, { status: 502 });
  }
  return Response.json({ info, via: "direct" });
}
