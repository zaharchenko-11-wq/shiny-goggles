import { db } from "@/db";
import { eventLogs } from "@/db/schema";
import { readLogTail } from "@/lib/singbox";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const events = await db
    .select()
    .from(eventLogs)
    .orderBy(desc(eventLogs.createdAt))
    .limit(200);
  const engineLog = readLogTail(120);
  return Response.json({ events, engineLog });
}

export async function DELETE() {
  await db.delete(eventLogs);
  return Response.json({ ok: true });
}
