import { db } from "@/db";
import { servers } from "@/db/schema";
import { tcpPing } from "@/lib/net";
import { eq } from "drizzle-orm";
import { unstable_noStore as noStore } from "next/cache";

export const dynamic = "force-dynamic";

export async function POST(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  noStore();
  const { id } = await params;
  const serverId = Number(id);
  const [server] = await db.select().from(servers).where(eq(servers.id, serverId));
  if (!server) return Response.json({ error: "Сервер не найден" }, { status: 404 });

  const latency = await tcpPing(server.address, server.port, 4000);
  const status = latency === null ? "fail" : "ok";
  await db.update(servers).set({ latency, status }).where(eq(servers.id, serverId));

  return Response.json({ id: serverId, latency, status });
}
