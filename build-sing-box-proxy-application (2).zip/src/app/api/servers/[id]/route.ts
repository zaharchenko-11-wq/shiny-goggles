import { db } from "@/db";
import { servers } from "@/db/schema";
import { addLog, getSettings, setSettings } from "@/lib/settings";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, { params }: Params) {
  const { id } = await params;
  const serverId = Number(id);
  if (!Number.isInteger(serverId)) {
    return Response.json({ error: "Неверный id" }, { status: 400 });
  }
  try {
    const body = await req.json();
    const updates: Record<string, unknown> = {};
    if (typeof body.name === "string" && body.name.trim()) updates.name = body.name.trim();
    if (typeof body.enabled === "boolean") updates.enabled = body.enabled;
    if (typeof body.latency === "number" || body.latency === null) updates.latency = body.latency;
    if (typeof body.status === "string") updates.status = body.status;
    if (body.config && typeof body.config === "object") {
      const c = body.config as Record<string, unknown>;
      updates.config = c;
      updates.protocol = String(c.type || "unknown");
      updates.address = String(c.server || "");
      updates.port = Number(c.server_port) || 0;
      if (!updates.name) updates.name = String(c.tag || `${updates.address}:${updates.port}`);
    }

    const [updated] = await db
      .update(servers)
      .set(updates as never)
      .where(eq(servers.id, serverId))
      .returning();
    if (!updated) return Response.json({ error: "Сервер не найден" }, { status: 404 });
    return Response.json({ server: updated });
  } catch (e) {
    return Response.json(
      { error: e instanceof Error ? e.message : "Ошибка обновления" },
      { status: 400 },
    );
  }
}

export async function DELETE(_req: Request, { params }: Params) {
  const { id } = await params;
  const serverId = Number(id);
  const [removed] = await db.delete(servers).where(eq(servers.id, serverId)).returning();
  if (!removed) return Response.json({ error: "Сервер не найден" }, { status: 404 });

  const settings = await getSettings();
  if (settings.activeServerId === serverId) {
    await setSettings({ activeServerId: null });
  }
  await addLog("warn", `Сервер «${removed.name}» удалён`);
  return Response.json({ ok: true });
}
