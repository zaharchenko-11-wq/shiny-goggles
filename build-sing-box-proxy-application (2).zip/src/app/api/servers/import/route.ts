import { db } from "@/db";
import { servers, subscriptions } from "@/db/schema";
import { addLog } from "@/lib/settings";
import { decodeSubscriptionPayload, parseShareLink } from "@/lib/protocols";
import { and, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

interface ImportResult {
  added: number;
  skipped: number;
  failed: { line: string; error: string }[];
  total: number;
}

async function importLines(lines: string[], source: string): Promise<ImportResult> {
  const result: ImportResult = { added: 0, skipped: 0, failed: [], total: 0 };
  const candidates = lines.filter((l) =>
    /^(vless|vmess|trojan|ss|hysteria2|hy2|tuic):\/\//.test(l),
  );
  result.total = candidates.length;

  for (const line of candidates) {
    try {
      const parsed = parseShareLink(line);
      // dedupe by name + address + port
      const existing = await db
        .select({ id: servers.id })
        .from(servers)
        .where(
          and(
            eq(servers.name, parsed.name),
            eq(servers.address, parsed.address),
            eq(servers.port, parsed.port),
          ),
        )
        .limit(1);
      if (existing.length) {
        result.skipped++;
        continue;
      }
      await db.insert(servers).values({
        name: parsed.name,
        protocol: parsed.protocol,
        address: parsed.address,
        port: parsed.port,
        config: parsed.outbound,
        source,
      });
      result.added++;
    } catch (e) {
      result.failed.push({
        line: line.slice(0, 80),
        error: e instanceof Error ? e.message : "Ошибка парсинга",
      });
    }
  }
  return result;
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));

  if (typeof body.text === "string" && body.text.trim()) {
    const lines = decodeSubscriptionPayload(body.text);
    const result = await importLines(lines, "uri");
    await addLog(
      result.added > 0 ? "success" : "warn",
      `Импорт ссылок: добавлено ${result.added}, дубликатов ${result.skipped}, ошибок ${result.failed.length}`,
    );
    return Response.json(result);
  }

  if (typeof body.url === "string" && body.url.trim()) {
    const url = body.url.trim();
    const name = (body.name || "").trim() || new URL(url).hostname;
    let text = "";
    try {
      const res = await fetch(url, {
        signal: AbortSignal.timeout(10000),
        headers: { "user-agent": "sing-box/1.14 sing-deck" },
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      text = await res.text();
    } catch (e) {
      return Response.json(
        { error: `Не удалось загрузить подписку: ${e instanceof Error ? e.message : e}` },
        { status: 400 },
      );
    }
    const lines = decodeSubscriptionPayload(text);
    const result = await importLines(lines, "subscription");

    await db
      .insert(subscriptions)
      .values({ name, url, serversCount: result.added, updatedAt: new Date() })
      .onConflictDoUpdate({
        target: subscriptions.url,
        set: { name, serversCount: result.added, updatedAt: new Date() },
      });

    await addLog(
      "success",
      `Подписка «${name}»: загружено ${result.total} узлов, добавлено ${result.added}`,
    );
    return Response.json(result);
  }

  return Response.json({ error: "Передайте text или url" }, { status: 400 });
}

export async function GET() {
  const rows = await db.select().from(subscriptions);
  return Response.json({ subscriptions: rows });
}

export async function DELETE(req: Request) {
  const { searchParams } = new URL(req.url);
  const id = Number(searchParams.get("id"));
  if (!id) return Response.json({ error: "id required" }, { status: 400 });
  await db.delete(subscriptions).where(eq(subscriptions.id, id));
  return Response.json({ ok: true });
}
