import { db } from "@/db";
import { servers } from "@/db/schema";
import { addLog, getSettings } from "@/lib/settings";
import { parseShareLink } from "@/lib/protocols";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db.select().from(servers).orderBy(desc(servers.createdAt));
  const settings = await getSettings();
  return Response.json({ servers: rows, activeServerId: settings.activeServerId });
}

export async function POST(req: Request) {
  try {
    const body = await req.json();

    let name: string;
    let protocol: string;
    let address: string;
    let port: number;
    let config: Record<string, unknown>;

    if (typeof body.uri === "string" && body.uri.trim()) {
      const parsed = parseShareLink(body.uri.trim());
      name = parsed.name;
      protocol = parsed.protocol;
      address = parsed.address;
      port = parsed.port;
      config = parsed.outbound;
    } else if (body.config && typeof body.config === "object") {
      const c = body.config as Record<string, unknown>;
      config = c;
      protocol = String(c.type || "unknown");
      address = String(c.server || "");
      port = Number(c.server_port) || 0;
      name = String(body.name || c.tag || `${address}:${port}`);
    } else {
      return Response.json(
        { error: "Укажите uri (ссылку) или config (outbound-объект)" },
        { status: 400 },
      );
    }

    if (!name) name = `${address}:${port}`;

    const [created] = await db
      .insert(servers)
      .values({
        name,
        protocol,
        address,
        port,
        config,
        source: body.source === "demo" ? "demo" : body.uri ? "uri" : "manual",
      })
      .returning();

    await addLog("info", `Добавлен сервер «${name}» (${protocol})`);
    return Response.json({ server: created }, { status: 201 });
  } catch (e) {
    const message = e instanceof Error ? e.message : "Ошибка создания сервера";
    return Response.json({ error: message }, { status: 400 });
  }
}
