import { addLog, getSettings, setSettings, DEFAULT_PROXY_DOMAINS } from "@/lib/settings";
import { binaryInfo } from "@/lib/singbox";

export const dynamic = "force-dynamic";

export async function GET() {
  const settings = await getSettings();
  const binary = binaryInfo(settings.singboxPath || undefined);
  return Response.json({ settings, binary, defaultDomains: DEFAULT_PROXY_DOMAINS });
}

export async function PUT(req: Request) {
  const body = await req.json().catch(() => ({}));
  const patch: Record<string, unknown> = {};

  if ("mode" in body) {
    if (!["rule", "global", "direct"].includes(body.mode)) {
      return Response.json({ error: "Недопустимый режим" }, { status: 400 });
    }
    patch.mode = body.mode;
  }
  if ("listenPort" in body) {
    const p = Number(body.listenPort);
    if (!Number.isInteger(p) || p < 1 || p > 65535) {
      return Response.json({ error: "Порт должен быть 1–65535" }, { status: 400 });
    }
    patch.listenPort = p;
  }
  if ("proxyDomains" in body) {
    if (!Array.isArray(body.proxyDomains)) {
      return Response.json({ error: "proxyDomains должен быть массивом" }, { status: 400 });
    }
    const domains = (body.proxyDomains as unknown[])
      .map((d) => String(d).trim().toLowerCase().replace(/^\*\./, "").replace(/\s/g, ""))
      .filter((d) => d && /^[a-z0-9.-]+\.[a-z]{2,}$/.test(d));
    if (!domains.length) {
      return Response.json({ error: "Нужен минимум один домен" }, { status: 400 });
    }
    patch.proxyDomains = [...new Set(domains)];
  }
  if ("dnsRemote" in body) patch.dnsRemote = String(body.dnsRemote).trim() || "1.1.1.1";
  if ("dnsLocal" in body) patch.dnsLocal = String(body.dnsLocal).trim() || "223.5.5.5";
  if ("singboxPath" in body) patch.singboxPath = String(body.singboxPath).trim();
  if ("activeServerId" in body) {
    patch.activeServerId = body.activeServerId === null ? null : Number(body.activeServerId) || null;
  }

  const settings = await setSettings(patch as never);
  await addLog("info", "Настройки маршрутизации обновлены");
  return Response.json({ settings });
}
