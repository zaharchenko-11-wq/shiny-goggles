import { db } from "@/db";
import { servers } from "@/db/schema";
import { getSettings } from "@/lib/settings";
import { buildSingboxConfig } from "@/lib/config-gen";
import { engineStatus } from "@/lib/singbox";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const settings = await getSettings();
  let activeServer = null;
  let activeOutbound: Record<string, unknown> | null = null;
  if (settings.activeServerId) {
    const [s] = await db.select().from(servers).where(eq(servers.id, settings.activeServerId));
    activeServer = s || null;
    activeOutbound = (s?.config as Record<string, unknown>) || null;
  }

  const { config, degraded } = buildSingboxConfig(activeOutbound, settings);
  const engine = engineStatus(settings);

  const { searchParams } = new URL(req.url);
  if (searchParams.get("download") === "1") {
    return new Response(JSON.stringify(config, null, 2), {
      headers: {
        "content-type": "application/json; charset=utf-8",
        "content-disposition": 'attachment; filename="sing-box-config.json"',
      },
    });
  }

  return Response.json({
    config,
    degraded,
    engine,
    activeServer: activeServer
      ? { id: activeServer.id, name: activeServer.name, protocol: activeServer.protocol }
      : null,
  });
}
