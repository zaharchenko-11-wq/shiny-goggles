import { db } from "@/db";
import { servers } from "@/db/schema";
import { addLog, getSettings } from "@/lib/settings";
import {
  engineStatus,
  startEngine,
  stopEngine,
  binaryInfo,
  resolveBinary,
} from "@/lib/singbox";
import { buildSingboxConfig } from "@/lib/config-gen";
import { eq } from "drizzle-orm";
import { execFileSync } from "node:child_process";
import fs from "node:fs";

export const dynamic = "force-dynamic";

export async function GET() {
  const settings = await getSettings();
  const engine = engineStatus(settings);

  let activeServer = null;
  if (settings.activeServerId) {
    const [s] = await db
      .select()
      .from(servers)
      .where(eq(servers.id, settings.activeServerId));
    activeServer = s || null;
  }

  return Response.json({ engine, settings, activeServer });
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const action = String(body.action || "");
  const settings = await getSettings();

  if (action === "stop") {
    const res = stopEngine();
    await addLog("info", "Движок sing-box остановлен пользователем");
    return Response.json(res);
  }

  if (action === "validate") {
    const bin = resolveBinary(settings.singboxPath || undefined);
    if (!bin) {
      return Response.json(
        { ok: false, message: "sing-box не найден", detail: "Установите sing-box или укажите путь в настройках" },
        { status: 400 },
      );
    }
    let activeOutbound = null;
    if (settings.activeServerId) {
      const [s] = await db.select().from(servers).where(eq(servers.id, settings.activeServerId));
      activeOutbound = (s?.config as Record<string, unknown>) || null;
    }
    const { config } = buildSingboxConfig(activeOutbound, settings);
    const tmp = `${process.cwd()}/.singbox-run/validate.json`;
    fs.mkdirSync(`${process.cwd()}/.singbox-run`, { recursive: true });
    fs.writeFileSync(tmp, JSON.stringify(config, null, 2));
    try {
      execFileSync(bin, ["check", "-c", tmp], { encoding: "utf8", timeout: 10000 });
      return Response.json({ ok: true, message: "Конфигурация валидна (sing-box check пройден)" });
    } catch (e) {
      const stderr = (e as { stderr?: string })?.stderr;
      return Response.json(
        { ok: false, message: "Ошибка валидации", detail: stderr || String(e) },
        { status: 400 },
      );
    }
  }

  if (action === "start" || action === "restart") {
    if (binaryInfo(settings.singboxPath || undefined).available === false) {
      return Response.json(
        {
          ok: false,
          message: "Бинарный файл sing-box не найден",
          detail:
            "Положите sing-box в ./bin/ или пропишите путь в настройках. Релизы: https://github.com/SagerNet/sing-box/releases",
        },
        { status: 400 },
      );
    }

    let activeServer = null;
    if (settings.activeServerId) {
      const [s] = await db.select().from(servers).where(eq(servers.id, settings.activeServerId));
      activeServer = s || null;
    }

    const res = await startEngine(
      settings,
      activeServer ? (activeServer.config as Record<string, unknown>) : null,
      activeServer?.id ?? null,
      activeServer?.name ?? "(без сервера — direct)",
    );

    if (res.ok) {
      await addLog(
        "success",
        `sing-box запущен. Режим: ${
          settings.mode === "rule"
            ? "по правилам (OpenAI → прокси)"
            : settings.mode === "global"
              ? "глобальный"
              : "напрямую"
        }. Сервер: ${activeServer?.name ?? "не выбран"}. Порт: ${settings.listenPort}`,
      );
    } else {
      await addLog("error", `Не удалось запустить sing-box: ${res.message}`);
    }
    return Response.json(res, { status: res.ok ? 200 : 500 });
  }

  return Response.json({ error: "Неизвестное действие" }, { status: 400 });
}

