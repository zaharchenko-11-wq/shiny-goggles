import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Manrope, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { Shell } from "@/components/shell";

const manrope = Manrope({
  subsets: ["latin", "cyrillic"],
  variable: "--font-manrope",
  weight: ["400", "500", "600", "700", "800"],
});

const jbMono = JetBrains_Mono({
  subsets: ["latin", "cyrillic"],
  variable: "--font-jbmono",
  weight: ["400", "500", "600", "700"],
});

export const metadata: Metadata = {
  title: "SING·DECK — панель управления sing-box",
  description:
    "Смена IP-адреса для ChatGPT и Codex: управление ядром sing-box, серверами, маршрутизацией и конфигурацией.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ru" className={`${manrope.variable} ${jbMono.variable}`}>
      <body className="bg-bg font-sans text-ink antialiased">
        <Shell>{children}</Shell>
      </body>
    </html>
  );
}
