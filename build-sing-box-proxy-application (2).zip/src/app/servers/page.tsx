"use client";

import clsx from "clsx";
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Boxes,
  Crosshair,
  Pencil,
  Plus,
  RefreshCw,
  Search,
  SquareArrowOutUpRight,
  Trash2,
  Zap,
} from "lucide-react";
import Link from "next/link";
import { Btn, Card, CardHeader, Dot, Field, Input, Modal, Spinner, Textarea } from "@/components/ui";
import {
  jfetch,
  latencyColor,
  protocolColor,
  toast,
  type ServerItem,
} from "@/lib/client";
import { PROTOCOL_FORMS, PROTOCOL_LABELS, buildManualOutbound } from "@/lib/manual";

export default function ServersPage() {
  const [servers, setServers] = useState<ServerItem[]>([]);
  const [activeId, setActiveId] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [testing, setTesting] = useState<Set<number>>(new Set());
  const [testingAll, setTestingAll] = useState(false);
  const [edit, setEdit] = useState<ServerItem | null>(null);
  const [addOpen, setAddOpen] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<number | null>(null);

  const load = useCallback(async () => {
    try {
      const d = await jfetch<{ servers: ServerItem[]; activeServerId: number | null }>(
        "/api/servers",
      );
      setServers(d.servers);
      setActiveId(d.activeServerId);
    } catch (e) {
      toast(e instanceof Error ? e.message : "Ошибка загрузки", "error");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = q
      ? servers.filter(
          (s) =>
            s.name.toLowerCase().includes(q) ||
            s.address.toLowerCase().includes(q) ||
            s.protocol.toLowerCase().includes(q),
        )
      : servers;
    return [...list].sort((a, b) => (a.id === activeId ? -1 : b.id === activeId ? 1 : b.id - a.id));
  }, [servers, query, activeId]);

  async function testOne(id: number) {
    setTesting((s) => new Set(s).add(id));
    try {
      await jfetch(`/api/servers/${id}/test`, { method: "POST" });
    } catch {
      /* handled via latency null */
    } finally {
      setTesting((s) => {
        const n = new Set(s);
        n.delete(id);
        return n;
      });
    }
  }

  async function testAll() {
    setTestingAll(true);
    for (const s of filtered) {
      setTesting((set) => new Set(set).add(s.id));
      try {
        await jfetch(`/api/servers/${s.id}/test`, { method: "POST" });
      } catch {
        /* ignore */
      }
      setTesting((set) => {
        const n = new Set(set);
        n.delete(s.id);
        return n;
      });
      await load();
    }
    setTestingAll(false);
    toast("Тест задержки завершён", "success");
  }

  async function setActive(id: number) {
    try {
      await jfetch("/api/settings", {
        method: "PUT",
        body: JSON.stringify({ activeServerId: id }),
      });
      setActiveId(id);
      toast("Сервер назначен активным. Перезапустите движок, если он запущен.", "success");
      window.dispatchEvent(new Event("sd-refresh-control"));
    } catch (e) {
      toast(e instanceof Error ? e.message : "Ошибка", "error");
    }
  }

  async function remove(id: number) {
    try {
      await jfetch(`/api/servers/${id}`, { method: "DELETE" });
      toast("Сервер удалён", "info");
      setConfirmDelete(null);
      load();
    } catch (e) {
      toast(e instanceof Error ? e.message : "Ошибка удаления", "error");
    }
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="font-mono text-[10px] tracking-[0.3em] text-muted uppercase">
            панель / серверы
          </div>
          <h1 className="mt-2 text-3xl font-extrabold tracking-tight md:text-4xl">
            Серверы <span className="text-muted">/ {servers.length}</span>
          </h1>
        </div>
        <div className="flex items-center gap-2">
          <Btn variant="ghost" onClick={testAll} disabled={testingAll || !servers.length}>
            {testingAll ? <Spinner /> : <Zap size={14} />}
            Тест всех
          </Btn>
          <Btn variant="ghost" onClick={() => load()}>
            <RefreshCw size={14} />
          </Btn>
          <Link href="/import">
            <Btn variant="outline">
              <SquareArrowOutUpRight size={14} />
              Импорт
            </Btn>
          </Link>
          <Btn variant="primary" onClick={() => setAddOpen(true)}>
            <Plus size={15} />
            Добавить
          </Btn>
        </div>
      </div>

      <div className="relative">
        <Search size={14} className="absolute top-1/2 left-3.5 -translate-y-1/2 text-muted" />
        <Input
          placeholder="Поиск по имени, адресу или протоколу…"
          className="pl-9"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20 text-muted">
          <Spinner className="mr-2" /> загрузка…
        </div>
      ) : filtered.length === 0 ? (
        <Card className="border-dashed">
          <div className="flex flex-col items-center gap-4 px-6 py-16 text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-2xl border border-line bg-panel2 text-muted">
              <Boxes size={24} />
            </span>
            <div>
              <div className="text-lg font-bold">Серверов пока нет</div>
              <p className="mx-auto mt-1 max-w-sm text-[13px] text-sub">
                Импортируйте ссылки vless://, vmess://, trojan://, ss://, hysteria2://, tuic://
                или добавьте сервер вручную.
              </p>
            </div>
            <div className="flex gap-2">
              <Link href="/import">
                <Btn variant="primary">
                  <SquareArrowOutUpRight size={14} />
                  Импортировать ссылки
                </Btn>
              </Link>
              <Btn variant="outline" onClick={() => setAddOpen(true)}>
                <Plus size={14} />
                Вручную
              </Btn>
            </div>
          </div>
        </Card>
      ) : (
        <div className="flex flex-col gap-2">
          {filtered.map((s) => {
            const isActive = s.id === activeId;
            const isTesting = testing.has(s.id);
            return (
              <Card
                key={s.id}
                className={clsx(
                  "px-5 py-4 transition-all duration-200",
                  isActive
                    ? "border-acid/50 shadow-[0_0_30px_rgba(201,242,75,0.08)]"
                    : "hover:border-line2",
                )}
              >
                <div className="flex flex-wrap items-center gap-x-4 gap-y-3">
                  <Dot
                    color={s.status === "ok" ? "#4ade80" : s.status === "fail" ? "#ff6a5c" : "#5c6a71"}
                  />
                  <div className="min-w-0 flex-1 basis-52">
                    <div className="flex items-center gap-2">
                      <span className="truncate text-[14px] font-semibold text-ink">{s.name}</span>
                      {isActive && (
                        <span className="rounded-md bg-acid/15 px-1.5 py-0.5 font-mono text-[9px] font-bold tracking-widest text-acid uppercase">
                          активный
                        </span>
                      )}
                    </div>
                    <div className="mt-0.5 truncate font-mono text-[11px] text-muted">
                      {s.address}:{s.port}
                    </div>
                  </div>

                  <span
                    className="rounded-md px-2 py-1 font-mono text-[10px] font-bold tracking-wider uppercase"
                    style={{
                      color: protocolColor(s.protocol),
                      backgroundColor: `${protocolColor(s.protocol)}14`,
                      border: `1px solid ${protocolColor(s.protocol)}33`,
                    }}
                  >
                    {s.protocol}
                  </span>

                  <span
                    className={clsx(
                      "w-20 text-right font-mono text-[12px]",
                      latencyColor(s.latency),
                    )}
                  >
                    {isTesting ? <Spinner className="ml-auto" /> : s.latency != null ? `${s.latency} мс` : "—"}
                  </span>

                  <span className="hidden w-24 text-right font-mono text-[10px] text-muted uppercase lg:block">
                    {s.source === "uri" ? "ссылка" : s.source}
                  </span>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => testOne(s.id).then(load)}
                      disabled={isTesting}
                      title="Тест задержки (TCP)"
                      className="rounded-lg p-2 text-muted transition-colors hover:bg-panel2 hover:text-info"
                    >
                      <Zap size={15} />
                    </button>
                    <button
                      onClick={() => setActive(s.id)}
                      title="Сделать активным"
                      className={clsx(
                        "rounded-lg p-2 transition-colors hover:bg-panel2",
                        isActive ? "text-acid" : "text-muted hover:text-acid",
                      )}
                    >
                      <Crosshair size={15} />
                    </button>
                    <button
                      onClick={() => setEdit(s)}
                      title="Редактировать"
                      className="rounded-lg p-2 text-muted transition-colors hover:bg-panel2 hover:text-ink"
                    >
                      <Pencil size={15} />
                    </button>
                    <button
                      onClick={() => setConfirmDelete(s.id)}
                      title="Удалить"
                      className="rounded-lg p-2 text-muted transition-colors hover:bg-panel2 hover:text-danger"
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <EditModal server={edit} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); load(); }} />
      <AddModal open={addOpen} onClose={() => setAddOpen(false)} onSaved={() => { setAddOpen(false); load(); }} />
      <DeleteConfirm id={confirmDelete} onCancel={() => setConfirmDelete(null)} onConfirm={remove} />
    </div>
  );
}

/* ---------------- edit modal ---------------- */

function EditModal({
  server,
  onClose,
  onSaved,
}: {
  server: ServerItem | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [name, setName] = useState("");
  const [json, setJson] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (server) {
      setName(server.name);
      setJson(JSON.stringify(server.config, null, 2));
    }
  }, [server]);

  async function save() {
    setSaving(true);
    try {
      let config: unknown;
      try {
        config = JSON.parse(json);
      } catch {
        throw new Error("JSON невалиден — проверьте синтаксис");
      }
      await jfetch(`/api/servers/${server!.id}`, {
        method: "PATCH",
        body: JSON.stringify({ name, config }),
      });
      toast("Сервер обновлён", "success");
      onSaved();
    } catch (e) {
      toast(e instanceof Error ? e.message : "Ошибка сохранения", "error");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal open={!!server} onClose={onClose} title="Редактировать сервер" wide>
      <div className="flex flex-col gap-4">
        <Field label="Название">
          <Input value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="Outbound JSON (sing-box)" hint="Поле tag будет заменено на «proxy» при генерации конфига">
          <Textarea rows={14} value={json} onChange={(e) => setJson(e.target.value)} spellCheck={false} />
        </Field>
        <div className="flex justify-end gap-2">
          <Btn variant="ghost" onClick={onClose}>
            Отмена
          </Btn>
          <Btn variant="primary" onClick={save} disabled={saving}>
            {saving && <Spinner />}
            Сохранить
          </Btn>
        </div>
      </div>
    </Modal>
  );
}

/* ---------------- add modal ---------------- */

function AddModal({
  open,
  onClose,
  onSaved,
}: {
  open: boolean;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [protocol, setProtocol] = useState("vless");
  const [values, setValues] = useState<Record<string, string>>({ security: "reality" });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setProtocol("vless");
      setValues({ security: "reality" });
    }
  }, [open]);

  function setField(k: string, v: string) {
    setValues((prev) => ({ ...prev, [k]: v }));
  }

  async function save() {
    setSaving(true);
    try {
      const { outbound, name } = buildManualOutbound(protocol, values);
      outbound.tag = name;
      await jfetch("/api/servers", {
        method: "POST",
        body: JSON.stringify({ name, config: outbound }),
      });
      toast(`Сервер «${name}» добавлен`, "success");
      onSaved();
    } catch (e) {
      toast(e instanceof Error ? e.message : "Ошибка", "error");
    } finally {
      setSaving(false);
    }
  }

  const specs = (PROTOCOL_FORMS[protocol] || []).filter((f) => !f.show || f.show(values));

  return (
    <Modal open={open} onClose={onClose} title="Добавить сервер вручную" wide>
      <div className="flex flex-col gap-4">
        <div className="flex flex-wrap gap-1.5">
          {Object.keys(PROTOCOL_FORMS).map((p) => (
            <button
              key={p}
              onClick={() => {
                setProtocol(p);
                setValues(p === "vless" ? { security: "reality" } : {});
              }}
              className={clsx(
                "rounded-lg border px-3 py-1.5 font-mono text-[11px] font-semibold transition-all",
                protocol === p
                  ? "border-acid/60 bg-acid/10 text-acid"
                  : "border-line bg-panel2 text-muted hover:text-sub",
              )}
            >
              {PROTOCOL_LABELS[p]}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          {specs.map((f) => {
            if (f.type === "checkbox") {
              return (
                <label
                  key={f.key}
                  className="flex h-10 cursor-pointer items-center gap-2.5 rounded-xl border border-line2 bg-bg px-3"
                >
                  <input
                    type="checkbox"
                    checked={values[f.key] === "1"}
                    onChange={(e) => setField(f.key, e.target.checked ? "1" : "")}
                    className="h-3.5 w-3.5 accent-[#c9f24b]"
                  />
                  <span className="text-[13px] text-sub">{f.label}</span>
                </label>
              );
            }
            if (f.type === "select") {
              return (
                <Field key={f.key} label={f.label}>
                  <select
                    value={values[f.key] ?? f.options?.[0] ?? ""}
                    onChange={(e) => setField(f.key, e.target.value)}
                    className="h-10 w-full rounded-xl border border-line2 bg-bg px-3 font-mono text-sm text-ink outline-none focus:border-acid/70"
                  >
                    {f.options?.map((o) => (
                      <option key={o} value={o}>
                        {o || "(нет)"}
                      </option>
                    ))}
                  </select>
                </Field>
              );
            }
            return (
              <Field key={f.key} label={f.label + (f.required ? " *" : "")} hint={f.hint}>
                <Input
                  type={f.type === "number" ? "number" : "text"}
                  placeholder={f.placeholder}
                  value={values[f.key] ?? ""}
                  onChange={(e) => setField(f.key, e.target.value)}
                />
              </Field>
            );
          })}
        </div>

        <div className="flex justify-end gap-2 pt-1">
          <Btn variant="ghost" onClick={onClose}>
            Отмена
          </Btn>
          <Btn variant="primary" onClick={save} disabled={saving}>
            {saving && <Spinner />}
            Добавить сервер
          </Btn>
        </div>
      </div>
    </Modal>
  );
}

/* ---------------- delete confirm ---------------- */

function DeleteConfirm({
  id,
  onCancel,
  onConfirm,
}: {
  id: number | null;
  onCancel: () => void;
  onConfirm: (id: number) => void;
}) {
  return (
    <Modal open={id !== null} onClose={onCancel} title="Удалить сервер?">
      <p className="text-sm text-sub">
        Запись будет удалена из базы. Если сервер активен — активность сбросится.
      </p>
      <div className="mt-5 flex justify-end gap-2">
        <Btn variant="ghost" onClick={onCancel}>
          Отмена
        </Btn>
        <Btn variant="danger" onClick={() => id !== null && onConfirm(id)}>
          <Trash2 size={14} />
          Удалить
        </Btn>
      </div>
    </Modal>
  );
}
