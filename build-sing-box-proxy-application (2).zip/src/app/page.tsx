"use client";

import clsx from "clsx";
import { motion } from "framer-motion";
import {
  AlertTriangle,
  ArrowRight,
  Boxes,
  ChevronDown,
  CircleStop,
  Globe2,
  ListFilter,
  Play,
  RefreshCw,
  ShieldCheck,
  Terminal,
  Zap,
} from "lucide-react";
import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import { Btn, Card, CardHeader, CopyBtn, Dot, Spinner } from "@/components/ui";
import {
  fmtTime,
  jfetch,
  protocolColor,
  toast,
  type ControlState,
  type IpInfoData,
  type ServerItem,
} from "@/lib/client";

type IpState =
  | { kind: "idle" }
  | { kind: "loading" }
  | { kind: "ok"; info: IpInfoData }
  | { kind: "error"; message: string };

const MODE_LABEL = { rule: "По правилам", global: "Глобально", direct: "Напрямую" } as const;
const MODE_ICON = { rule: ListFilter, global: Globe2, direct: ArrowRight } as const;

export default function DashboardPage() {
  const [ctl, setCtl] = useState<ControlState | null>(null);
  const [servers, setServers] = useState<ServerItem[]>([]);
  const [busy, setBusy] = useState<"start" | "stop" | null>(null);
  const [ipDirect, setIpDirect] = useState<IpState>({ kind: "idle" });
  const [ipProxy, setIpProxy] = useState<IpState>({ kind: "idle" });
  const busyRef = useRef(false);

  const refreshControl = useCallback(async () => {
    try {
      const d = await jfetch<ControlState>("/api/control");
      setCtl(d);
    } catch {
      /* offline */
    }
  }, []);

  const refreshServers = useCallback(async () => {
    try {
      const d = await jfetch<{ servers: ServerItem[] }>("/api/servers");
      setServers(d.servers);
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    refreshControl();
    refreshServers();
    const t = setInterval(() => {
      if (!busyRef.current) refreshControl();
    }, 5000);
    return () => clearInterval(t);
  }, [refreshControl, refreshServers]);

  const loadIp = useCallback(async (via: "direct" | "proxy") => {
    const set = via === "direct" ? setIpDirect : setIpProxy;
    set({ kind: "loading" });
    try {
      const d = await jfetch<{ info: IpInfoData }>(`/api/ip${via === "proxy" ? "?via=proxy" : ""}`);
      set({ kind: "ok", info: d.info });
    } catch (e) {
      set({ kind: "error", message: e instanceof Error ? e.message : "Ошибка" });
    }
  }, []);

  useEffect(() => {
    loadIp("direct");
  }, [loadIp]);

  const engine = ctl?.engine;
  const running = !!engine?.running;
  const activeServer = ctl?.activeServer ?? null;

  useEffect(() => {
    if (running && ipProxy.kind === "idle") loadIp("proxy");
  }, [running, ipProxy.kind, loadIp]);

  async function control(action: "start" | "stop" | "restart") {
    busyRef.current = true;
    setBusy(action === "stop" ? "stop" : "start");
    try {
      const res = await jfetch<{ ok: boolean; message: string; detail?: string }>(
        "/api/control",
        { method: "POST", body: JSON.stringify({ action }) },
      );
      toast(res.message, "success");
      if (action !== "stop") setTimeout(() => loadIp("proxy"), 1200);
    } catch (e) {
      const err = e as Error & { detail?: string };
      toast(err.message, "error");
      if (err.detail) toast(err.detail.slice(0, 200), "error");
    } finally {
      setBusy(null);
      busyRef.current = false;
      refreshControl();
      window.dispatchEvent(new Event("sd-refresh-control"));
    }
  }

  async function setActive(id: number) {
    try {
      await jfetch("/api/settings", {
        method: "PUT",
        body: JSON.stringify({ activeServerId: id }),
      });
      toast("Активный сервер обновлён", "success");
      refreshControl();
      window.dispatchEvent(new Event("sd-refresh-control"));
    } catch (e) {
      toast(e instanceof Error ? e.message : "Ошибка", "error");
    }
  }

  const settings = ctl?.settings;
  const ModeIcon = MODE_ICON[settings?.mode ?? "rule"];

  return (
    <div className="flex flex-col gap-5">
      {/* header */}
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="font-mono text-[10px] tracking-[0.3em] text-muted uppercase">
            панель / обзор
          </div>
          <h1 className="mt-2 text-3xl font-extrabold tracking-tight md:text-4xl">
            Смена IP для{" "}
            <span className="text-acid">ChatGPT · Codex</span>
          </h1>
          <p className="mt-2 max-w-xl text-[13px] leading-relaxed text-sub">
            Движок запускает локальный прокси-вход и направляет домены OpenAI
            через выбранный сервер — остальной трафик идёт напрямую.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-2 rounded-xl border border-line bg-panel px-3 py-2 font-mono text-[11px] text-sub">
            <ModeIcon size={13} className="text-acid" />
            {MODE_LABEL[settings?.mode ?? "rule"]}
          </span>
          <span
            className={clsx(
              "inline-flex items-center gap-2 rounded-xl border px-3 py-2 font-mono text-[11px]",
              running
                ? "border-acid/40 bg-acid/10 text-acid"
                : "border-line bg-panel text-sub",
            )}
          >
            <Dot color={running ? "#c9f24b" : "#5c6a71"} pulse={running} />
            {running ? "ОНЛАЙН" : "ОФФЛАЙН"}
          </span>
        </div>
      </div>

      {/* hero row */}
      <div className="grid grid-cols-1 gap-5 xl:grid-cols-12">
        {/* control card */}
        <Card className="xl:col-span-5">
          <CardHeader
            title="Управление движком"
            hint={engine?.version ? `sing-box v${engine.version}` : "ядро sing-box"}
            right={
              engine?.running ? (
                <span className="font-mono text-[10px] text-muted">pid {engine.pid}</span>
              ) : undefined
            }
          />
          <div className="flex flex-col gap-4 px-6 py-5">
            {engine && !engine.available && (
              <div className="rounded-xl border border-warn/30 bg-warn/5 p-4">
                <div className="flex items-center gap-2 text-sm font-semibold text-warn">
                  <AlertTriangle size={15} />
                  Бинарный файл sing-box не найден
                </div>
                <p className="mt-2 text-xs leading-relaxed text-sub">
                  Положите sing-box в <span className="font-mono text-ink">./bin/sing-box</span> или
                  укажите путь в настройках. Скачать:
                </p>
                <div className="mt-2 flex items-center justify-between gap-2 rounded-lg bg-bg px-3 py-2 font-mono text-[10px] text-sub">
                  <span className="truncate">github.com/SagerNet/sing-box/releases</span>
                  <CopyBtn text="https://github.com/SagerNet/sing-box/releases" label="" />
                </div>
              </div>
            )}

            <div>
              <div className="mb-1.5 font-mono text-[10px] tracking-[0.2em] text-sub uppercase">
                Активный сервер
              </div>
              <div className="relative">
                <select
                  value={settings?.activeServerId ?? ""}
                  onChange={(e) => setActive(Number(e.target.value))}
                  className="h-11 w-full appearance-none rounded-xl border border-line2 bg-bg px-3 pr-9 text-sm text-ink outline-none transition-colors focus:border-acid/70"
                >
                  <option value="" disabled>
                    {servers.length ? "Выберите сервер…" : "Нет серверов — импортируйте"}
                  </option>
                  {servers.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} — {s.protocol.toUpperCase()} · {s.address}:{s.port}
                    </option>
                  ))}
                </select>
                <ChevronDown
                  size={14}
                  className="pointer-events-none absolute top-1/2 right-3 -translate-y-1/2 text-muted"
                />
              </div>
              {activeServer && (
                <div className="mt-2 flex items-center gap-2 text-[11px]">
                  <span
                    className="rounded-md px-1.5 py-0.5 font-mono text-[9px] font-bold tracking-wider uppercase"
                    style={{
                      color: protocolColor(activeServer.protocol),
                      backgroundColor: `${protocolColor(activeServer.protocol)}1a`,
                    }}
                  >
                    {activeServer.protocol}
                  </span>
                  <span className="font-mono text-muted">
                    {activeServer.address}:{activeServer.port}
                  </span>
                  {activeServer.latency != null && (
                    <span className="ml-auto font-mono text-[10px] text-info">
                      {activeServer.latency} мс
                    </span>
                  )}
                </div>
              )}
            </div>

            <div className="flex gap-2">
              {!running ? (
                <Btn
                  variant="primary"
                  size="lg"
                  className="flex-1"
                  disabled={busy !== null || engine?.available === false}
                  onClick={() => control("start")}
                >
                  {busy === "start" ? <Spinner /> : <Play size={17} />}
                  Запустить
                </Btn>
              ) : (
                <>
                  <Btn
                    variant="danger"
                    size="lg"
                    className="flex-1"
                    disabled={busy !== null}
                    onClick={() => control("stop")}
                  >
                    {busy === "stop" ? <Spinner /> : <CircleStop size={17} />}
                    Остановить
                  </Btn>
                  <Btn
                    variant="outline"
                    size="lg"
                    disabled={busy !== null}
                    onClick={() => control("restart")}
                  >
                    <RefreshCw size={16} />
                  </Btn>
                </>
              )}
            </div>

            <div className="grid grid-cols-3 gap-2 text-center">
              {[
                { k: "порт", v: `:${settings?.listenPort ?? 2080}` },
                { k: "режим", v: MODE_LABEL[settings?.mode ?? "rule"] },
                { k: "старт", v: running ? fmtTime(engine?.startedAt).split(",")[0] : "—" },
              ].map((m) => (
                <div key={m.k} className="rounded-lg border border-line bg-panel2 px-2 py-2">
                  <div className="font-mono text-[9px] tracking-[0.2em] text-muted uppercase">
                    {m.k}
                  </div>
                  <div className="mt-0.5 truncate font-mono text-[12px] text-ink">{m.v}</div>
                </div>
              ))}
            </div>
          </div>
        </Card>

        {/* IP compare card */}
        <Card className="xl:col-span-7">
          <CardHeader
            title="Внешний IP-адрес"
            hint="сравнение: напрямую / через прокси"
            right={<ShieldCheck size={16} className={running ? "text-acid" : "text-muted"} />}
          />
          <div className="grid grid-cols-1 gap-0 sm:grid-cols-2">
            <IpPane
              title="Напрямую"
              state={ipDirect}
              onRefresh={() => loadIp("direct")}
              accent="#93a2aa"
            />
            <div className="relative border-t border-line sm:border-t-0 sm:border-l">
              <div className="absolute top-1/2 -left-3 z-10 hidden h-6 w-6 -translate-y-1/2 items-center justify-center rounded-full border border-line bg-panel sm:flex">
                <ArrowRight size={12} className="text-acid" />
              </div>
              <IpPane
                title="Через прокси"
                state={ipProxy}
                onRefresh={() => loadIp("proxy")}
                accent="#c9f24b"
                running={running}
              />
            </div>
          </div>
        </Card>
      </div>

      {/* routing visualization */}
      <RoutingMap ctl={ctl} running={running} />

      {/* stats row */}
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <StatCard
          label="Серверов в базе"
          value={String(servers.length)}
          sub="vless · vmess · trojan · ss · hy2 · tuic"
          icon={<Boxes size={15} />}
          href="/servers"
        />
        <StatCard
          label="Лучшая задержка"
          value={
            servers.filter((s) => s.latency != null).length
              ? `${Math.min(...servers.filter((s) => s.latency != null).map((s) => s.latency!))} мс`
              : "—"
          }
          sub="по последнему тесту TCP"
          icon={<Zap size={15} />}
          href="/servers"
        />
        <StatCard
          label="Домены OpenAI"
          value={String(settings?.proxyDomains?.length ?? 0)}
          sub="маршрутизируются в прокси"
          icon={<ListFilter size={15} />}
          href="/settings"
        />
        <StatCard
          label="Локальный вход"
          value={`127.0.0.1:${settings?.listenPort ?? 2080}`}
          sub="SOCKS5 + HTTP mixed"
          icon={<Terminal size={15} />}
          href="/config"
        />
      </div>
    </div>
  );
}

/* ---------------- IP pane ---------------- */

function IpPane({
  title,
  state,
  onRefresh,
  accent,
  running,
}: {
  title: string;
  state: IpState;
  onRefresh: () => void;
  accent: string;
  running?: boolean;
}) {
  return (
    <div className="flex min-h-[210px] flex-col px-6 py-5">
      <div className="flex items-center justify-between">
        <span className="font-mono text-[10px] tracking-[0.24em] uppercase" style={{ color: accent }}>
          {title}
        </span>
        <button
          onClick={onRefresh}
          className="rounded-lg p-1.5 text-muted transition-colors hover:bg-panel2 hover:text-ink"
          title="Обновить"
        >
          {state.kind === "loading" ? <Spinner /> : <RefreshCw size={13} />}
        </button>
      </div>

      {state.kind === "ok" ? (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-3">
          <div className="font-mono text-[26px] leading-none font-bold tracking-tight text-ink md:text-[30px]">
            {state.info.ip}
          </div>
          <div className="mt-4 flex flex-col gap-1.5 font-mono text-[11px]">
            <Row k="страна" v={`${state.info.countryCode || "—"} · ${state.info.country || "—"}`} />
            <Row k="город" v={state.info.city || "—"} />
            <Row k="сеть" v={state.info.org || "—"} />
            <Row k="api" v={state.info.source} dim />
          </div>
        </motion.div>
      ) : state.kind === "loading" ? (
        <div className="mt-6 flex items-center gap-2 font-mono text-xs text-muted">
          <Spinner /> запрос внешнего IP…
        </div>
      ) : state.kind === "error" ? (
        <div className="mt-6 font-mono text-xs leading-relaxed text-danger">{state.message}</div>
      ) : (
        <div className="mt-6 font-mono text-xs text-muted">
          {running === false ? "прокси не запущен" : "—"}
        </div>
      )}
    </div>
  );
}

function Row({ k, v, dim }: { k: string; v: string; dim?: boolean }) {
  return (
    <div className="flex gap-3">
      <span className="w-14 shrink-0 text-muted">{k}</span>
      <span className={clsx("truncate", dim ? "text-muted" : "text-sub")}>{v}</span>
    </div>
  );
}

/* ---------------- routing map ---------------- */

function RoutingMap({ ctl, running }: { ctl: ControlState | null; running: boolean }) {
  const domains = (ctl?.settings.proxyDomains ?? []).slice(0, 6);
  const mode = ctl?.settings.mode ?? "rule";
  const serverName = ctl?.activeServer?.name ?? "сервер не выбран";
  const port = ctl?.settings.listenPort ?? 2080;

  const chipY = (i: number) => 26 + i * 52;
  const midX = 368;
  const midTop = 156;
  const midBottom = 194;

  const proxyHot = running && mode !== "direct";
  const directHot = mode !== "global";
  const lime = "#c9f24b";
  const dim = "#39434a";

  return (
    <Card>
      <CardHeader
        title="Карта маршрутизации"
        hint={
          mode === "rule"
            ? "домены OpenAI → прокси · остальное → напрямую"
            : mode === "global"
              ? "весь трафик → прокси"
              : "весь трафик → напрямую (прокси не используется)"
        }
        right={
          <span className="rounded-lg border border-line bg-panel2 px-2.5 py-1 font-mono text-[10px] text-sub">
            sing-box route engine
          </span>
        }
      />
      <div className="overflow-x-auto px-4 py-4">
        <svg viewBox="0 0 920 380" className="w-full min-w-[640px]" role="img" aria-label="routing map">
          {/* labels */}
          <text x="20" y="14" fill="#5c6a71" fontSize="10" fontFamily="var(--font-jbmono), monospace" letterSpacing="2">
            ДОМЕНЫ OPENAI
          </text>
          <text x="700" y="42" fill="#5c6a71" fontSize="10" fontFamily="var(--font-jbmono), monospace" letterSpacing="2">
            ВЫХОД В ИНТЕРНЕТ
          </text>

          {/* domain chips → center */}
          {domains.map((d, i) => {
            const y = chipY(i) + 16;
            const pathStr = `M228 ${y} C 300 ${y}, 320 ${midTop + 30}, ${midX} ${midTop + 30}`;
            return (
              <g key={d}>
                <rect x="16" y={chipY(i)} width="212" height="34" rx="10" fill="#10161a" stroke="#1c2429" />
                <circle cx="34" cy={y} r="3" fill={proxyHot ? lime : "#5c6a71"} />
                <text x="48" y={y + 4} fill="#93a2aa" fontSize="12" fontFamily="var(--font-jbmono), monospace">
                  {d}
                </text>
                <path
                  d={pathStr}
                  fill="none"
                  stroke={proxyHot ? lime : dim}
                  strokeWidth="1.4"
                  className={proxyHot ? "flow-line" : "flow-line-slow"}
                  opacity={proxyHot ? 0.9 : 0.35}
                />
                {proxyHot && (
                  <circle r="2.6" fill={lime}>
                    <animateMotion dur={`${2.2 + i * 0.35}s`} repeatCount="indefinite" path={pathStr} />
                  </circle>
                )}
              </g>
            );
          })}

          {/* rest traffic chip */}
          <rect x="16" y="336" width="212" height="30" rx="10" fill="transparent" stroke="#1c2429" strokeDasharray="4 4" />
          <text x="30" y="356" fill="#5c6a71" fontSize="11" fontFamily="var(--font-jbmono), monospace">
            весь остальной трафик
          </text>
          <path
            d={`M228 351 C 300 351, 320 ${midBottom + 8}, ${midX} ${midBottom + 8}`}
            fill="none"
            stroke={directHot ? "#93a2aa" : dim}
            strokeWidth="1.4"
            className="flow-line-slow"
            opacity={directHot ? 0.6 : 0.25}
          />

          {/* center node */}
          <g>
            <rect
              x={midX}
              y={midTop - 26}
              width="186"
              height="96"
              rx="16"
              fill="#0e1317"
              stroke={running ? lime : "#29343b"}
              strokeWidth={running ? 1.6 : 1}
              style={running ? { filter: "drop-shadow(0 0 14px rgba(201,242,75,0.25))" } : undefined}
            />
            <text x={midX + 93} y={midTop + 2} textAnchor="middle" fill="#e9f1ec" fontSize="15" fontWeight="700" fontFamily="var(--font-jbmono), monospace">
              SING-BOX
            </text>
            <text x={midX + 93} y={midTop + 22} textAnchor="middle" fill="#5c6a71" fontSize="10" fontFamily="var(--font-jbmono), monospace">
              mixed · 127.0.0.1:{port}
            </text>
            <circle cx={midX + 93} cy={midTop + 48} r="3.5" fill={running ? lime : "#5c6a71"}>
              {running && <animate attributeName="opacity" values="1;0.3;1" dur="1.6s" repeatCount="indefinite" />}
            </circle>
          </g>

          {/* center → proxy node */}
          <path
            d={`M${midX + 186} ${midTop - 4} C 640 ${midTop - 4}, 648 92, 700 92`}
            fill="none"
            stroke={proxyHot ? lime : dim}
            strokeWidth="1.6"
            className={proxyHot ? "flow-line" : "flow-line-slow"}
            opacity={proxyHot ? 1 : 0.3}
          />
          {proxyHot && (
            <circle r="3" fill={lime}>
              <animateMotion dur="1.6s" repeatCount="indefinite" path={`M${midX + 186} ${midTop - 4} C 640 ${midTop - 4}, 648 92, 700 92`} />
            </circle>
          )}

          {/* center → direct */}
          <path
            d={`M${midX + 186} ${midBottom + 16} C 640 ${midBottom + 16}, 648 292, 700 292`}
            fill="none"
            stroke={directHot ? "#93a2aa" : dim}
            strokeWidth="1.4"
            className="flow-line-slow"
            opacity={directHot ? 0.7 : 0.25}
          />

          {/* proxy node box */}
          <rect x="700" y="60" width="204" height="64" rx="14" fill="#0e1317" stroke={proxyHot ? lime : "#29343b"} strokeWidth={proxyHot ? 1.4 : 1} />
          <text x="716" y="84" fill={proxyHot ? lime : "#5c6a71"} fontSize="9" fontFamily="var(--font-jbmono), monospace" letterSpacing="2">
            PROXY {proxyHot ? "● LIVE" : ""}
          </text>
          <text x="716" y="106" fill="#e9f1ec" fontSize="12" fontFamily="var(--font-jbmono), monospace">
            {serverName.length > 26 ? serverName.slice(0, 26) + "…" : serverName}
          </text>

          {/* direct box */}
          <rect x="700" y="260" width="204" height="64" rx="14" fill="transparent" stroke="#29343b" />
          <text x="716" y="284" fill="#5c6a71" fontSize="9" fontFamily="var(--font-jbmono), monospace" letterSpacing="2">
            DIRECT
          </text>
          <text x="716" y="306" fill="#93a2aa" fontSize="12" fontFamily="var(--font-jbmono), monospace">
            ваш реальный IP
          </text>
        </svg>
      </div>
    </Card>
  );
}

/* ---------------- stat card ---------------- */

function StatCard({
  label,
  value,
  sub,
  icon,
  href,
}: {
  label: string;
  value: string;
  sub: string;
  icon: React.ReactNode;
  href: string;
}) {
  return (
    <Link href={href}>
      <Card className="group px-5 py-4 transition-colors duration-200 hover:border-line2">
        <div className="flex items-center justify-between">
          <span className="font-mono text-[9px] tracking-[0.22em] text-muted uppercase">{label}</span>
          <span className="text-muted transition-colors group-hover:text-acid">{icon}</span>
        </div>
        <div className="mt-2 truncate text-xl font-bold tracking-tight text-ink">{value}</div>
        <div className="mt-1 truncate text-[10px] text-muted">{sub}</div>
      </Card>
    </Link>
  );
}
