"use client";

import { useCallback, useEffect, useState } from "react";
import {
  CheckCircle2,
  FlaskConical,
  Link2,
  LoaderCircle,
  RefreshCw,
  SquareArrowOutUpRight,
  Trash2,
  XCircle,
} from "lucide-react";
import { Btn, Card, CardHeader, Field, Input, Spinner, Textarea } from "@/components/ui";
import { fmtTime, jfetch, toast } from "@/lib/client";

interface ImportResult {
  added: number;
  skipped: number;
  failed: { line: string; error: string }[];
  total: number;
}

interface Subscription {
  id: number;
  name: string;
  url: string;
  serversCount: number;
  updatedAt: string;
}

const DEMO_SERVERS = [
  {
    name: "DEMO · NL — VLESS Reality",
    config: {
      type: "vless",
      tag: "DEMO · NL — VLESS Reality",
      server: "203.0.113.10",
      server_port: 443,
      uuid: "11111111-2222-3333-4444-555555555555",
      flow: "xtls-rprx-vision",
      tls: {
        enabled: true,
        server_name: "www.microsoft.com",
        utls: { enabled: true, fingerprint: "chrome" },
        reality: { enabled: true, public_key: "jNXHtGgz5rnbhVYDnBmwip7KevprQJKZDrVYw1aF-xs", short_id: "0123abcd" },
      },
    },
  },
  {
    name: "DEMO · DE — Hysteria2",
    config: {
      type: "hysteria2",
      tag: "DEMO · DE — Hysteria2",
      server: "198.51.100.7",
      server_port: 8443,
      password: "demo-password",
      tls: { enabled: true, server_name: "bing.com" },
    },
  },
  {
    name: "DEMO · JP — Shadowsocks",
    config: {
      type: "shadowsocks",
      tag: "DEMO · JP — Shadowsocks",
      server: "192.0.2.44",
      server_port: 8388,
      method: "aes-256-gcm",
      password: "demo-password",
    },
  },
];

export default function ImportPage() {
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<ImportResult | null>(null);

  const [subUrl, setSubUrl] = useState("");
  const [subName, setSubName] = useState("");
  const [subs, setSubs] = useState<Subscription[]>([]);
  const [subBusy, setSubBusy] = useState<number | "new" | null>(null);

  const loadSubs = useCallback(async () => {
    try {
      const d = await jfetch<{ subscriptions: Subscription[] }>("/api/servers/import");
      setSubs(d.subscriptions);
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    loadSubs();
  }, [loadSubs]);

  async function importText() {
    if (!text.trim()) return;
    setBusy(true);
    setResult(null);
    try {
      const r = await jfetch<ImportResult>("/api/servers/import", {
        method: "POST",
        body: JSON.stringify({ text }),
      });
      setResult(r);
      if (r.added > 0) setText("");
      toast(`Добавлено серверов: ${r.added}`, r.added > 0 ? "success" : "info");
    } catch (e) {
      toast(e instanceof Error ? e.message : "Ошибка импорта", "error");
    } finally {
      setBusy(false);
    }
  }

  async function importUrl(url: string, name: string, key: number | "new") {
    setSubBusy(key);
    try {
      const r = await jfetch<ImportResult>("/api/servers/import", {
        method: "POST",
        body: JSON.stringify({ url, name }),
      });
      toast(`Подписка: добавлено ${r.added} из ${r.total}`, "success");
      if (key === "new") {
        setSubUrl("");
        setSubName("");
      }
      loadSubs();
    } catch (e) {
      toast(e instanceof Error ? e.message : "Ошибка загрузки подписки", "error");
    } finally {
      setSubBusy(null);
    }
  }

  async function deleteSub(id: number) {
    try {
      await jfetch(`/api/servers/import?id=${id}`, { method: "DELETE" });
      loadSubs();
    } catch (e) {
      toast(e instanceof Error ? e.message : "Ошибка", "error");
    }
  }

  async function addDemo() {
    try {
      for (const d of DEMO_SERVERS) {
        await jfetch("/api/servers", {
          method: "POST",
          body: JSON.stringify({ name: d.name, config: d.config, source: "demo" }),
        });
      }
      toast("Демо-набор добавлен (адреса недоступны — только для интерфейса)", "success");
    } catch (e) {
      toast(e instanceof Error ? e.message : "Ошибка", "error");
    }
  }

  return (
    <div className="flex flex-col gap-5">
      <div>
        <div className="font-mono text-[10px] tracking-[0.3em] text-muted uppercase">
          панель / импорт
        </div>
        <h1 className="mt-2 text-3xl font-extrabold tracking-tight md:text-4xl">Импорт серверов</h1>
        <p className="mt-2 max-w-xl text-[13px] leading-relaxed text-sub">
          Поддерживаются ссылки vless://, vmess://, trojan://, ss://, hysteria2://, hy2://, tuic://
          и подписки в base64.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-5 xl:grid-cols-2">
        {/* links */}
        <Card>
          <CardHeader title="Вставить ссылки" hint="по одной на строку — vless, vmess, trojan, ss, hy2, tuic" />
          <div className="flex flex-col gap-3 px-6 py-5">
            <Textarea
              rows={9}
              spellCheck={false}
              placeholder={"vless://uuid@host:443?security=reality&pbk=...#NL-1\nvmess://eyJ2IjoiMiIs...\nss://YWVzLTI1Ni1nY206cGFzc0AxLjIuMy40OjgzODg=#JP"}
              value={text}
              onChange={(e) => setText(e.target.value)}
            />
            <div className="flex items-center justify-between">
              <span className="font-mono text-[10px] text-muted">
                {text.split("\n").filter((l) => /^(vless|vmess|trojan|ss|hysteria2|hy2|tuic):\/\//.test(l.trim())).length} распознано
              </span>
              <Btn variant="primary" onClick={importText} disabled={busy || !text.trim()}>
                {busy ? <Spinner /> : <SquareArrowOutUpRight size={14} />}
                Импортировать
              </Btn>
            </div>

            {result && (
              <div className="rounded-xl border border-line bg-panel2 p-4">
                <div className="flex flex-wrap gap-2 font-mono text-[11px]">
                  <span className="inline-flex items-center gap-1.5 rounded-md bg-acid/10 px-2 py-1 text-acid">
                    <CheckCircle2 size={12} /> добавлено: {result.added}
                  </span>
                  <span className="inline-flex items-center gap-1.5 rounded-md bg-panel3 px-2 py-1 text-sub">
                    дубликаты: {result.skipped}
                  </span>
                  {result.failed.length > 0 && (
                    <span className="inline-flex items-center gap-1.5 rounded-md bg-danger/10 px-2 py-1 text-danger">
                      <XCircle size={12} /> ошибок: {result.failed.length}
                    </span>
                  )}
                </div>
                {result.failed.length > 0 && (
                  <div className="mt-3 max-h-32 overflow-y-auto rounded-lg bg-bg p-3 font-mono text-[10px] leading-relaxed text-danger/90">
                    {result.failed.map((f, i) => (
                      <div key={i} className="truncate">
                        {f.line} — {f.error}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </Card>

        {/* subscriptions */}
        <Card>
          <CardHeader title="Подписка по URL" hint="endpoint с base64-списком ссылок" />
          <div className="flex flex-col gap-3 px-6 py-5">
            <Field label="URL подписки">
              <Input
                placeholder="https://provider.example/sub/abcdef"
                value={subUrl}
                onChange={(e) => setSubUrl(e.target.value)}
              />
            </Field>
            <Field label="Название (необязательно)">
              <Input placeholder="Мой провайдер" value={subName} onChange={(e) => setSubName(e.target.value)} />
            </Field>
            <div className="flex justify-end">
              <Btn
                variant="primary"
                disabled={subBusy !== null || !subUrl.trim()}
                onClick={() => importUrl(subUrl.trim(), subName.trim(), "new")}
              >
                {subBusy === "new" ? <Spinner /> : <Link2 size={14} />}
                Добавить подписку
              </Btn>
            </div>

            {subs.length > 0 && (
              <div className="mt-2 flex flex-col gap-2">
                {subs.map((s) => (
                  <div
                    key={s.id}
                    className="flex items-center gap-3 rounded-xl border border-line bg-panel2 px-4 py-3"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-[13px] font-semibold text-ink">{s.name}</div>
                      <div className="truncate font-mono text-[10px] text-muted">
                        {s.serversCount} узлов · обновлена {fmtTime(s.updatedAt)}
                      </div>
                    </div>
                    <button
                      onClick={() => importUrl(s.url, s.name, s.id)}
                      title="Обновить"
                      className="rounded-lg p-2 text-muted transition-colors hover:bg-panel3 hover:text-acid"
                    >
                      {subBusy === s.id ? (
                        <LoaderCircle size={14} className="spin-slow" />
                      ) : (
                        <RefreshCw size={14} />
                      )}
                    </button>
                    <button
                      onClick={() => deleteSub(s.id)}
                      title="Удалить"
                      className="rounded-lg p-2 text-muted transition-colors hover:bg-panel3 hover:text-danger"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </Card>
      </div>

      {/* demo */}
      <Card className="border-dashed">
        <div className="flex flex-wrap items-center justify-between gap-4 px-6 py-5">
          <div className="flex items-center gap-4">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl border border-line bg-panel2 text-warn">
              <FlaskConical size={17} />
            </span>
            <div>
              <div className="text-sm font-bold">Демо-набор серверов</div>
              <div className="mt-0.5 text-[12px] text-sub">
                Три записи с тестовыми адресами (TEST-NET, RFC 5737) — чтобы оценить интерфейс.
                Для реального подключения нужны рабочие сервера.
              </div>
            </div>
          </div>
          <Btn variant="outline" onClick={addDemo}>
            <FlaskConical size={14} />
            Добавить демо-набор
          </Btn>
        </div>
      </Card>
    </div>
  );
}
