"use client";

import clsx from "clsx";
import { useEffect, useState } from "react";
import {
  ArrowRight,
  CheckCircle2,
  Cpu,
  Globe2,
  ListFilter,
  RotateCcw,
  Save,
  XCircle,
} from "lucide-react";
import { Btn, Card, CardHeader, Field, Input, Spinner, Textarea } from "@/components/ui";
import { jfetch, toast, type SettingsData } from "@/lib/client";

const MODES = [
  {
    key: "rule",
    icon: ListFilter,
    title: "По правилам",
    desc: "Домены OpenAI (ChatGPT, Codex, Sora) — через прокси. Весь остальной трафик идёт напрямую. Рекомендуется.",
  },
  {
    key: "global",
    icon: Globe2,
    title: "Глобально",
    desc: "Весь трафик системы через выбранный прокси-сервер. Максимальная «приватность», медленнее.",
  },
  {
    key: "direct",
    icon: ArrowRight,
    title: "Напрямую",
    desc: "Прокси фактически отключён: все соединения идут напрямую. Полезно для отладки.",
  },
] as const;

export default function SettingsPage() {
  const [settings, setSettings] = useState<SettingsData | null>(null);
  const [defaultDomains, setDefaultDomains] = useState<string[]>([]);
  const [binary, setBinary] = useState<{ available: boolean; path: string | null; version: string | null } | null>(null);
  const [domainsText, setDomainsText] = useState("");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    jfetch<{ settings: SettingsData; binary: typeof binary; defaultDomains: string[] }>(
      "/api/settings",
    ).then((d) => {
      setSettings(d.settings);
      setBinary(d.binary);
      setDefaultDomains(d.defaultDomains);
      setDomainsText(d.settings.proxyDomains.join("\n"));
    });
  }, []);

  async function save() {
    if (!settings) return;
    setSaving(true);
    setSaved(false);
    try {
      const domains = domainsText
        .split(/[\n,;]+/)
        .map((d) => d.trim())
        .filter(Boolean);
      const r = await jfetch<{ settings: SettingsData }>("/api/settings", {
        method: "PUT",
        body: JSON.stringify({ ...settings, proxyDomains: domains }),
      });
      setSettings(r.settings);
      setDomainsText(r.settings.proxyDomains.join("\n"));
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
      toast("Настройки сохранены", "success");
      window.dispatchEvent(new Event("sd-refresh-control"));
    } catch (e) {
      toast(e instanceof Error ? e.message : "Ошибка сохранения", "error");
    } finally {
      setSaving(false);
    }
  }

  if (!settings) {
    return (
      <div className="flex items-center gap-2 py-24 text-muted">
        <Spinner /> загрузка настроек…
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="font-mono text-[10px] tracking-[0.3em] text-muted uppercase">
            панель / настройки
          </div>
          <h1 className="mt-2 text-3xl font-extrabold tracking-tight md:text-4xl">Настройки</h1>
        </div>
        <Btn variant="primary" size="lg" onClick={save} disabled={saving}>
          {saving ? <Spinner /> : saved ? <CheckCircle2 size={16} /> : <Save size={16} />}
          {saved ? "Сохранено" : "Сохранить"}
        </Btn>
      </div>

      {/* routing mode */}
      <Card>
        <CardHeader title="Режим маршрутизации" hint="что уходит через прокси" />
        <div className="grid grid-cols-1 gap-3 px-6 py-5 md:grid-cols-3">
          {MODES.map((m) => {
            const active = settings.mode === m.key;
            return (
              <button
                key={m.key}
                onClick={() => setSettings({ ...settings, mode: m.key })}
                className={clsx(
                  "rounded-xl border p-4 text-left transition-all duration-150",
                  active
                    ? "border-acid/60 bg-acid/8 shadow-[0_0_24px_rgba(201,242,75,0.08)]"
                    : "border-line bg-panel2 hover:border-line2",
                )}
              >
                <div className="flex items-center justify-between">
                  <m.icon size={17} className={active ? "text-acid" : "text-muted"} />
                  <span
                    className={clsx(
                      "h-2.5 w-2.5 rounded-full border-2 transition-colors",
                      active ? "border-acid bg-acid" : "border-line2",
                    )}
                  />
                </div>
                <div className={clsx("mt-3 text-[14px] font-bold", active ? "text-ink" : "text-sub")}>
                  {m.title}
                </div>
                <div className="mt-1.5 text-[11.5px] leading-relaxed text-muted">{m.desc}</div>
              </button>
            );
          })}
        </div>
      </Card>

      {/* network */}
      <div className="grid grid-cols-1 gap-5 xl:grid-cols-2">
        <Card>
          <CardHeader title="Сеть и DNS" />
          <div className="flex flex-col gap-4 px-6 py-5">
            <Field
              label="Локальный порт (mixed inbound)"
              hint="SOCKS5+HTTP прокси будет слушать 127.0.0.1:<порт>"
            >
              <Input
                type="number"
                min={1}
                max={65535}
                value={settings.listenPort}
                onChange={(e) => setSettings({ ...settings, listenPort: Number(e.target.value) })}
              />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="DNS через прокси (DoH)" hint="для доменов OpenAI">
                <Input
                  value={settings.dnsRemote}
                  onChange={(e) => setSettings({ ...settings, dnsRemote: e.target.value })}
                  placeholder="1.1.1.1"
                />
              </Field>
              <Field label="Локальный DNS (UDP)" hint="для остального трафика">
                <Input
                  value={settings.dnsLocal}
                  onChange={(e) => setSettings({ ...settings, dnsLocal: e.target.value })}
                  placeholder="223.5.5.5"
                />
              </Field>
            </div>
            <Field label="Путь к sing-box (необязательно)" hint="по умолчанию ищется ./bin/sing-box, затем PATH">
              <Input
                value={settings.singboxPath}
                onChange={(e) => setSettings({ ...settings, singboxPath: e.target.value })}
                placeholder="/usr/local/bin/sing-box"
              />
            </Field>
          </div>
        </Card>

        {/* domains */}
        <Card>
          <CardHeader
            title="Домены через прокси"
            hint="в режиме «по правилам» — по одному на строку"
            right={
              <Btn
                variant="ghost"
                size="sm"
                onClick={() => setDomainsText(defaultDomains.join("\n"))}
              >
                <RotateCcw size={12} />
                По умолчанию
              </Btn>
            }
          />
          <div className="px-6 py-5">
            <Textarea
              rows={10}
              value={domainsText}
              onChange={(e) => setDomainsText(e.target.value)}
              spellCheck={false}
              placeholder="openai.com&#10;chatgpt.com"
            />
            <div className="mt-2 font-mono text-[10px] text-muted">
              {domainsText.split(/[\n,;]+/).filter((d) => d.trim()).length} доменов ·
              сопоставление с учётом поддоменов (domain_suffix)
            </div>
          </div>
        </Card>
      </div>

      {/* engine info */}
      <Card>
        <CardHeader title="Ядро sing-box" hint="бинарный файл движка" />
        <div className="flex flex-wrap items-center gap-x-8 gap-y-3 px-6 py-5">
          <div className="flex items-center gap-3">
            <span
              className={clsx(
                "flex h-10 w-10 items-center justify-center rounded-xl border",
                binary?.available
                  ? "border-acid/40 bg-acid/10 text-acid"
                  : "border-danger/30 bg-danger/10 text-danger",
              )}
            >
              <Cpu size={17} />
            </span>
            <div>
              <div className="flex items-center gap-2 text-sm font-bold">
                {binary?.available ? (
                  <>
                    <CheckCircle2 size={14} className="text-acid" /> обнаружено
                  </>
                ) : (
                  <>
                    <XCircle size={14} className="text-danger" /> не найдено
                  </>
                )}
              </div>
              <div className="font-mono text-[11px] text-muted">
                {binary?.version ? `version ${binary.version}` : "—"}
              </div>
            </div>
          </div>
          <div className="min-w-0 font-mono text-[11px] break-all text-sub">
            {binary?.path || "укажите путь выше или положите бинарник в ./bin/"}
          </div>
          {!binary?.available && (
            <div className="w-full rounded-xl bg-bg p-3 font-mono text-[10px] leading-relaxed text-sub">
              # Linux x64 · установка рядом с приложением:{"\n"}
              curl -L https://github.com/SagerNet/sing-box/releases/download/v1.14.4/sing-box-1.14.4-linux-amd64.tar.gz | tar xz{"\n"}
              cp sing-box-1.14.4-linux-amd64/sing-box ./bin/sing-box && chmod +x ./bin/sing-box
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}
