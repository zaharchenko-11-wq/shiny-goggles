import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  jsonb,
  timestamp,
} from "drizzle-orm/pg-core";

/**
 * A proxy server entry. `config` stores the complete sing-box outbound
 * object (including its `tag`), so any protocol supported by sing-box
 * can be represented without schema migrations.
 */
export const servers = pgTable("servers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  protocol: text("protocol").notNull().default("unknown"),
  address: text("address").notNull().default(""),
  port: integer("port").notNull().default(0),
  config: jsonb("config").notNull(),
  latency: integer("latency"),
  status: text("status").notNull().default("unknown"), // ok | fail | unknown
  enabled: boolean("enabled").notNull().default(true),
  source: text("source").notNull().default("manual"), // manual | uri | subscription | demo
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const appSettings = pgTable("app_settings", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
});

export const eventLogs = pgTable("event_logs", {
  id: serial("id").primaryKey(),
  kind: text("kind").notNull().default("info"), // info | success | warn | error
  message: text("message").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  url: text("url").notNull().unique(),
  serversCount: integer("servers_count").notNull().default(0),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type ServerRow = typeof servers.$inferSelect;
export type EventLogRow = typeof eventLogs.$inferSelect;
export type SubscriptionRow = typeof subscriptions.$inferSelect;
