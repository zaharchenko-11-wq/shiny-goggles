"use client";

import clsx from "clsx";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Copy, Loader2, X } from "lucide-react";
import {
  useEffect,
  useState,
  type ButtonHTMLAttributes,
  type InputHTMLAttributes,
  type ReactNode,
  type TextareaHTMLAttributes,
} from "react";
import type { ToastKind } from "@/lib/client";

/* ---------- Button ---------- */

type BtnVariant = "primary" | "ghost" | "danger" | "outline" | "subtle";

const btnVariants: Record<BtnVariant, string> = {
  primary:
    "bg-acid text-black hover:bg-acid-dim font-semibold border border-acid shadow-[0_0_24px_rgba(201,242,75,0.22)]",
  outline:
    "border border-line2 bg-transparent text-ink hover:border-acid/60 hover:text-acid",
  ghost: "bg-panel2 text-sub hover:text-ink hover:bg-panel3 border border-line",
  subtle: "bg-transparent text-sub hover:text-ink border border-transparent",
  danger:
    "border border-danger/40 bg-danger/10 text-danger hover:bg-danger/20",
};

export function Btn({
  variant = "outline",
  size = "md",
  className,
  children,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: BtnVariant;
  size?: "sm" | "md" | "lg";
}) {
  return (
    <button
      {...rest}
      className={clsx(
        "inline-flex select-none items-center justify-center gap-2 rounded-xl transition-all duration-150 disabled:pointer-events-none disabled:opacity-40",
        size === "sm" && "h-8 px-3 text-xs",
        size === "md" && "h-10 px-4 text-sm",
        size === "lg" && "h-12 px-6 text-[15px]",
        btnVariants[variant],
        className,
      )}
    >
      {children}
    </button>
  );
}

/* ---------- Card ---------- */

export function Card({
  className,
  children,
}: {
  className?: string;
  children: ReactNode;
}) {
  return (
    <div
      className={clsx(
        "relative rounded-2xl border border-line bg-panel",
        className,
      )}
    >
      {children}
    </div>
  );
}

export function CardHeader({
  title,
  hint,
  right,
}: {
  title: string;
  hint?: string;
  right?: ReactNode;
}) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-line px-6 py-4">
      <div>
        <div className="font-mono text-[11px] font-semibold tracking-[0.22em] text-sub uppercase">
          {title}
        </div>
        {hint && <div className="mt-1 text-xs text-muted">{hint}</div>}
      </div>
      {right}
    </div>
  );
}

/* ---------- Dot ---------- */

export function Dot({
  color,
  pulse,
  className,
}: {
  color: string;
  pulse?: boolean;
  className?: string;
}) {
  return (
    <span
      className={clsx("inline-block h-2 w-2 rounded-full", pulse && "pulse-dot", className)}
      style={{ backgroundColor: color, boxShadow: `0 0 10px ${color}66` }}
    />
  );
}

/* ---------- Inputs ---------- */

export function Input(props: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      {...props}
      className={clsx(
        "h-10 w-full rounded-xl border border-line2 bg-bg px-3 font-mono text-sm text-ink outline-none transition-colors placeholder:text-muted focus:border-acid/70",
        props.className,
      )}
    />
  );
}

export function Textarea(props: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      {...props}
      className={clsx(
        "w-full rounded-xl border border-line2 bg-bg px-3 py-2.5 font-mono text-[13px] leading-relaxed text-ink outline-none transition-colors placeholder:text-muted focus:border-acid/70",
        props.className,
      )}
    />
  );
}

export function Field({
  label,
  children,
  hint,
}: {
  label: string;
  children: ReactNode;
  hint?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block font-mono text-[10px] font-semibold tracking-[0.18em] text-sub uppercase">
        {label}
      </span>
      {children}
      {hint && <span className="mt-1 block text-[11px] text-muted">{hint}</span>}
    </label>
  );
}

/* ---------- Spinner ---------- */

export function Spinner({ className }: { className?: string }) {
  return <Loader2 size={15} className={clsx("spin-slow", className)} />;
}

/* ---------- Copy button ---------- */

export function CopyBtn({ text, label }: { text: string; label?: string }) {
  const [ok, setOk] = useState(false);
  return (
    <Btn
      variant="outline"
      size="sm"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(text);
          setOk(true);
          setTimeout(() => setOk(false), 1500);
        } catch {
          /* noop */
        }
      }}
    >
      {ok ? <Check size={14} /> : <Copy size={14} />}
      {label ?? (ok ? "Скопировано" : "Копировать")}
    </Btn>
  );
}

/* ---------- Modal ---------- */

export function Modal({
  open,
  onClose,
  title,
  children,
  wide,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  wide?: boolean;
}) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    if (open) window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <div
            className="absolute inset-0 bg-black/70 backdrop-blur-sm"
            onClick={onClose}
          />
          <motion.div
            initial={{ scale: 0.96, y: 12, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.97, y: 8, opacity: 0 }}
            transition={{ type: "spring", stiffness: 380, damping: 34 }}
            className={clsx(
              "relative max-h-[88vh] w-full overflow-y-auto rounded-2xl border border-line2 bg-panel shadow-2xl",
              wide ? "max-w-2xl" : "max-w-md",
            )}
          >
            <div className="flex items-center justify-between border-b border-line px-6 py-4">
              <h3 className="font-mono text-xs font-semibold tracking-[0.2em] text-acid uppercase">
                {title}
              </h3>
              <button
                onClick={onClose}
                className="rounded-lg p-1.5 text-muted transition-colors hover:bg-panel2 hover:text-ink"
              >
                <X size={16} />
              </button>
            </div>
            <div className="px-6 py-5">{children}</div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* ---------- Toaster ---------- */

interface ToastItem {
  id: number;
  message: string;
  kind: ToastKind;
}

export function Toaster() {
  const [items, setItems] = useState<ToastItem[]>([]);

  useEffect(() => {
    const handler = (e: Event) => {
      const { message, kind } = (e as CustomEvent).detail as {
        message: string;
        kind: ToastKind;
      };
      const id = Date.now() + Math.random();
      setItems((prev) => [...prev.slice(-4), { id, message, kind }]);
      setTimeout(() => setItems((prev) => prev.filter((t) => t.id !== id)), 4500);
    };
    window.addEventListener("sd-toast", handler);
    return () => window.removeEventListener("sd-toast", handler);
  }, []);

  const colors: Record<ToastKind, string> = {
    info: "border-line2 text-ink",
    success: "border-acid/50 text-acid",
    error: "border-danger/50 text-danger",
  };

  return (
    <div className="pointer-events-none fixed right-5 bottom-5 z-[60] flex w-[340px] flex-col gap-2">
      {items.map((t) => (
        <div
          key={t.id}
          className={clsx(
            "toast-in pointer-events-auto rounded-xl border bg-panel2/95 px-4 py-3 text-[13px] shadow-xl backdrop-blur",
            colors[t.kind],
          )}
        >
          {t.message}
        </div>
      ))}
    </div>
  );
}
