"use client";

import { motion } from "framer-motion";
import {
  ArrowUpRight,
  Boxes,
  Braces,
  LayoutDashboard,
  ScrollText,
  SlidersHorizontal,
  SquareArrowOutUpRight,
  Waypoints,
} from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";
import clsx from "clsx";
import { jfetch, type ControlState } from "@/lib/client";
import { Dot, Toaster } from "./ui";

const NAV = [
  { href: "/", label: "Обзор", icon: LayoutDashboard },
  { href: "/servers", label: "Серверы", icon: Boxes },
  { href: "/import", label: "Импорт", icon: SquareArrowOutUpRight },
  { href: "/config", label: "Конфиг", icon: Braces },
  { href: "/logs", label: "Журнал", icon: ScrollText },
  { href: "/settings", label: "Настройки", icon: SlidersHorizontal },
];

function EngineMini() {
  const [state, setState] = useState<ControlState | null>(null);

  useEffect(() => {
    let stop = false;
    const load = () =>
      jfetch<ControlState>("/api/control")
        .then((d) => !stop && setState(d))
        .catch(() => {});
    load();
    const t = setInterval(load, 6000);
    const refresh = () => load();
    window.addEventListener("sd-refresh-control", refresh);
    return () => {
      stop = true;
      clearInterval(t);
      window.removeEventListener("sd-refresh-control", refresh);
    };
  }, []);

  const engine = state?.engine;
  const running = engine?.running;
  const available = engine?.available;

  const statusText = !available
    ? "ядро не найдено"
    : running
      ? `онлайн · :${engine?.port} · ${engine?.serverName ?? ""}`
      : "ядро остановлено";

  return (
    <div className="mx-3 mb-3 rounded-xl border border-line bg-panel2 px-3.5 py-3">
      <div className="flex items-center gap-2.5">
        <Dot
          color={!available ? "#5c6a71" : running ? "#c9f24b" : "#f5c04e"}
          pulse={!!running}
        />
        <div className="min-w-0">
          <div className="text-[12px] font-semibold text-ink">
            sing-box {engine?.version ? `v${engine.version}` : "не установлен"}
          </div>
          <div className="truncate font-mono text-[10px] text-muted">{statusText}</div>
        </div>
      </div>
    </div>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  const pathname = usePathname();

  return (
    <div className="relative z-10 min-h-screen">
      {/* Sidebar */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[232px] flex-col border-r border-line bg-panel/80 backdrop-blur md:flex">
        <Link href="/" className="flex items-center gap-3 px-5 pt-6 pb-7">
          <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-acid text-black shadow-[0_0_22px_rgba(201,242,75,0.35)]">
            <Waypoints size={18} strokeWidth={2.4} />
          </span>
          <span>
            <span className="block text-[15px] font-extrabold tracking-[0.14em]">
              SING·DECK
            </span>
            <span className="block font-mono text-[9px] tracking-[0.28em] text-muted uppercase">
              proxy control
            </span>
          </span>
        </Link>

        <nav className="flex flex-1 flex-col gap-1 px-3">
          {NAV.map((item) => {
            const active =
              item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={clsx(
                  "group flex items-center gap-3 rounded-xl px-3 py-2.5 text-[13px] font-medium transition-all duration-150",
                  active
                    ? "bg-panel2 text-acid"
                    : "text-sub hover:bg-panel2/60 hover:text-ink",
                )}
              >
                <item.icon
                  size={16}
                  strokeWidth={active ? 2.4 : 2}
                  className={clsx(active ? "text-acid" : "text-muted group-hover:text-sub")}
                />
                {item.label}
                {active && (
                  <span className="ml-auto h-1.5 w-1.5 rounded-full bg-acid" />
                )}
              </Link>
            );
          })}
        </nav>

        <EngineMini />

        <div className="border-t border-line px-5 py-4">
          <a
            href="https://github.com/SagerNet/sing-box"
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-2 font-mono text-[10px] text-muted transition-colors hover:text-sub"
          >
            <ArrowUpRight size={12} />
            SagerNet/sing-box
          </a>
        </div>
      </aside>

      {/* Mobile top nav */}
      <div className="sticky top-0 z-40 flex items-center gap-2 overflow-x-auto border-b border-line bg-panel/90 px-4 py-3 backdrop-blur md:hidden">
        <span className="mr-2 flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-acid text-black">
          <Waypoints size={14} strokeWidth={2.4} />
        </span>
        {NAV.map((item) => {
          const active =
            item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={clsx(
                "flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-xs whitespace-nowrap",
                active ? "bg-panel2 text-acid" : "text-sub",
              )}
            >
              <item.icon size={13} />
              {item.label}
            </Link>
          );
        })}
      </div>

      <main className="md:pl-[232px]">
        <motion.div
          key={pathname}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, ease: [0.2, 0.8, 0.2, 1] }}
          className="mx-auto max-w-6xl px-5 py-8 md:px-10 md:py-10"
        >
          {children}
        </motion.div>
      </main>

      <Toaster />
    </div>
  );
}
