/**
 * Parsers that convert share links (vless://, vmess://, trojan://, ss://,
 * hysteria2://, tuic://) into sing-box outbound JSON objects.
 */

export interface ParsedOutbound {
  outbound: Record<string, unknown>;
  protocol: string;
  address: string;
  port: number;
  name: string;
}

export const SUPPORTED_SCHEMES = [
  "vless://",
  "vmess://",
  "trojan://",
  "ss://",
  "hysteria2://",
  "hy2://",
  "tuic://",
];

function decodeB64(input: string): string {
  let s = input.trim().replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4 !== 0) s += "=";
  return Buffer.from(s, "base64").toString("utf8");
}

function tagOf(name: string | undefined, host: string, port: number): string {
  const t = (name || "").trim();
  return t || `${host}:${port}`;
}

function buildTransport(
  netType: string | null,
  q: URLSearchParams,
): Record<string, unknown> | undefined {
  if (!netType || netType === "tcp") return undefined;
  if (netType === "ws") {
    const headers: Record<string, string> = {};
    const host = q.get("host") || q.get("peer") || "";
    if (host) headers.Host = host;
    const t: Record<string, unknown> = {
      type: "ws",
      path: q.get("path") || "/",
    };
    if (Object.keys(headers).length) t.headers = headers;
    const ed = q.get("ed");
    if (ed && Number(ed) > 0) t.max_early_data = Number(ed);
    return t;
  }
  if (netType === "grpc") {
    return { type: "grpc", service_name: q.get("serviceName") || q.get("service_name") || "" };
  }
  if (netType === "http") {
    const host = q.get("host") || "";
    return {
      type: "http",
      host: host ? host.split(",") : [],
      path: q.get("path") || "/",
    };
  }
  if (netType === "httpupgrade") {
    return { type: "httpupgrade", host: q.get("host") || "", path: q.get("path") || "/" };
  }
  return undefined;
}

function insecureFlag(q: URLSearchParams): boolean {
  return (
    q.get("allowInsecure") === "1" ||
    q.get("allow_insecure") === "1" ||
    q.get("insecure") === "1" ||
    q.get("skip-cert-verify") === "1"
  );
}

function parseVless(line: string): ParsedOutbound {
  const u = new URL(line);
  const uuid = decodeURIComponent(u.username);
  const host = u.hostname;
  const port = Number(u.port) || 443;
  const q = u.searchParams;
  const name = tagOf(decodeURIComponent(u.hash.replace(/^#/, "")), host, port);
  const security = (q.get("security") || "").toLowerCase();

  const out: Record<string, unknown> = {
    type: "vless",
    tag: name,
    server: host,
    server_port: port,
    uuid,
  };
  const flow = q.get("flow");
  if (flow) out.flow = flow;

  if (security === "tls" || security === "reality") {
    const tls: Record<string, unknown> = {
      enabled: true,
      server_name: q.get("sni") || q.get("peer") || host,
      insecure: insecureFlag(q),
      utls: { enabled: true, fingerprint: q.get("fp") || "chrome" },
    };
    if (q.get("alpn")) tls.alpn = q.get("alpn")!.split(",").filter(Boolean);
    if (security === "reality") {
      tls.reality = {
        enabled: true,
        public_key: q.get("pbk") || "",
        short_id: q.get("sid") || undefined,
      };
    }
    out.tls = tls;
  }
  const transport = buildTransport(q.get("type"), q);
  if (transport) out.transport = transport;
  return { outbound: out, protocol: "vless", address: host, port, name };
}

function parseVmess(line: string): ParsedOutbound {
  const json = JSON.parse(decodeB64(line.replace("vmess://", "")));
  const host = String(json.add || "");
  const port = Number(json.port) || 443;
  const name = tagOf(json.ps ? String(json.ps) : "", host, port);
  const out: Record<string, unknown> = {
    type: "vmess",
    tag: name,
    server: host,
    server_port: port,
    uuid: json.id,
    security: json.scy || "auto",
  };
  const aid = Number(json.aid) || 0;
  if (aid > 0) out.alter_id = aid;

  if (json.tls === "tls") {
    const tls: Record<string, unknown> = {
      enabled: true,
      server_name: json.sni || json.host || host,
      utls: { enabled: true, fingerprint: json.fp || "chrome" },
    };
    if (json.alpn) tls.alpn = String(json.alpn).split(",").filter(Boolean);
    out.tls = tls;
  }
  const q = new URLSearchParams();
  if (json.path) q.set("path", String(json.path));
  if (json.host) q.set("host", String(json.host));
  const transport = buildTransport(json.net ? String(json.net) : null, q);
  if (transport) out.transport = transport;
  return { outbound: out, protocol: "vmess", address: host, port, name };
}

function parseTrojan(line: string): ParsedOutbound {
  const u = new URL(line);
  const host = u.hostname;
  const port = Number(u.port) || 443;
  const q = u.searchParams;
  const name = tagOf(decodeURIComponent(u.hash.replace(/^#/, "")), host, port);
  const tls: Record<string, unknown> = {
    enabled: true,
    server_name: q.get("sni") || q.get("peer") || host,
    insecure: insecureFlag(q),
    utls: { enabled: true, fingerprint: q.get("fp") || "chrome" },
  };
  if (q.get("alpn")) tls.alpn = q.get("alpn")!.split(",").filter(Boolean);
  const out: Record<string, unknown> = {
    type: "trojan",
    tag: name,
    server: host,
    server_port: port,
    password: decodeURIComponent(u.username),
    tls,
  };
  const transport = buildTransport(q.get("type"), q);
  if (transport) out.transport = transport;
  return { outbound: out, protocol: "trojan", address: host, port, name };
}

function parseShadowsocks(line: string): ParsedOutbound {
  const rest = line.replace("ss://", "");
  const hashIdx = rest.indexOf("#");
  const nameEnc = hashIdx >= 0 ? rest.slice(hashIdx + 1) : "";
  const queryIdx = rest.indexOf("?");
  const main = rest.slice(
    0,
    hashIdx >= 0 ? hashIdx : queryIdx >= 0 ? queryIdx : rest.length,
  );

  let method = "";
  let password = "";
  let host = "";
  let port = 0;

  if (main.includes("@")) {
    // SIP002: userinfo is base64url(method:password)
    const at = main.lastIndexOf("@");
    const userinfo = main.slice(0, at);
    const hostport = main.slice(at + 1);
    let decoded = userinfo;
    if (!userinfo.includes(":")) decoded = decodeB64(userinfo);
    const colon = decoded.indexOf(":");
    method = decoded.slice(0, colon);
    password = decoded.slice(colon + 1);
    const hp = new URL("tcp://" + hostport);
    host = hp.hostname;
    port = Number(hp.port);
  } else {
    // legacy: entire payload base64
    const decoded = decodeB64(main);
    const at = decoded.lastIndexOf("@");
    const userinfo = decoded.slice(0, at);
    const hostport = decoded.slice(at + 1);
    const colon = userinfo.indexOf(":");
    method = userinfo.slice(0, colon);
    password = userinfo.slice(colon + 1);
    const hp = hostport.split(":");
    host = hp.slice(0, -1).join(":");
    port = Number(hp[hp.length - 1]);
  }

  const name = tagOf(decodeURIComponent(nameEnc), host, port);
  const out: Record<string, unknown> = {
    type: "shadowsocks",
    tag: name,
    server: host,
    server_port: port,
    method,
    password,
  };
  return { outbound: out, protocol: "shadowsocks", address: host, port, name };
}

function parseHysteria2(line: string): ParsedOutbound {
  const u = new URL(line.replace("hy2://", "hysteria2://"));
  const host = u.hostname;
  const port = Number(u.port) || 443;
  const q = u.searchParams;
  const name = tagOf(decodeURIComponent(u.hash.replace(/^#/, "")), host, port);
  const tls: Record<string, unknown> = {
    enabled: true,
    server_name: q.get("sni") || host,
    insecure: insecureFlag(q),
  };
  const out: Record<string, unknown> = {
    type: "hysteria2",
    tag: name,
    server: host,
    server_port: port,
    password: decodeURIComponent(u.username),
    tls,
  };
  if ((q.get("obfs") || "").toLowerCase() === "salamander") {
    out.obfs = { type: "salamander", password: q.get("obfs-password") || "" };
  }
  return { outbound: out, protocol: "hysteria2", address: host, port, name };
}

function parseTuic(line: string): ParsedOutbound {
  const u = new URL(line);
  const host = u.hostname;
  const port = Number(u.port) || 443;
  const q = u.searchParams;
  const [uuid, password] = [
    decodeURIComponent(u.username),
    decodeURIComponent(u.password),
  ];
  const name = tagOf(decodeURIComponent(u.hash.replace(/^#/, "")), host, port);
  const tls: Record<string, unknown> = {
    enabled: true,
    server_name: q.get("sni") || host,
    insecure: insecureFlag(q),
  };
  if (q.get("alpn")) tls.alpn = q.get("alpn")!.split(",").filter(Boolean);
  const out: Record<string, unknown> = {
    type: "tuic",
    tag: name,
    server: host,
    server_port: port,
    uuid,
    password,
    congestion_control: (q.get("congestion_control") || "bbr").toLowerCase(),
    tls,
  };
  return { outbound: out, protocol: "tuic", address: host, port, name };
}

export function parseShareLink(line: string): ParsedOutbound {
  const l = line.trim();
  if (l.startsWith("vless://")) return parseVless(l);
  if (l.startsWith("vmess://")) return parseVmess(l);
  if (l.startsWith("trojan://")) return parseTrojan(l);
  if (l.startsWith("ss://")) return parseShadowsocks(l);
  if (l.startsWith("hysteria2://") || l.startsWith("hy2://")) return parseHysteria2(l);
  if (l.startsWith("tuic://")) return parseTuic(l);
  throw new Error(
    "Неподдерживаемая схема. Поддерживаются: vless, vmess, trojan, ss, hysteria2, tuic",
  );
}

/** Best-effort detection for subscription payloads. */
export function decodeSubscriptionPayload(text: string): string[] {
  const trimmed = text.trim();
  let candidate = trimmed;
  // If it does not contain any scheme directly, try base64 decode.
  if (!/(vless|vmess|trojan|ss|hysteria2|hy2|tuic):\/\//.test(trimmed)) {
    try {
      const decoded = decodeB64(trimmed);
      if (/(vless|vmess|trojan|ss|hysteria2|hy2|tuic):\/\//.test(decoded)) {
        candidate = decoded;
      }
    } catch {
      /* keep original */
    }
  }
  return candidate
    .split(/\r?\n/)
    .map((s) => s.trim())
    .filter((s) => s && !s.startsWith("#") && !s.startsWith("//"));
}
