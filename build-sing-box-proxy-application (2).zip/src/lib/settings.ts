import { db } from "@/db";
import { appSettings, eventLogs } from "@/db/schema";
import { eq } from "drizzle-orm";

export type RouteMode = "rule" | "global" | "direct";

export interface Settings {
  mode: RouteMode;
  activeServerId: number | null;
  listenPort: number;
  proxyDomains: string[];
  dnsRemote: string;
  dnsLocal: string;
  singboxPath: string; // optional explicit binary path override
}

export const DEFAULT_PROXY_DOMAINS = [
  "openai.com",
  "chatgpt.com",
  "chat.com",
  "oaistatic.com",
  "oaiusercontent.com",
  "auth0.openai.com",
  "openai.fides-cdn.ethyca.com",
  "cdn.usefathom.com",
  "sora.com",
  "helper.chat",
];

export const DEFAULT_SETTINGS: Settings = {
  mode: "rule",
  activeServerId: null,
  listenPort: 2080,
  proxyDomains: DEFAULT_PROXY_DOMAINS,
  dnsRemote: "1.1.1.1",
  dnsLocal: "223.5.5.5",
  singboxPath: "",
};

const KEYS: (keyof Settings)[] = [
  "mode",
  "activeServerId",
  "listenPort",
  "proxyDomains",
  "dnsRemote",
  "dnsLocal",
  "singboxPath",
];

export async function getSettings(): Promise<Settings> {
  const rows = await db.select().from(appSettings);
  const map = new Map<string, unknown>(rows.map((r) => [r.key, r.value]));
  const merged: Record<string, unknown> = { ...DEFAULT_SETTINGS };
  for (const key of KEYS) {
    if (map.has(key)) merged[key] = map.get(key);
  }
  // Normalize
  const s = merged as unknown as Settings;
  if (!Array.isArray(s.proxyDomains) || s.proxyDomains.length === 0) {
    s.proxyDomains = DEFAULT_PROXY_DOMAINS;
  }
  if (!["rule", "global", "direct"].includes(s.mode)) s.mode = "rule";
  s.listenPort = Number(s.listenPort) || 2080;
  return s;
}

export async function setSettings(partial: Partial<Settings>): Promise<Settings> {
  for (const key of KEYS) {
    if (!(key in partial)) continue;
    const value = partial[key] as unknown;
    if (value === null) {
      // jsonb columns cannot hold SQL NULL — fall back to the in-code default
      await db.delete(appSettings).where(eq(appSettings.key, key));
      continue;
    }
    await db
      .insert(appSettings)
      .values({ key, value: value as never })
      .onConflictDoUpdate({ target: appSettings.key, set: { value: value as never } });
  }
  return getSettings();
}

export async function addLog(
  kind: "info" | "success" | "warn" | "error",
  message: string,
) {
  await db.insert(eventLogs).values({ kind, message });
}
