"use client";

export interface ServerItem {
  id: number;
  name: string;
  protocol: string;
  address: string;
  port: number;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  config: any;
  latency: number | null;
  status: string;
  enabled: boolean;
  source: string;
  createdAt: string;
}

export interface EngineInfo {
  available: boolean;
  path: string | null;
  version: string | null;
  running: boolean;
  pid: number | null;
  startedAt: string | null;
  serverName: string | null;
  mode: string | null;
  port: number | null;
}

export interface SettingsData {
  mode: "rule" | "global" | "direct";
  activeServerId: number | null;
  listenPort: number;
  proxyDomains: string[];
  dnsRemote: string;
  dnsLocal: string;
  singboxPath: string;
}

export interface ControlState {
  engine: EngineInfo;
  settings: SettingsData;
  activeServer: ServerItem | null;
}

export interface IpInfoData {
  ip: string;
  countryCode: string;
  country: string;
  city: string;
  org: string;
  source: string;
}

export async function jfetch<T = unknown>(
  url: string,
  opts?: RequestInit,
): Promise<T> {
  const res = await fetch(url, {
    ...opts,
    headers: { "content-type": "application/json", ...(opts?.headers || {}) },
    cache: "no-store",
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = (data as { error?: string; message?: string; detail?: string });
    const e = new Error(err.error || err.message || `HTTP ${res.status}`) as Error & {
      detail?: string;
    };
    e.detail = err.detail;
    throw e;
  }
  return data as T;
}

export type ToastKind = "info" | "success" | "error";

export function toast(message: string, kind: ToastKind = "info") {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new CustomEvent("sd-toast", { detail: { message, kind } }));
}

export const PROTOCOL_COLORS: Record<string, string> = {
  vless: "#c9f24b",
  vmess: "#5fd2e4",
  trojan: "#f5b04e",
  shadowsocks: "#b78cff",
  hysteria2: "#ff7ab8",
  tuic: "#4ade80",
  wireguard: "#7dd3fc",
  direct: "#93a2aa",
  unknown: "#8a8f94",
};

export function protocolColor(p: string): string {
  return PROTOCOL_COLORS[p] || PROTOCOL_COLORS.unknown;
}

export function latencyColor(ms: number | null): string {
  if (ms === null || ms === undefined) return "text-muted";
  if (ms < 300) return "text-acid";
  if (ms < 800) return "text-warn";
  return "text-danger";
}

export function fmtTime(iso: string | null | undefined): string {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleString("ru-RU", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      day: "2-digit",
      month: "2-digit",
    });
  } catch {
    return iso;
  }
}
