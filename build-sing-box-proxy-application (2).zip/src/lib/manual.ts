/**
 * Declarative form specs for manually adding servers, plus builders that
 * produce sing-box outbound objects from form values.
 */

export type FieldType = "text" | "number" | "select" | "checkbox";

export interface FieldSpec {
  key: string;
  label: string;
  type: FieldType;
  options?: string[];
  required?: boolean;
  placeholder?: string;
  hint?: string;
  show?: (v: Record<string, string>) => boolean;
  span?: "full" | "half";
}

export const PROTOCOL_LABELS: Record<string, string> = {
  vless: "VLESS",
  vmess: "VMess",
  trojan: "Trojan",
  shadowsocks: "Shadowsocks",
  hysteria2: "Hysteria2",
  tuic: "TUIC",
  wireguard: "WireGuard",
};

const V = (v: Record<string, string>, k: string) => (v[k] || "").trim();
const isSecurity = (v: Record<string, string>) => V(v, "security") !== "none";
const isReality = (v: Record<string, string>) => V(v, "security") === "reality";
const isWs = (v: Record<string, string>) => ["ws", "httpupgrade"].includes(V(v, "transport") || V(v, "network"));
const isGrpc = (v: Record<string, string>) => (V(v, "transport") || V(v, "network")) === "grpc";
const tlsOn = (v: Record<string, string>) => V(v, "tls") === "1";

const BASE: FieldSpec[] = [
  { key: "name", label: "Название", type: "text", placeholder: "NL · Frankfurt #1" },
  { key: "server", label: "Адрес сервера", type: "text", required: true, placeholder: "server.example.com" },
  { key: "port", label: "Порт", type: "number", required: true, placeholder: "443" },
];

const TRANSPORT: FieldSpec[] = [
  { key: "transport", label: "Транспорт", type: "select", options: ["tcp", "ws", "grpc", "httpupgrade"] },
  { key: "path", label: "WS Path", type: "text", placeholder: "/ws", show: isWs },
  { key: "host", label: "WS Host", type: "text", placeholder: "cdn.example.com", show: isWs },
  { key: "serviceName", label: "gRPC service name", type: "text", show: isGrpc },
];

export const PROTOCOL_FORMS: Record<string, FieldSpec[]> = {
  vless: [
    ...BASE,
    { key: "uuid", label: "UUID", type: "text", required: true, placeholder: "11111111-....", span: "full" },
    {
      key: "security",
      label: "Безопасность",
      type: "select",
      options: ["reality", "tls", "none"],
    },
    { key: "flow", label: "Flow", type: "select", options: ["", "xtls-rprx-vision"], show: isSecurity },
    { key: "sni", label: "SNI", type: "text", placeholder: "www.microsoft.com", show: isSecurity },
    {
      key: "fp",
      label: "Fingerprint (uTLS)",
      type: "select",
      options: ["chrome", "firefox", "safari", "edge", "randomized"],
      show: isSecurity,
    },
    { key: "pbk", label: "Reality public key", type: "text", show: isReality, hint: "base64-строка из панели Xray/sing-box" },
    { key: "sid", label: "Reality short id", type: "text", placeholder: "0123abcd", show: isReality },
    ...TRANSPORT,
  ],
  vmess: [
    ...BASE,
    { key: "uuid", label: "UUID", type: "text", required: true, span: "full" },
    {
      key: "security",
      label: "Шифрование",
      type: "select",
      options: ["auto", "aes-128-gcm", "chacha20-poly1305", "zero", "none"],
    },
    { key: "alterId", label: "Alter ID", type: "number", placeholder: "0" },
    { key: "tls", label: "TLS включён", type: "checkbox" },
    { key: "sni", label: "SNI", type: "text", show: tlsOn },
    { key: "network", label: "Транспорт", type: "select", options: ["tcp", "ws", "grpc"] },
    { key: "path", label: "WS Path", type: "text", placeholder: "/vmess", show: isWs },
    { key: "host", label: "WS Host", type: "text", show: isWs },
  ],
  trojan: [
    ...BASE,
    { key: "password", label: "Пароль", type: "text", required: true, span: "full" },
    { key: "sni", label: "SNI", type: "text", placeholder: "по умолчанию — адрес сервера" },
    { key: "alpn", label: "ALPN", type: "text", placeholder: "h2,http/1.1" },
    ...TRANSPORT,
  ],
  shadowsocks: [
    ...BASE,
    {
      key: "method",
      label: "Метод",
      type: "select",
      options: [
        "2022-blake3-aes-128-gcm",
        "2022-blake3-aes-256-gcm",
        "2022-blake3-chacha20-poly1305",
        "aes-256-gcm",
        "aes-192-gcm",
        "aes-128-gcm",
        "chacha20-ietf-poly1305",
        "xchacha20-ietf-poly1305",
        "none",
      ],
    },
    { key: "password", label: "Пароль", type: "text", required: true, span: "full" },
  ],
  hysteria2: [
    ...BASE,
    { key: "password", label: "Пароль", type: "text", required: true, span: "full" },
    { key: "sni", label: "SNI", type: "text" },
    { key: "insecure", label: "Игнорировать проверку TLS", type: "checkbox" },
    { key: "obfs", label: "obfs (salamander)", type: "checkbox" },
    { key: "obfsPassword", label: "obfs пароль", type: "text", show: (v) => V(v, "obfs") === "1" },
  ],
  tuic: [
    ...BASE,
    { key: "uuid", label: "UUID", type: "text", required: true },
    { key: "password", label: "Пароль", type: "text", required: true },
    { key: "congestion", label: "Congestion control", type: "select", options: ["bbr", "cubic", "new_reno"] },
    { key: "sni", label: "SNI", type: "text" },
    { key: "insecure", label: "Игнорировать проверку TLS", type: "checkbox" },
  ],
  wireguard: [
    ...BASE,
    { key: "privateKey", label: "Private key", type: "text", required: true, span: "full" },
    { key: "peerPublicKey", label: "Peer public key", type: "text", required: true, span: "full" },
    { key: "localAddress", label: "Local address (CIDR)", type: "text", placeholder: "10.0.0.2/32" },
    { key: "mtu", label: "MTU", type: "number", placeholder: "1420" },
    { key: "reserved", label: "Reserved (через запятую)", type: "text", placeholder: "1,2,3" },
  ],
};

export function buildManualOutbound(
  protocol: string,
  v: Record<string, string>,
): { outbound: Record<string, unknown>; name: string } {
  const server = V(v, "server");
  const port = Number(V(v, "port")) || 0;
  if (!server) throw new Error("Укажите адрес сервера");
  if (!port || port > 65535) throw new Error("Укажите корректный порт");
  const name = V(v, "name") || `${server}:${port}`;

  const out: Record<string, unknown> = { type: protocol, tag: name, server, server_port: port };

  const transportOf = (netType: string): Record<string, unknown> | undefined => {
    if (netType === "ws" || netType === "httpupgrade") {
      const t: Record<string, unknown> = { type: netType, path: V(v, "path") || "/" };
      if (V(v, "host")) t.headers = { Host: V(v, "host") };
      if (netType === "httpupgrade") {
        t.host = V(v, "host");
        delete t.headers;
      }
      return t;
    }
    if (netType === "grpc") return { type: "grpc", service_name: V(v, "serviceName") };
    return undefined;
  };

  if (protocol === "vless") {
    out.uuid = V(v, "uuid");
    if (V(v, "flow")) out.flow = V(v, "flow");
    const security = V(v, "security") || "reality";
    if (security !== "none") {
      const tls: Record<string, unknown> = {
        enabled: true,
        server_name: V(v, "sni") || server,
        utls: { enabled: true, fingerprint: V(v, "fp") || "chrome" },
      };
      if (security === "reality") {
        tls.reality = {
          enabled: true,
          public_key: V(v, "pbk"),
          short_id: V(v, "sid") || undefined,
        };
      }
      out.tls = tls;
    }
    const t = transportOf(V(v, "transport"));
    if (t) out.transport = t;
  } else if (protocol === "vmess") {
    out.uuid = V(v, "uuid");
    out.security = V(v, "security") || "auto";
    const aid = Number(V(v, "alterId")) || 0;
    if (aid > 0) out.alter_id = aid;
    if (tlsOn(v)) {
      out.tls = {
        enabled: true,
        server_name: V(v, "sni") || server,
        utls: { enabled: true, fingerprint: "chrome" },
      };
    }
    const t = transportOf(V(v, "network"));
    if (t) out.transport = t;
  } else if (protocol === "trojan") {
    out.password = V(v, "password");
    const tls: Record<string, unknown> = {
      enabled: true,
      server_name: V(v, "sni") || server,
      utls: { enabled: true, fingerprint: "chrome" },
    };
    if (V(v, "alpn")) tls.alpn = V(v, "alpn").split(",").map((s) => s.trim()).filter(Boolean);
    out.tls = tls;
    const t = transportOf(V(v, "transport"));
    if (t) out.transport = t;
  } else if (protocol === "shadowsocks") {
    out.method = V(v, "method") || "aes-256-gcm";
    out.password = V(v, "password");
  } else if (protocol === "hysteria2") {
    out.password = V(v, "password");
    out.tls = {
      enabled: true,
      server_name: V(v, "sni") || server,
      insecure: V(v, "insecure") === "1",
    };
    if (V(v, "obfs") === "1") {
      out.obfs = { type: "salamander", password: V(v, "obfsPassword") };
    }
  } else if (protocol === "tuic") {
    out.uuid = V(v, "uuid");
    out.password = V(v, "password");
    out.congestion_control = V(v, "congestion") || "bbr";
    out.tls = {
      enabled: true,
      server_name: V(v, "sni") || server,
      insecure: V(v, "insecure") === "1",
    };
  } else if (protocol === "wireguard") {
    out.local_address = [V(v, "localAddress") || "10.0.0.2/32"];
    out.private_key = V(v, "privateKey");
    out.peer_public_key = V(v, "peerPublicKey");
    if (V(v, "reserved")) {
      out.reserved = V(v, "reserved")
        .split(",")
        .map((s) => Number(s.trim()))
        .filter((n) => Number.isFinite(n));
    }
    if (V(v, "mtu")) out.mtu = Number(V(v, "mtu"));
  } else {
    throw new Error("Неизвестный протокол");
  }

  return { outbound: out, name };
}
