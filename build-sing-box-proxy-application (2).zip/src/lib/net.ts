import net from "node:net";

/** Measures TCP connect time to host:port. Returns ms or null on failure. */
export function tcpPing(host: string, port: number, timeoutMs = 3500): Promise<number | null> {
  return new Promise((resolve) => {
    if (!host || !port) return resolve(null);
    const started = Date.now();
    const socket = new net.Socket();
    let done = false;
    const finish = (ms: number | null) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(ms);
    };
    socket.setTimeout(timeoutMs);
    socket.once("connect", () => finish(Date.now() - started));
    socket.once("timeout", () => finish(null));
    socket.once("error", () => finish(null));
    try {
      socket.connect(port, host);
    } catch {
      finish(null);
    }
  });
}
