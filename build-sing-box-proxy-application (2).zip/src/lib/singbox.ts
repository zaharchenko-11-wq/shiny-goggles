import { execFileSync, execSync, spawn } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import type { Settings } from "./settings";
import { buildSingboxConfig } from "./config-gen";

const RUN_DIR = path.join(process.cwd(), ".singbox-run");
const STATE_FILE = path.join(RUN_DIR, "state.json");
const CONFIG_FILE = path.join(RUN_DIR, "config.json");
const LOG_FILE = path.join(RUN_DIR, "sing-box.log");

interface RunState {
  pid: number;
  startedAt: string;
  serverId: number | null;
  serverName: string;
  mode: string;
  port: number;
}

export interface BinaryInfo {
  available: boolean;
  path: string | null;
  version: string | null;
}

export interface EngineStatus extends BinaryInfo {
  running: boolean;
  pid: number | null;
  startedAt: string | null;
  serverName: string | null;
  mode: string | null;
  port: number | null;
}

export function resolveBinary(preferred?: string): string | null {
  const candidates: (string | undefined)[] = [
    preferred,
    process.env.SING_BOX_PATH,
    path.join(process.cwd(), "bin", "sing-box"),
    path.join(process.cwd(), "bin", "sing-box.exe"),
  ];
  for (const c of candidates) {
    if (c && fs.existsSync(c)) {
      try {
        fs.accessSync(c, fs.constants.X_OK);
        return c;
      } catch {
        /* not executable */
      }
    }
  }
  try {
    const found = execSync("which sing-box 2>/dev/null", { encoding: "utf8" }).trim();
    if (found) return found;
  } catch {
    /* not found */
  }
  return null;
}

export function binaryInfo(preferred?: string): BinaryInfo {
  const p = resolveBinary(preferred);
  if (!p) return { available: false, path: null, version: null };
  try {
    const out = execFileSync(p, ["version"], {
      encoding: "utf8",
      timeout: 5000,
    });
    const m = out.match(/sing-box version ([\d.]+)/);
    return { available: true, path: p, version: m ? m[1] : "unknown" };
  } catch {
    return { available: false, path: p, version: null };
  }
}

function ensureRunDir() {
  if (!fs.existsSync(RUN_DIR)) fs.mkdirSync(RUN_DIR, { recursive: true });
}

function readState(): RunState | null {
  try {
    return JSON.parse(fs.readFileSync(STATE_FILE, "utf8")) as RunState;
  } catch {
    return null;
  }
}

function writeState(s: RunState | null) {
  ensureRunDir();
  if (s) fs.writeFileSync(STATE_FILE, JSON.stringify(s, null, 2));
  else if (fs.existsSync(STATE_FILE)) fs.unlinkSync(STATE_FILE);
}

function pidAlive(pid: number): boolean {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

export function engineStatus(settings?: Settings): EngineStatus {
  const bin = binaryInfo(settings?.singboxPath || undefined);
  const state = readState();
  const running = state ? pidAlive(state.pid) : false;
  if (state && !running) writeState(null);
  return {
    ...bin,
    running,
    pid: running && state ? state.pid : null,
    startedAt: running && state ? state.startedAt : null,
    serverName: running && state ? state.serverName : null,
    mode: running && state ? state.mode : null,
    port: running && state ? state.port : null,
  };
}

export interface ControlResult {
  ok: boolean;
  message: string;
  detail?: string;
}

export async function startEngine(
  settings: Settings,
  activeOutbound: Record<string, unknown> | null,
  serverId: number | null,
  serverName: string,
): Promise<ControlResult> {
  const binPath = resolveBinary(settings.singboxPath || undefined);
  if (!binPath) {
    return {
      ok: false,
      message: "Бинарный файл sing-box не найден",
      detail:
        "Укажите путь к sing-box в настройках или положите бинарник в ./bin/sing-box. Скачать: https://github.com/SagerNet/sing-box/releases",
    };
  }

  // Stop a previous instance first
  stopEngine();

  const { config } = buildSingboxConfig(activeOutbound, settings);
  ensureRunDir();
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));

  // Validate config first
  try {
    execFileSync(binPath, ["check", "-c", CONFIG_FILE], {
      encoding: "utf8",
      timeout: 10000,
    });
  } catch (e) {
    const msg = e instanceof Error ? String((e as { stderr?: string }).stderr || e.message) : String(e);
    return { ok: false, message: "Конфигурация не прошла проверку sing-box", detail: msg };
  }

  const logFd = fs.openSync(LOG_FILE, "a");
  const child = spawn(binPath, ["run", "-c", CONFIG_FILE], {
    stdio: ["ignore", logFd, logFd],
    detached: false,
  });
  child.unref();

  await new Promise((r) => setTimeout(r, 800));

  if (!child.pid || !pidAlive(child.pid)) {
    fs.closeSync(logFd);
    const tail = readLogTail(40);
    return {
      ok: false,
      message: "sing-box завершился сразу после запуска",
      detail: tail || undefined,
    };
  }
  fs.closeSync(logFd);

  writeState({
    pid: child.pid,
    startedAt: new Date().toISOString(),
    serverId,
    serverName,
    mode: settings.mode,
    port: settings.listenPort,
  });
  return {
    ok: true,
    message: `sing-box запущен (pid ${child.pid}), локальный порт ${settings.listenPort}`,
  };
}

export function stopEngine(): ControlResult {
  const state = readState();
  if (!state) return { ok: true, message: "sing-box не запущен" };
  try {
    process.kill(state.pid, "SIGTERM");
  } catch {
    /* already dead */
  }
  writeState(null);
  return { ok: true, message: "sing-box остановлен" };
}

export function readLogTail(lines = 200): string {
  try {
    const content = fs.readFileSync(LOG_FILE, "utf8");
    const arr = content.split(/\r?\n/);
    return arr.slice(-lines).join("\n");
  } catch {
    return "";
  }
}

export function configFilePath(): string {
  return CONFIG_FILE;
}
