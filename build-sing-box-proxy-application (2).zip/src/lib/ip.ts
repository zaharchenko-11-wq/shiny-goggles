import { ProxyAgent, fetch as undiciFetch } from "undici";

export interface IpInfo {
  ip: string;
  countryCode: string;
  country: string;
  city: string;
  org: string;
  source: string;
}

interface IpWho {
  success?: boolean;
  ip?: string;
  country?: string;
  country_code?: string;
  city?: string;
  connection?: { isp?: string; org?: string; asn?: number };
}

interface IpSb {
  ip?: string;
  country?: string;
  country_code?: string;
  city?: string;
  isp?: string;
  asn_organization?: string;
  organization?: string;
}

interface IpApiCo {
  ip?: string;
  country_name?: string;
  country_code?: string;
  city?: string;
  org?: string;
}

interface IpGeneric extends IpWho, IpSb, IpApiCo {}

const UA =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36";

function normalize(data: IpGeneric, source: string): IpInfo | null {
  const ip = data.ip;
  if (!ip) return null;
  return {
    ip,
    countryCode: (data.country_code || "").toUpperCase(),
    country: data.country || data.country_name || "",
    city: data.city || "",
    org:
      data.connection?.isp ||
      data.connection?.org ||
      data.isp ||
      data.asn_organization ||
      data.organization ||
      data.org ||
      "",
    source,
  };
}

export async function fetchIpInfo(
  opts: { timeoutMs?: number; viaProxyPort?: number } = {},
): Promise<IpInfo | null> {
  const timeoutMs = opts.timeoutMs ?? 6000;
  const dispatcher = opts.viaProxyPort
    ? new ProxyAgent(`http://127.0.0.1:${opts.viaProxyPort}`)
    : undefined;

  const endpoints: { url: string; name: string }[] = [
    { url: "https://ipwho.is/", name: "ipwho.is" },
    { url: "https://api.ip.sb/geoip", name: "api.ip.sb" },
    { url: "https://ipapi.co/json/", name: "ipapi.co" },
  ];
  for (const ep of endpoints) {
    try {
      const res = await undiciFetch(ep.url, {
        dispatcher,
        signal: AbortSignal.timeout(timeoutMs),
        headers: { "user-agent": UA, accept: "application/json" },
      });
      if (!res.ok) continue;
      const data = (await res.json()) as IpGeneric;
      if (data.success === false) continue;
      const info = normalize(data, ep.name);
      if (info) return info;
    } catch {
      /* try next endpoint */
    }
  }
  return null;
}
