import type { Settings } from "./settings";

export interface GeneratedConfig {
  config: Record<string, unknown>;
  degraded: boolean; // true when no active server is selected
}

/**
 * Builds a complete sing-box configuration in the modern (>= 1.11) format:
 *  - mixed (SOCKS5+HTTP) inbound on localhost
 *  - routing rules that send OpenAI / ChatGPT / Codex domains through the
 *    selected proxy while all other traffic goes direct ("rule" mode)
 *  - DNS over HTTPS via the proxy for proxied domains
 */
export function buildSingboxConfig(
  activeOutbound: Record<string, unknown> | null,
  settings: Settings,
): GeneratedConfig {
  const degraded = !activeOutbound;

  const proxyOutbound: Record<string, unknown> = activeOutbound
    ? { ...activeOutbound, tag: "proxy", domain_resolver: { server: "dns-system" } }
    : { type: "direct", tag: "proxy", domain_resolver: { server: "dns-system" } };

  const domains = settings.proxyDomains
    .map((d) => d.trim().toLowerCase().replace(/^\*\./, ""))
    .filter(Boolean);

  const dnsRules: Record<string, unknown>[] = [];
  if (settings.mode !== "direct" && domains.length) {
    dnsRules.push({ domain_suffix: domains, server: "dns-remote" });
  }

  const routeRules: Record<string, unknown>[] = [
    { action: "sniff" },
    { protocol: "dns", action: "hijack-dns" },
    { ip_is_private: true, outbound: "direct" },
  ];
  if (settings.mode === "rule" && domains.length) {
    routeRules.push({ domain_suffix: domains, outbound: "proxy" });
  }

  const final =
    settings.mode === "global"
      ? "proxy"
      : settings.mode === "rule"
        ? "direct"
        : "direct";

  const config: Record<string, unknown> = {
    log: { level: "warn", timestamp: true },
    dns: {
      servers: [
        {
          type: "https",
          tag: "dns-remote",
          server: settings.dnsRemote || "1.1.1.1",
          detour: "proxy",
        },
        {
          type: "udp",
          tag: "dns-local",
          server: settings.dnsLocal || "223.5.5.5",
          detour: "direct",
        },
        {
          type: "local",
          tag: "dns-system",
        },
      ],
      rules: dnsRules,
      final: "dns-local",
    },
    inbounds: [
      {
        type: "mixed",
        tag: "in",
        listen: "127.0.0.1",
        listen_port: settings.listenPort || 2080,
      },
    ],
    outbounds: [
      proxyOutbound,
      {
        type: "direct",
        tag: "direct",
        domain_resolver: { server: "dns-system", strategy: "ipv4_only" },
      },
    ],
    route: {
      rules: routeRules,
      final,
      auto_detect_interface: true,
      default_domain_resolver: { server: "dns-system", strategy: "ipv4_only" },
    },
    experimental: {
      cache_file: { enabled: false },
      clash_api: { external_controller: "127.0.0.1:9090" },
    },
  };

  return { config, degraded };
}
